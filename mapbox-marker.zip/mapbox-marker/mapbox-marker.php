<?php
/**
 * Mapbox Marker
 * @wordpress-plugin
 * Plugin Name: Mapbox Marker
 * Plugin URI:  https://google.com/
 * Description: Plugin which gives the special map
 * Version:     0.1
 * Author:      Shourya
 */
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('MapBoxMarker')) {
    class MapBoxMarker {

		function map_box_scripts()
        {
		wp_enqueue_script( 'mapbox', 'https://api.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.js', array('jquery'), '3.3.5', true );
		wp_enqueue_script( 'mapbox-directions', 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.js', array('jquery'), '3.3.5', true );
		wp_enqueue_script('map-box-script', plugin_dir_url(__FILE__) . 'assets/javascripts/script.js', array('jquery') , false, true);	
            
        }
        function map_box_override_stylesheets() {
           wp_enqueue_style('mapbox-gl', 'https://api.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.css', array(), '0.1.0', 'all');
           wp_enqueue_style('mapbox-gl-directions', 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.css', array(), '0.1.0', 'all');
		   $dir = plugin_dir_url(__FILE__);
           wp_enqueue_style('theme-override', $dir . 'assets/stylesheets/style.css', array() , '0.1.0', 'all');	
		}
        function map_box_shortcode($atts, $content, $code = NULL) 
        {
            ob_start(); ?>
				<div id='map'></div>
            <?php    
			return ob_get_clean();
            
        }
    }
    
}

$map_box = new MapBoxMarker();
add_action('wp_enqueue_scripts', array($map_box, 'map_box_scripts',));
add_action('wp_enqueue_scripts', array($map_box,'map_box_override_stylesheets',));
add_shortcode('map_box', array($map_box, 'map_box_shortcode',));


