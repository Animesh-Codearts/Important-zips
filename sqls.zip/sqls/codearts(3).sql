-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 20, 2022 at 08:07 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codearts`
--

-- --------------------------------------------------------

--
-- Table structure for table `capms_admin_leave`
--

CREATE TABLE `capms_admin_leave` (
  `leave_ID` int(11) NOT NULL,
  `user_empid` varchar(255) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_dept` varchar(255) NOT NULL,
  `user_reason` varchar(255) NOT NULL,
  `user_ldate` varchar(255) NOT NULL,
  `user_time` varchar(255) NOT NULL,
  `user_rdate` varchar(255) NOT NULL,
  `no_of_leave_days` varchar(255) NOT NULL,
  `created_at` varchar(255) CHARACTER SET latin1 NOT NULL,
  `updated_at` varchar(255) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `capms_admin_leave`
--

INSERT INTO `capms_admin_leave` (`leave_ID`, `user_empid`, `user_fullname`, `user_dept`, `user_reason`, `user_ldate`, `user_time`, `user_rdate`, `no_of_leave_days`, `created_at`, `updated_at`) VALUES
(3, 'john-doe-4231', 'John Doe', 'Backend Developer', 'Vacation', '2022-05-16', '', '2022-05-20', '5', '', ''),
(5, 'john-doe-4231', 'John Doe', 'Backend Developer', 'Jury Duty', '2022-04-22', '01:22', '2022-04-25', '3', '', ''),
(6, 'john-doe-4231', 'Animesh Das', 'Backend Developer', 'Natural Calamity', '2022-05-16', '10:15', '2022-05-17', '1', '', ''),
(7, 'john-doe-4231', 'Animesh Das', 'Backend Developer', 'Funeral', '2022-05-16', '10:15', '2022-05-17', '1', '', ''),
(8, 'john-doe-4231', 'John Doe', 'Junior-Designer', 'Doctor Appointment', '2022-05-17', '17:13', '2022-05-19', '2', '', ''),
(15, 'axel-rose-3079', '', 'Senior-Designer', 'Vacation', '2022-05-23', '03:56', '2022-05-24', '1', '', ''),
(16, 'axel-rose-3079', '', 'Senior-Designer', 'Leave of Absence', '2022-02-24', '17:50', '2022-02-25', '1', '', ''),
(17, 'john-doe-4231', '', 'Junior-Designer', 'Natural Calamity', '2022-06-19', '10:10', '2022-06-21', '2', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `capms_admin_leave1`
--

CREATE TABLE `capms_admin_leave1` (
  `leave_ID` int(11) NOT NULL,
  `user_empid` int(4) NOT NULL,
  `user_designation` varchar(255) NOT NULL,
  `user_reason` varchar(255) NOT NULL,
  `user_ldate` varchar(255) NOT NULL,
  `user_rdate` varchar(255) NOT NULL,
  `leave_type` varchar(10) NOT NULL,
  `no_of_leave_days` varchar(5) NOT NULL,
  `balance_leave` varchar(5) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `capms_admin_project`
--

CREATE TABLE `capms_admin_project` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_description` varchar(255) NOT NULL,
  `project_priority` varchar(30) NOT NULL,
  `project_team` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `project_status` varchar(30) NOT NULL,
  `project_progress` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `capms_admin_project`
--

INSERT INTO `capms_admin_project` (`project_id`, `project_name`, `project_description`, `project_priority`, `project_team`, `start_date`, `end_date`, `project_status`, `project_progress`, `created_at`, `updated_at`) VALUES
(1, 'XYZ', '\r\n\r\nXYZ COMPANY\r\n', 'Medium', 'animesh', '2022-07-21', '2022-07-23', '40%', 'ongoing', '2022-07-19 02:00:15', '2022-07-19 02:00:15'),
(2, 'ABC', '\r\n\r\nTestCompany\r\n', 'Medium', 'testing', '2022-07-19', '2022-07-23', '40%', 'ongoing', '2022-07-19 02:12:26', '2022-07-19 02:12:26'),
(3, 'XYZ', '\r\n\r\nxcxzzxcasfasdas\r\n', 'High', 'Angular', '2022-07-20', '2022-07-23', '40%', 'ongoing', '2022-07-19 03:15:20', '2022-07-19 03:15:20');

-- --------------------------------------------------------

--
-- Table structure for table `capms_admin_timing`
--

CREATE TABLE `capms_admin_timing` (
  `dol_id` int(11) NOT NULL,
  `leave_id` int(11) NOT NULL,
  `leave_date` varchar(255) NOT NULL,
  `return_date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `capms_admin_users`
--

CREATE TABLE `capms_admin_users` (
  `id` int(4) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_empid` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_contact` varchar(255) NOT NULL,
  `user_joining_date` varchar(255) NOT NULL,
  `user_featured_image` varchar(255) NOT NULL,
  `user_salary` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_designation` varchar(255) NOT NULL,
  `user_dob` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_gender` varchar(255) NOT NULL,
  `reports_to_uid` varchar(25) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `capms_admin_users`
--

INSERT INTO `capms_admin_users` (`id`, `user_type`, `user_fullname`, `user_empid`, `user_email`, `user_contact`, `user_joining_date`, `user_featured_image`, `user_salary`, `user_password`, `user_designation`, `user_dob`, `user_address`, `user_gender`, `reports_to_uid`, `created_at`, `updated_at`) VALUES
(3, 'admin', 'John Doe', 'john-doe-4231', 'john_doe@gmail.com', '9876543210', '2022-01-03', '1647846364-john_doe.jpg', '10000.00', '21232f297a57a5a743894a0e4a801fc3', 'Junior-Designer', '1996-07-17', '123 ABC, Demo Address', '', '', '2022-02-25 04:38:23', '2022-05-19 10:48:08'),
(4, 'admin', 'Axel Rose', 'axel-rose-3079', 'axel_rose@gmail.com', '9785462130', '2022-01-03', '1645857309-axel_rose.jpg', '9500.00', '21232f297a57a5a743894a0e4a801fc3', 'Senior-Designer', '2021-07-08', 'demo address in kolkata', 'Male', 'aniket-das-9977', '2022-02-26 12:05:09', '2022-05-24 10:51:45'),
(5, 'hr', 'Britney Adams', 'britney-adams-8321', 'britney_adams@gmail.com', '9632587410', '2022-01-10', '1648202248-britney_adams.png', '10500.00', '21232f297a57a5a743894a0e4a801fc3', '', '', '', '', '', '2022-03-25 03:27:28', '2022-05-24 11:12:55'),
(6, 'employee', 'Martin Fonsy', 'martin-fonsy-5693', 'martin_fonsy@gmail.com', '9512347806', '2022-03-15', '1649148047-martin_fonsy.png', '8500.00', '21232f297a57a5a743894a0e4a801fc3', '', '', '', '', '', '2022-04-05 02:10:47', '2022-04-05 02:10:47'),
(7, 'employee', 'Jackson Holder', 'jackson-holder-6639', 'jackson_holder@gmail.com', '9871230546', '2022-02-21', '1649148220-jackson_holder.png', '9000.00', '21232f297a57a5a743894a0e4a801fc3', '', '', '', '', '', '2022-04-05 02:13:40', '2022-04-05 02:13:40'),
(8, 'employee', 'Subhankar Paul', 'subhankar-paul-2496', 'codearts.subhankar@gmail.com', '9674291776', '2021-06-01', '1651472077-subhankar_paul.JPG', '10000.00', '6c15128164d3ba3f10e642f16f031388', '', '', '', '', '', '2022-05-02 11:44:37', '2022-05-02 11:50:17'),
(9, 'employee', 'Dipan Das', 'dipan-das-7619', 'dipan.codearts@gmail.com', '8296747440', '1995-02-22', '1651472134-1646375260646.JPEG', '', '52899eeec83d813844272230873e34b5', '', '', '', '', '', '2022-05-02 11:45:34', '2022-05-02 11:45:34'),
(10, 'hr', 'Aniket Das', 'aniket-das-9977', 'hraniket.codearts@gmail.com', '7044246756', '1998-07-03', '1651472400-1649842249496.jpg', '', '5dcb7eccdf8842db00008a2db6b5218e', '', '', '', '', '', '2022-05-02 11:50:00', '2022-05-02 11:50:00'),
(11, 'employee', 'Pritam Sen', 'pritam-sen-5289', 'pritam.codearts@gmail.com', '6289570039', '1998-07-14', '1651472934-Screenshot_1.png', '20,000', '9e2b6183f135f2d401931bc9159e0d73', '', '', '', '', '', '2022-05-02 11:58:54', '2022-05-02 11:58:54'),
(12, 'employee', 'Swagata Bose', 'swagata-bose-3537', 'swagata.codearts@gmail.com', '8961219180', '1995-06-19', '1651473044-IMG_20220205_124048_823.webp', '', '177da57035b03c2eb2cbe9b872348d15', '', '', '', '', '', '2022-05-02 12:00:44', '2022-05-02 12:00:44'),
(13, 'employee', 'Anakshi Dhar', 'anakshi-dhar-5844', 'anakshi.codearts@gmail.com', '8420332725', '1990-04-09', '1651473192-Anakshi Dhar.png', '8500', 'ecada7a82947803b5f624c9a86f8b8f6', '', '', '', '', '', '2022-05-02 12:03:12', '2022-05-02 12:03:12'),
(14, 'employee', 'Rahul Yadav', 'rahul-yadav-6500', 'rahul.codearts@gmail.com', '9143116017', '1986-12-19', '1651473647-IMG-20220103-WA0002.jpg', '', '7b7f71bff78951c020e9c647a32bb839', '', '', '', '', '', '2022-05-02 12:10:47', '2022-05-02 12:10:47'),
(15, 'employee', 'Ajoy Biswas', 'ajoy-biswas-1163', 'ajay.codearts@gmail.com', '6289000843', '2022-05-02', '1651473652-1646374712102.JPEG', '20000', 'a08ee45ef214dc905e59bfcc4c263565', '', '', '', '', '', '2022-05-02 12:10:52', '2022-05-02 12:10:52'),
(16, '', 'Saraswata Tripathi', 'saraswata-tripathi-6566', 'saraswat.codearts@gmail.com', '9734261014', '2021-12-06', '1652786338-papai.jpg', '8000', '42257268860ba671cd9361fb97d83357', 'Junior-Backend Developer', '2022-05-10', 'demo address, india,earth', 'Male', 'dipan-das-7619', '2022-05-17 04:48:58', '2022-05-26 12:32:19');

-- --------------------------------------------------------

--
-- Table structure for table `capms_login_information`
--

CREATE TABLE `capms_login_information` (
  `id` int(4) NOT NULL,
  `user_id` int(4) NOT NULL,
  `login_date` varchar(255) NOT NULL,
  `login_time` varchar(255) NOT NULL,
  `logout_time` varchar(255) NOT NULL,
  `lunch_break_start` varchar(255) NOT NULL,
  `lunch_break_end` varchar(255) NOT NULL,
  `eve_break_start` varchar(255) NOT NULL,
  `eve_break_end` varchar(255) NOT NULL,
  `working_hours` varchar(255) NOT NULL,
  `break_duration` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `capms_login_information`
--

INSERT INTO `capms_login_information` (`id`, `user_id`, `login_date`, `login_time`, `logout_time`, `lunch_break_start`, `lunch_break_end`, `eve_break_start`, `eve_break_end`, `working_hours`, `break_duration`) VALUES
(1, 4, '02-03-2022', '05-53-46', '', '', '', '', '', '', ''),
(2, 4, '03-03-2022', '03-29-04', '', '', '', '', '', '', ''),
(3, 3, '03-03-2022', '03-29-10', '', '', '', '', '', '', ''),
(4, 4, '08-03-2022', '04-04-16', '', '', '', '', '', '', ''),
(5, 3, '08-03-2022', '04-04-40', '', '', '', '', '', '', ''),
(6, 4, '09-03-2022', '01-57-04', '', '', '', '', '', '', ''),
(7, 3, '09-03-2022', '04-35-30', '', '', '', '', '', '', ''),
(8, 3, '21-03-2022', '11-57-36', '', '', '', '', '', '', ''),
(9, 3, '25-03-2022', '11-51-02', '', '', '', '', '', '', ''),
(10, 4, '25-03-2022', '02-45-02', '', '', '', '', '', '', ''),
(11, 5, '25-03-2022', '04-16-53', '', '', '', '', '', '', ''),
(12, 3, '26-03-2022', '12-46-33', '', '', '', '', '', '', ''),
(13, 5, '26-03-2022', '12-46-40', '', '', '', '', '', '', ''),
(14, 6, '05-04-2022', '02-10-54', '', '', '', '', '', '', ''),
(15, 7, '05-04-2022', '02-13-47', '', '', '', '', '', '', ''),
(16, 5, '05-04-2022', '02-18-16', '', '', '', '', '', '', ''),
(17, 5, '08-04-2022', '11-12-32', '', '', '', '', '', '', ''),
(18, 5, '12-04-2022', '12-50-24', '03-39-08', '', '', '', '', '', ''),
(19, 5, '13-04-2022', '11-14-23', '17-41-57', '', '', '', '', '', ''),
(20, 7, '13-04-2022', '05-53-50', '', '', '', '', '', '', ''),
(21, 5, '14-04-2022', '11-50-23', '15-59-18', '15-57-10', '15-58-23', '', '', '', ''),
(22, 7, '14-04-2022', '11-50-30', '', '15-23-37', '15-29-08', '', '', '', ''),
(23, 5, '18-04-2022', '12-46-31', '', '13:04 PM', '13:15 PM', '', '', '', ''),
(24, 7, '18-04-2022', '12-46-46', '', '13:14 PM', '13:14 PM', '', '', '', ''),
(25, 8, '02-05-2022', '11-44-44', '12-23-01', '12:16 PM', '12:16 PM', '', '', '', ''),
(26, 9, '02-05-2022', '11-45-46', '', '', '', '', '', '', ''),
(27, 10, '02-05-2022', '11-50-08', '11-55-27', '', '', '', '', '', ''),
(28, 5, '02-05-2022', '11-55-56', '', '', '', '', '', '', ''),
(29, 11, '02-05-2022', '11-59-00', '12-07-48', '', '', '', '', '', ''),
(30, 12, '02-05-2022', '12-01-04', '12-10-06', '', '', '', '', '', ''),
(31, 13, '02-05-2022', '12-04-14', '12-07-55', '', '', '', '', '', ''),
(32, 14, '02-05-2022', '12-11-00', '12-11-10', '12:16 PM', '12:17 PM', '', '', '', ''),
(33, 15, '02-05-2022', '12-11-12', '12-19-52', '', '', '', '', '', ''),
(34, 11, '04-05-2022', '10-19-20', '', '', '', '', '', '', ''),
(35, 12, '04-05-2022', '02-44-20', '', '', '', '', '', '', ''),
(36, 11, '05-05-2022', '10-23-31', '', '', '', '', '', '', ''),
(37, 11, '06-05-2022', '10-28-35', '', '', '', '', '', '', ''),
(38, 11, '09-05-2022', '11-05-14', '', '', '', '', '', '', ''),
(39, 16, '17-05-2022', '04-49-08', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `capms_admin_leave`
--
ALTER TABLE `capms_admin_leave`
  ADD PRIMARY KEY (`leave_ID`);

--
-- Indexes for table `capms_admin_leave1`
--
ALTER TABLE `capms_admin_leave1`
  ADD PRIMARY KEY (`leave_ID`);

--
-- Indexes for table `capms_admin_project`
--
ALTER TABLE `capms_admin_project`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `capms_admin_timing`
--
ALTER TABLE `capms_admin_timing`
  ADD PRIMARY KEY (`dol_id`);

--
-- Indexes for table `capms_admin_users`
--
ALTER TABLE `capms_admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `capms_login_information`
--
ALTER TABLE `capms_login_information`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `capms_admin_leave`
--
ALTER TABLE `capms_admin_leave`
  MODIFY `leave_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `capms_admin_leave1`
--
ALTER TABLE `capms_admin_leave1`
  MODIFY `leave_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `capms_admin_project`
--
ALTER TABLE `capms_admin_project`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `capms_admin_timing`
--
ALTER TABLE `capms_admin_timing`
  MODIFY `dol_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `capms_admin_users`
--
ALTER TABLE `capms_admin_users`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `capms_login_information`
--
ALTER TABLE `capms_login_information`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
