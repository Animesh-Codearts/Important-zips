-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 20, 2022 at 08:14 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sponner`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_cfs_sessions`
--

CREATE TABLE `wp_cfs_sessions` (
  `id` varchar(32) NOT NULL,
  `data` text DEFAULT NULL,
  `expires` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_cfs_sessions`
--

INSERT INTO `wp_cfs_sessions` (`id`, `data`, `expires`) VALUES
('0105d5d58faa36452b0fa309a97dec74', 'a:7:{s:7:\"post_id\";i:54;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205853'),
('06173962c8a423dac1f1831fdb695c8e', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655204392'),
('0bdafec998e7012f9da0efbfd8a05742', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655204411'),
('121fdc2ed08dbf135bbc6b725586e46f', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655202105'),
('17ec827385a6084380e874b564f2d2c5', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655215278'),
('289600e1030be924cffa230f25cd322f', 'a:7:{s:7:\"post_id\";i:54;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205790'),
('3511b30cd4c513e5206c25b2ef75ecbf', 'a:7:{s:7:\"post_id\";i:51;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205783'),
('3c10ff583480bbfb780b82ec652a2ba7', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655202180'),
('3e299b1b5b6e35c5b17fb0488ed70083', 'a:7:{s:7:\"post_id\";i:48;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205700'),
('3e89811a21496904d0f5de6ee9f23961', 'a:7:{s:7:\"post_id\";i:123;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:238;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655212034'),
('7abb92c115c28457ce1127b72ee06507', 'a:7:{s:7:\"post_id\";i:123;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:238;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655211685'),
('847ee5d72e699ef142b25c0e006887f1', 'a:7:{s:7:\"post_id\";i:51;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205721'),
('899632334ab87b31b156f95590926f3a', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655202022'),
('9d60c8c0ad2d8cc4b08616bf08b95a04', 'a:7:{s:7:\"post_id\";i:206;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205620'),
('9f3a8f0ab55390ddf51251ee833ff389', 'a:7:{s:7:\"post_id\";i:123;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:238;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655211837'),
('ac7bf19fb338db7b3a5c7b2b01a20222', 'a:7:{s:7:\"post_id\";i:206;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205525'),
('b6236037b653b9b5137f1a5c6c9b41ed', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655216071'),
('b865c705fe3e9b5ee76c8e4fe1fa3756', 'a:7:{s:7:\"post_id\";i:123;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:238;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655212030'),
('b9c5d958b80d56a050073707706e4cc8', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655215800'),
('c0ff531b295e39a0a904858667be4708', 'a:7:{s:7:\"post_id\";i:123;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:238;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655211709'),
('c1f27e69860234bb450911e83914c4c3', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655201847'),
('c5e000d986779a7e79b69763eb8a1618', 'a:7:{s:7:\"post_id\";i:123;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:238;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655211731'),
('c853fdf3f28879741d2d2294b333f9ff', 'a:7:{s:7:\"post_id\";i:48;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205643'),
('eeb485a2ca8e166217fd1801ff976272', 'a:7:{s:7:\"post_id\";i:54;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:221;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655205526'),
('f0589078ce3728d388ee91c2a4673926', 'a:7:{s:7:\"post_id\";i:10;s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:5:\"draft\";s:12:\"field_groups\";a:1:{i:0;i:205;}s:20:\"confirmation_message\";s:0:\"\";s:16:\"confirmation_url\";s:0:\"\";s:9:\"front_end\";b:0;}', '1655215271');

-- --------------------------------------------------------

--
-- Table structure for table `wp_cfs_values`
--

CREATE TABLE `wp_cfs_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `field_id` int(10) UNSIGNED DEFAULT NULL,
  `meta_id` int(10) UNSIGNED DEFAULT NULL,
  `post_id` int(10) UNSIGNED DEFAULT NULL,
  `base_field_id` int(10) UNSIGNED DEFAULT 0,
  `hierarchy` text DEFAULT NULL,
  `depth` int(10) UNSIGNED DEFAULT 0,
  `weight` int(10) UNSIGNED DEFAULT 0,
  `sub_weight` int(10) UNSIGNED DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_cfs_values`
--

INSERT INTO `wp_cfs_values` (`id`, `field_id`, `meta_id`, `post_id`, `base_field_id`, `hierarchy`, `depth`, `weight`, `sub_weight`) VALUES
(17, 6, 863, 206, 5, '5:0:6', 1, 0, 0),
(18, 6, 864, 206, 5, '5:1:6', 1, 1, 0),
(19, 6, 865, 206, 5, '5:2:6', 1, 2, 0),
(20, 6, 866, 206, 5, '5:3:6', 1, 3, 0),
(21, 6, 873, 48, 5, '5:0:6', 1, 0, 0),
(22, 6, 874, 48, 5, '5:1:6', 1, 1, 0),
(23, 6, 875, 48, 5, '5:2:6', 1, 2, 0),
(24, 6, 884, 51, 5, '5:0:6', 1, 0, 0),
(25, 6, 885, 51, 5, '5:1:6', 1, 1, 0),
(26, 6, 886, 51, 5, '5:2:6', 1, 2, 0),
(27, 6, 887, 51, 5, '5:3:6', 1, 3, 0),
(28, 6, 896, 54, 5, '5:0:6', 1, 0, 0),
(29, 6, 897, 54, 5, '5:1:6', 1, 1, 0),
(30, 6, 898, 54, 5, '5:2:6', 1, 2, 0),
(31, 6, 899, 54, 5, '5:3:6', 1, 3, 0),
(32, 8, 905, 123, 7, '7:0:8', 1, 0, 0),
(33, 9, 906, 123, 7, '7:0:9', 1, 0, 0),
(34, 8, 907, 123, 7, '7:1:8', 1, 1, 0),
(35, 9, 908, 123, 7, '7:1:9', 1, 1, 0),
(36, 8, 909, 123, 7, '7:2:8', 1, 2, 0),
(37, 9, 910, 123, 7, '7:2:9', 1, 2, 0),
(38, 8, 911, 123, 7, '7:3:8', 1, 3, 0),
(39, 9, 912, 123, 7, '7:3:9', 1, 3, 0),
(40, 8, 913, 123, 7, '7:4:8', 1, 4, 0),
(41, 9, 914, 123, 7, '7:4:9', 1, 4, 0),
(80, 2, 953, 10, 1, '1:0:2', 1, 0, 0),
(81, 4, 954, 10, 1, '1:0:3:0:4', 2, 0, 0),
(82, 2, 955, 10, 1, '1:1:2', 1, 1, 0),
(83, 4, 956, 10, 1, '1:1:3:0:4', 2, 0, 0),
(84, 4, 957, 10, 1, '1:1:3:1:4', 2, 1, 0),
(85, 2, 958, 10, 1, '1:2:2', 1, 2, 0),
(86, 4, 959, 10, 1, '1:2:3:0:4', 2, 0, 0),
(87, 2, 960, 10, 1, '1:3:2', 1, 3, 0),
(88, 4, 961, 10, 1, '1:3:3:0:4', 2, 0, 0),
(89, 2, 962, 10, 1, '1:4:2', 1, 4, 0),
(90, 4, 963, 10, 1, '1:4:3:0:4', 2, 0, 0),
(91, 2, 964, 10, 1, '1:5:2', 1, 5, 0),
(92, 4, 965, 10, 1, '1:5:3:0:4', 2, 0, 0),
(93, 2, 966, 10, 1, '1:6:2', 1, 6, 0),
(94, 4, 967, 10, 1, '1:6:3:0:4', 2, 0, 0),
(95, 2, 968, 10, 1, '1:7:2', 1, 7, 0),
(96, 4, 969, 10, 1, '1:7:3:0:4', 2, 0, 0),
(97, 2, 970, 10, 1, '1:8:2', 1, 8, 0),
(98, 4, 971, 10, 1, '1:8:3:0:4', 2, 0, 0),
(99, 4, 972, 10, 1, '1:8:3:1:4', 2, 1, 0),
(100, 4, 973, 10, 1, '1:8:3:2:4', 2, 2, 0),
(101, 2, 974, 10, 1, '1:9:2', 1, 9, 0),
(102, 4, 975, 10, 1, '1:9:3:0:4', 2, 0, 0),
(103, 2, 976, 10, 1, '1:10:2', 1, 10, 0),
(104, 4, 977, 10, 1, '1:10:3:0:4', 2, 0, 0),
(105, 4, 978, 10, 1, '1:10:3:1:4', 2, 1, 0),
(106, 2, 979, 10, 1, '1:11:2', 1, 11, 0),
(107, 4, 980, 10, 1, '1:11:3:0:4', 2, 0, 0),
(108, 2, 981, 10, 1, '1:12:2', 1, 12, 0),
(109, 4, 982, 10, 1, '1:12:3:0:4', 2, 0, 0),
(110, 4, 983, 10, 1, '1:12:3:1:4', 2, 1, 0),
(111, 2, 984, 10, 1, '1:13:2', 1, 13, 0),
(112, 4, 985, 10, 1, '1:13:3:0:4', 2, 0, 0),
(113, 4, 986, 10, 1, '1:13:3:1:4', 2, 1, 0),
(114, 2, 987, 10, 1, '1:14:2', 1, 14, 0),
(115, 4, 988, 10, 1, '1:14:3:0:4', 2, 0, 0),
(116, 4, 989, 10, 1, '1:14:3:1:4', 2, 1, 0),
(117, 4, 990, 10, 1, '1:14:3:2:4', 2, 2, 0),
(118, 2, 991, 10, 1, '1:15:2', 1, 15, 0),
(119, 4, 992, 10, 1, '1:15:3:0:4', 2, 0, 0),
(120, 4, 993, 10, 1, '1:15:3:1:4', 2, 1, 0),
(121, 4, 994, 10, 1, '1:15:3:2:4', 2, 2, 0),
(122, 2, 995, 10, 1, '1:16:2', 1, 16, 0),
(123, 4, 996, 10, 1, '1:16:3:0:4', 2, 0, 0),
(124, 2, 997, 10, 1, '1:17:2', 1, 17, 0),
(125, 4, 998, 10, 1, '1:17:3:0:4', 2, 0, 0),
(126, 4, 999, 10, 1, '1:17:3:1:4', 2, 1, 0),
(127, 4, 1000, 10, 1, '1:17:3:2:4', 2, 2, 0),
(128, 2, 1001, 10, 1, '1:18:2', 1, 18, 0),
(129, 4, 1002, 10, 1, '1:18:3:0:4', 2, 0, 0),
(130, 4, 1003, 10, 1, '1:18:3:1:4', 2, 1, 0),
(131, 2, 1004, 10, 1, '1:19:2', 1, 19, 0),
(132, 4, 1005, 10, 1, '1:19:3:0:4', 2, 0, 0),
(133, 4, 1006, 10, 1, '1:19:3:1:4', 2, 1, 0),
(134, 2, 1007, 10, 1, '1:20:2', 1, 20, 0),
(135, 4, 1008, 10, 1, '1:20:3:0:4', 2, 0, 0),
(136, 4, 1009, 10, 1, '1:20:3:1:4', 2, 1, 0),
(137, 4, 1010, 10, 1, '1:20:3:2:4', 2, 2, 0),
(138, 2, 1011, 10, 1, '1:21:2', 1, 21, 0),
(139, 4, 1012, 10, 1, '1:21:3:0:4', 2, 0, 0),
(140, 2, 1013, 10, 1, '1:22:2', 1, 22, 0),
(141, 4, 1014, 10, 1, '1:22:3:0:4', 2, 0, 0),
(142, 4, 1015, 10, 1, '1:22:3:1:4', 2, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-06-10 12:06:56', '2022-06-10 12:06:56', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://en.gravatar.com/\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/sponner', 'yes'),
(2, 'home', 'http://localhost/sponner', 'yes'),
(3, 'blogname', 'Architektur Marianne Sponner', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'Animesh.codearts@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:178:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:9:\"banner/?$\";s:30:\"index.php?post_type=cpt_banner\";s:39:\"banner/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=cpt_banner&feed=$matches[1]\";s:34:\"banner/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=cpt_banner&feed=$matches[1]\";s:26:\"banner/page/([0-9]{1,})/?$\";s:48:\"index.php?post_type=cpt_banner&paged=$matches[1]\";s:12:\"portfolio/?$\";s:33:\"index.php?post_type=cpt_portfolio\";s:42:\"portfolio/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_type=cpt_portfolio&feed=$matches[1]\";s:37:\"portfolio/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_type=cpt_portfolio&feed=$matches[1]\";s:29:\"portfolio/page/([0-9]{1,})/?$\";s:51:\"index.php?post_type=cpt_portfolio&paged=$matches[1]\";s:11:\"timeline/?$\";s:32:\"index.php?post_type=cpt_timeline\";s:41:\"timeline/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?post_type=cpt_timeline&feed=$matches[1]\";s:36:\"timeline/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?post_type=cpt_timeline&feed=$matches[1]\";s:28:\"timeline/page/([0-9]{1,})/?$\";s:50:\"index.php?post_type=cpt_timeline&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:31:\"cfs/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"cfs/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"cfs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"cfs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"cfs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"cfs/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:20:\"cfs/([^/]+)/embed/?$\";s:51:\"index.php?post_type=cfs&name=$matches[1]&embed=true\";s:24:\"cfs/([^/]+)/trackback/?$\";s:45:\"index.php?post_type=cfs&name=$matches[1]&tb=1\";s:32:\"cfs/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?post_type=cfs&name=$matches[1]&paged=$matches[2]\";s:39:\"cfs/([^/]+)/comment-page-([0-9]{1,})/?$\";s:58:\"index.php?post_type=cfs&name=$matches[1]&cpage=$matches[2]\";s:28:\"cfs/([^/]+)(?:/([0-9]+))?/?$\";s:57:\"index.php?post_type=cfs&name=$matches[1]&page=$matches[2]\";s:20:\"cfs/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:30:\"cfs/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:50:\"cfs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\"cfs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\"cfs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:26:\"cfs/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:34:\"banner/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"banner/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"banner/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"banner/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"banner/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"banner/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:23:\"banner/([^/]+)/embed/?$\";s:43:\"index.php?cpt_banner=$matches[1]&embed=true\";s:27:\"banner/([^/]+)/trackback/?$\";s:37:\"index.php?cpt_banner=$matches[1]&tb=1\";s:47:\"banner/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?cpt_banner=$matches[1]&feed=$matches[2]\";s:42:\"banner/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?cpt_banner=$matches[1]&feed=$matches[2]\";s:35:\"banner/([^/]+)/page/?([0-9]{1,})/?$\";s:50:\"index.php?cpt_banner=$matches[1]&paged=$matches[2]\";s:42:\"banner/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?cpt_banner=$matches[1]&cpage=$matches[2]\";s:31:\"banner/([^/]+)(?:/([0-9]+))?/?$\";s:49:\"index.php?cpt_banner=$matches[1]&page=$matches[2]\";s:23:\"banner/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:33:\"banner/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:53:\"banner/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"banner/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"banner/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:29:\"banner/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:37:\"portfolio/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:47:\"portfolio/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:67:\"portfolio/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"portfolio/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"portfolio/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:43:\"portfolio/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:26:\"portfolio/([^/]+)/embed/?$\";s:46:\"index.php?cpt_portfolio=$matches[1]&embed=true\";s:30:\"portfolio/([^/]+)/trackback/?$\";s:40:\"index.php?cpt_portfolio=$matches[1]&tb=1\";s:50:\"portfolio/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?cpt_portfolio=$matches[1]&feed=$matches[2]\";s:45:\"portfolio/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?cpt_portfolio=$matches[1]&feed=$matches[2]\";s:38:\"portfolio/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?cpt_portfolio=$matches[1]&paged=$matches[2]\";s:45:\"portfolio/([^/]+)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?cpt_portfolio=$matches[1]&cpage=$matches[2]\";s:34:\"portfolio/([^/]+)(?:/([0-9]+))?/?$\";s:52:\"index.php?cpt_portfolio=$matches[1]&page=$matches[2]\";s:26:\"portfolio/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:36:\"portfolio/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:56:\"portfolio/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"portfolio/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"portfolio/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\"portfolio/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"timeline/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"timeline/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"timeline/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"timeline/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"timeline/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"timeline/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"timeline/([^/]+)/embed/?$\";s:45:\"index.php?cpt_timeline=$matches[1]&embed=true\";s:29:\"timeline/([^/]+)/trackback/?$\";s:39:\"index.php?cpt_timeline=$matches[1]&tb=1\";s:49:\"timeline/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?cpt_timeline=$matches[1]&feed=$matches[2]\";s:44:\"timeline/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?cpt_timeline=$matches[1]&feed=$matches[2]\";s:37:\"timeline/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?cpt_timeline=$matches[1]&paged=$matches[2]\";s:44:\"timeline/([^/]+)/comment-page-([0-9]{1,})/?$\";s:52:\"index.php?cpt_timeline=$matches[1]&cpage=$matches[2]\";s:33:\"timeline/([^/]+)(?:/([0-9]+))?/?$\";s:51:\"index.php?cpt_timeline=$matches[1]&page=$matches[2]\";s:25:\"timeline/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\"timeline/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\"timeline/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"timeline/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"timeline/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:31:\"timeline/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=6&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";i:2;s:33:\"classic-editor/classic-editor.php\";i:3;s:35:\"classic-widgets/classic-widgets.php\";i:4;s:36:\"contact-form-7/wp-contact-form-7.php\";i:5;s:26:\"custom-field-suite/cfs.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'sponner', 'yes'),
(41, 'stylesheet', 'sponner', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '51917', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1670414816', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '1', 'no'),
(103, 'widget_block', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:4:{s:9:\"sidebar-1\";a:1:{i:0;s:10:\"nav_menu-2\";}s:19:\"wp_inactive_widgets\";a:0:{}s:11:\"footer-menu\";a:1:{i:0;s:10:\"nav_menu-3\";}s:13:\"array_version\";i:3;}', 'yes'),
(105, 'cron', 'a:6:{i:1655813217;a:6:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1655813223;a:3:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1655813224;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1655817113;a:1:{s:21:\"ai1wm_storage_cleanup\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1656158817;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:3:{i:2;a:1:{s:8:\"nav_menu\";i:3;}i:3;a:1:{s:8:\"nav_menu\";i:3;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(122, 'theme_mods_twentytwentytwo', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1654862880;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(125, 'https_detection_errors', 'a:2:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}s:19:\"bad_response_source\";a:1:{i:0;s:55:\"It looks like the response did not come from this site.\";}}', 'yes'),
(126, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.0.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.0.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-6.0-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-6.0-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"6.0\";s:7:\"version\";s:3:\"6.0\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1655797910;s:15:\"version_checked\";s:3:\"6.0\";s:12:\"translations\";a:0:{}}', 'no'),
(131, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1655797912;s:7:\"checked\";a:2:{s:7:\"sponner\";s:3:\"1.5\";s:15:\"twentytwentyone\";s:3:\"1.6\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:1:{s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.6.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(137, 'can_compress_scripts', '1', 'no'),
(150, 'current_theme', 'sponner', 'yes'),
(151, 'theme_mods_twentytwentyone', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1654865251;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(152, 'theme_switched', '', 'yes'),
(155, 'finished_updating_comment_type', '1', 'yes'),
(157, 'theme_mods_sponner', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:6:\"footer\";i:3;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1654863088;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(160, 'theme_mods_spooner', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1654865237;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}}}}', 'yes'),
(173, 'recovery_mode_email_last_sent', '1655104878', 'yes'),
(178, 'recently_activated', 'a:1:{s:30:\"cool-timeline/cooltimeline.php\";i:1655185692;}', 'yes'),
(187, 'wpcf7', 'a:2:{s:7:\"version\";s:7:\"5.5.6.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1654865385;s:7:\"version\";s:7:\"5.5.6.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(190, 'acf_version', '5.12.2', 'yes'),
(199, '_transient_health-check-site-status-result', '{\"good\":16,\"recommended\":3,\"critical\":0}', 'yes'),
(283, 'title', 'Architektur::Marianne Sponner', 'yes'),
(284, 'logo', 'http://localhost/sponner/wp-content/uploads/2022/06/logo-1.png', 'yes'),
(285, 'messages', 'Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.', 'yes'),
(286, 'address', 'Dipl.-Ing. (FH) Marianne Sponner Vordere Seestraße 33 82237 Wörthsee', 'yes'),
(287, 'consult_number', '08143 99 98 71', 'yes'),
(288, 'email', 'marianne@sponner.de', 'yes'),
(293, 'copyright', 'Architekturbüro Marianne Sponner - Alle Rechte vorbehalten', 'yes'),
(310, 'category_children', 'a:0:{}', 'yes'),
(325, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(459, 'cool-free-timeline-v', '2.4.4', 'yes'),
(460, 'cool-timelne-plugin-type', 'FREE', 'yes'),
(461, 'cool-timelne-installDate', '2022-06-14 05:12:47', 'yes'),
(462, 'cool-timeline-already-rated', 'no', 'yes'),
(464, 'cool_timeline_settings', 'a:18:{s:15:\"timeline_header\";s:0:\"\";s:22:\"story_content_settings\";s:0:\"\";s:19:\"story_date_settings\";s:0:\"\";s:20:\"first_story_position\";s:5:\"right\";s:19:\"timeline_background\";b:0;s:17:\"timeline_bg_color\";s:7:\"#ffbc00\";s:16:\"content_bg_color\";s:7:\"#ffffff\";s:19:\"circle_border_color\";s:7:\"#38aab7\";s:10:\"line_color\";s:7:\"#025149\";s:10:\"first_post\";s:7:\"#29b246\";s:11:\"second_post\";s:7:\"#ce792f\";s:13:\"custom_styles\";s:0:\"\";s:9:\"title_tag\";s:2:\"h2\";s:15:\"main_title_typo\";a:7:{s:11:\"font-family\";s:9:\"Maven Pro\";s:9:\"font-size\";s:2:\"22\";s:11:\"line-height\";s:0:\"\";s:4:\"unit\";s:2:\"px\";s:4:\"type\";s:6:\"google\";s:10:\"text-align\";s:6:\"center\";s:11:\"font-weight\";s:3:\"700\";}s:13:\"ctl_date_typo\";a:6:{s:11:\"font-family\";s:9:\"Maven Pro\";s:9:\"font-size\";s:2:\"21\";s:11:\"line-height\";s:0:\"\";s:4:\"unit\";s:2:\"px\";s:4:\"type\";s:6:\"google\";s:11:\"font-weight\";s:3:\"700\";}s:15:\"post_title_typo\";a:6:{s:11:\"font-family\";s:9:\"Maven Pro\";s:9:\"font-size\";s:2:\"20\";s:11:\"line-height\";s:0:\"\";s:4:\"unit\";s:2:\"px\";s:4:\"type\";s:6:\"google\";s:11:\"font-weight\";s:3:\"700\";}s:17:\"post_content_typo\";a:5:{s:11:\"font-family\";s:9:\"Maven Pro\";s:9:\"font-size\";s:2:\"16\";s:11:\"line-height\";s:0:\"\";s:4:\"unit\";s:2:\"px\";s:4:\"type\";s:6:\"google\";}s:17:\"advanced-features\";s:0:\"\";}', 'yes'),
(465, 'ctl-upgraded', 'yes', 'yes'),
(468, 'cool-plugins-timeline-addon-timeline', 'a:3:{s:13:\"cool-timeline\";a:7:{s:4:\"name\";s:13:\"Cool Timeline\";s:4:\"logo\";s:66:\"https://ps.w.org/cool-timeline/assets/icon-128x128.png?rev=2297699\";s:4:\"slug\";s:13:\"cool-timeline\";s:4:\"desc\";s:142:\"Cool Timeline WordPress plugin creates vertical and horizontal history timeline blocks in ASC or DESC order based on year and date of stories.\";s:7:\"version\";s:5:\"2.4.4\";s:4:\"tags\";O:8:\"stdClass\":5:{s:14:\"event-timeline\";s:14:\"event timeline\";s:6:\"events\";s:6:\"events\";s:7:\"history\";s:7:\"history\";s:7:\"roadmap\";s:7:\"roadmap\";s:8:\"timeline\";s:8:\"timeline\";}s:13:\"download_link\";s:62:\"https://downloads.wordpress.org/plugin/cool-timeline.2.4.4.zip\";}s:35:\"timeline-widget-addon-for-elementor\";a:7:{s:4:\"name\";s:31:\"Elementor Timeline Widget Addon\";s:4:\"logo\";s:88:\"https://ps.w.org/timeline-widget-addon-for-elementor/assets/icon-128x128.png?rev=2336624\";s:4:\"slug\";s:35:\"timeline-widget-addon-for-elementor\";s:4:\"desc\";s:102:\"Elementor timeline widget addon will showcase your company history or life story in a vertical&hellip;\";s:7:\"version\";s:5:\"1.3.5\";s:4:\"tags\";O:8:\"stdClass\":5:{s:9:\"elementor\";s:9:\"elementor\";s:15:\"elementor-addon\";s:15:\"elementor addon\";s:18:\"elementor-timeline\";s:18:\"elementor timeline\";s:17:\"elementor-widgets\";s:17:\"elementor widgets\";s:8:\"timeline\";s:8:\"timeline\";}s:13:\"download_link\";s:78:\"https://downloads.wordpress.org/plugin/timeline-widget-addon-for-elementor.zip\";}s:14:\"timeline-block\";a:7:{s:4:\"name\";s:28:\"Timeline Block For Gutenberg\";s:4:\"logo\";s:67:\"https://ps.w.org/timeline-block/assets/icon-128x128.png?rev=2365707\";s:4:\"slug\";s:14:\"timeline-block\";s:4:\"desc\";s:112:\"Showcase your story or company history,events,process steps and Roadmap in precise and elegant way using&hellip;\";s:7:\"version\";s:5:\"1.2.1\";s:4:\"tags\";O:8:\"stdClass\":5:{s:16:\"company-timeline\";s:16:\"company timeline\";s:9:\"gutenberg\";s:9:\"gutenberg\";s:7:\"history\";s:7:\"history\";s:7:\"roadmap\";s:7:\"roadmap\";s:8:\"timeline\";s:8:\"timeline\";}s:13:\"download_link\";s:57:\"https://downloads.wordpress.org/plugin/timeline-block.zip\";}}', 'yes'),
(485, 'cfs_next_field_id', '10', 'yes'),
(486, 'cfs_version', '2.6.2', 'yes'),
(649, '_site_transient_timeout_browser_276137e981fb49f45b6f0086f2d67529', '1655816456', 'no'),
(650, '_site_transient_browser_276137e981fb49f45b6f0086f2d67529', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:5:\"101.0\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:32:\"https://www.mozilla.org/firefox/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(658, 'ai1wm_secret_key', 'gbYjD8856pGj', 'yes'),
(659, 'ai1wm_status', 'a:2:{s:4:\"type\";s:8:\"download\";s:7:\"message\";s:307:\"<a href=\"https://localhost/sponner/wp-content/ai1wm-backups/localhost-sponner-20220614-131203-003g5m.wpress\" class=\"ai1wm-button-green ai1wm-emphasize ai1wm-button-download\" title=\"localhost\" download=\"localhost-sponner-20220614-131203-003g5m.wpress\"><span>Download localhost</span><em>Size: 101 MB</em></a>\";}', 'yes'),
(664, '_site_transient_ai1wm_last_check_for_updates', '1655797911', 'no'),
(665, 'ai1wm_updater', 'a:0:{}', 'yes'),
(666, '_site_transient_timeout_theme_roots', '1655799711', 'no'),
(667, '_site_transient_theme_roots', 'a:2:{s:7:\"sponner\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}', 'no'),
(668, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1655797913;s:8:\"response\";a:1:{s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:3:\"5.6\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/contact-form-7.5.6.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.9\";s:6:\"tested\";s:3:\"6.0\";s:12:\"requires_php\";b:0;}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:6:\"5.12.2\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.12.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.2.4\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.2.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";}s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:37:\"w.org/plugins/all-in-one-wp-migration\";s:4:\"slug\";s:23:\"all-in-one-wp-migration\";s:6:\"plugin\";s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";s:11:\"new_version\";s:4:\"7.61\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/all-in-one-wp-migration/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/all-in-one-wp-migration.7.61.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/all-in-one-wp-migration/assets/icon-256x256.png?rev=2458334\";s:2:\"1x\";s:76:\"https://ps.w.org/all-in-one-wp-migration/assets/icon-128x128.png?rev=2458334\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/all-in-one-wp-migration/assets/banner-1544x500.png?rev=2693719\";s:2:\"1x\";s:78:\"https://ps.w.org/all-in-one-wp-migration/assets/banner-772x250.png?rev=2693719\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.3\";}s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:5:\"1.6.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/classic-editor.1.6.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1998671\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1998671\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1998671\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1998676\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";}s:35:\"classic-widgets/classic-widgets.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:29:\"w.org/plugins/classic-widgets\";s:4:\"slug\";s:15:\"classic-widgets\";s:6:\"plugin\";s:35:\"classic-widgets/classic-widgets.php\";s:11:\"new_version\";s:3:\"0.3\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/classic-widgets/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/classic-widgets.0.3.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:59:\"https://s.w.org/plugins/geopattern-icon/classic-widgets.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";}s:26:\"custom-field-suite/cfs.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:32:\"w.org/plugins/custom-field-suite\";s:4:\"slug\";s:18:\"custom-field-suite\";s:6:\"plugin\";s:26:\"custom-field-suite/cfs.php\";s:11:\"new_version\";s:5:\"2.6.2\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/custom-field-suite/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/custom-field-suite.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/custom-field-suite/assets/icon-256x256.png?rev=1112866\";s:2:\"1x\";s:71:\"https://ps.w.org/custom-field-suite/assets/icon-128x128.png?rev=1112866\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/hello-dolly/assets/banner-1544x500.jpg?rev=2645582\";s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}}s:7:\"checked\";a:8:{s:30:\"advanced-custom-fields/acf.php\";s:6:\"5.12.2\";s:19:\"akismet/akismet.php\";s:5:\"4.2.4\";s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";s:4:\"7.61\";s:33:\"classic-editor/classic-editor.php\";s:5:\"1.6.2\";s:35:\"classic-widgets/classic-widgets.php\";s:3:\"0.3\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:7:\"5.5.6.1\";s:26:\"custom-field-suite/cfs.php\";s:5:\"2.6.2\";s:9:\"hello.php\";s:5:\"1.7.2\";}}', 'no'),
(669, '_site_transient_timeout_php_check_653b16e6c5979ac325fae9f9db6a18fe', '1656402715', 'no'),
(670, '_site_transient_php_check_653b16e6c5979ac325fae9f9db6a18fe', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(679, '_transient_timeout_global_styles_svg_filters_sponner', '1655810574', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(680, '_transient_global_styles_svg_filters_sponner', '<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-dark-grayscale\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0 0.49803921568627\" /><feFuncG type=\"table\" tableValues=\"0 0.49803921568627\" /><feFuncB type=\"table\" tableValues=\"0 0.49803921568627\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-grayscale\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0 1\" /><feFuncG type=\"table\" tableValues=\"0 1\" /><feFuncB type=\"table\" tableValues=\"0 1\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-purple-yellow\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0.54901960784314 0.98823529411765\" /><feFuncG type=\"table\" tableValues=\"0 1\" /><feFuncB type=\"table\" tableValues=\"0.71764705882353 0.25490196078431\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-blue-red\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0 1\" /><feFuncG type=\"table\" tableValues=\"0 0.27843137254902\" /><feFuncB type=\"table\" tableValues=\"0.5921568627451 0.27843137254902\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-midnight\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0 0\" /><feFuncG type=\"table\" tableValues=\"0 0.64705882352941\" /><feFuncB type=\"table\" tableValues=\"0 1\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-magenta-yellow\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0.78039215686275 1\" /><feFuncG type=\"table\" tableValues=\"0 0.94901960784314\" /><feFuncB type=\"table\" tableValues=\"0.35294117647059 0.47058823529412\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-purple-green\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0.65098039215686 0.40392156862745\" /><feFuncG type=\"table\" tableValues=\"0 1\" /><feFuncB type=\"table\" tableValues=\"0.44705882352941 0.4\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 0 0\" width=\"0\" height=\"0\" focusable=\"false\" role=\"none\" style=\"visibility: hidden; position: absolute; left: -9999px; overflow: hidden;\" ><defs><filter id=\"wp-duotone-blue-orange\"><feColorMatrix color-interpolation-filters=\"sRGB\" type=\"matrix\" values=\" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 \" /><feComponentTransfer color-interpolation-filters=\"sRGB\" ><feFuncR type=\"table\" tableValues=\"0.098039215686275 1\" /><feFuncG type=\"table\" tableValues=\"0 0.66274509803922\" /><feFuncB type=\"table\" tableValues=\"0.84705882352941 0.41960784313725\" /><feFuncA type=\"table\" tableValues=\"1 1\" /></feComponentTransfer><feComposite in2=\"SourceGraphic\" operator=\"in\" /></filter></defs></svg>', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_form', '<label> Your name\n    [text* your-name] </label>\n\n<label> Your email\n    [email* your-email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit \"Submit\"]'),
(4, 5, '_mail', 'a:8:{s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:42:\"[_site_title] <Animesh.codearts@gmail.com>\";s:4:\"body\";s:163:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(5, 5, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:42:\"[_site_title] <Animesh.codearts@gmail.com>\";s:4:\"body\";s:105:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(6, 5, '_messages', 'a:12:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";}'),
(7, 5, '_additional_settings', ''),
(8, 5, '_locale', 'en_US'),
(9, 6, '_edit_last', '1'),
(10, 6, '_edit_lock', '1655203362:1'),
(11, 8, '_edit_last', '1'),
(12, 8, '_edit_lock', '1655187310:1'),
(13, 10, '_edit_last', '1'),
(14, 10, '_edit_lock', '1655202768:1'),
(15, 12, '_edit_last', '1'),
(16, 12, '_edit_lock', '1655182316:1'),
(17, 14, '_edit_last', '1'),
(18, 14, '_edit_lock', '1655211173:1'),
(19, 19, '_edit_last', '1'),
(20, 19, '_edit_lock', '1655204341:1'),
(21, 20, '_wp_attached_file', '2022/06/s1.jpg'),
(22, 20, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:868;s:4:\"file\";s:14:\"2022/06/s1.jpg\";s:8:\"filesize\";i:141649;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"s1-300x136.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:136;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8710;}s:5:\"large\";a:5:{s:4:\"file\";s:15:\"s1-1024x463.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:463;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:78553;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"s1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3835;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:14:\"s1-768x347.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:347;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:48115;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:15:\"s1-1536x694.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:694;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:153485;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:15:\"s1-1568x709.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:709;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:158749;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(23, 19, '_thumbnail_id', '20'),
(24, 19, 'main_heading', 'Architektur<br />Marianne Sponner'),
(25, 19, '_main_heading', 'field_62a6fb7c94fd4'),
(26, 19, 'sub_heading', 'Architektur und Energieberatung'),
(27, 19, '_sub_heading', 'field_62a6fb9294fd5'),
(28, 19, 'button_text', 'Kontaktieren Sie mich'),
(29, 19, '_button_text', 'field_62a6fbc294fd6'),
(30, 19, 'button_link', 'javascript:void(0)'),
(31, 19, '_button_link', 'field_62a6fbd494fd7'),
(32, 21, 'main_heading', 'Architektur<br />Marianne Sponner'),
(33, 21, '_main_heading', 'field_62a6fb7c94fd4'),
(34, 21, 'sub_heading', 'Architektur und Energieberatung'),
(35, 21, '_sub_heading', 'field_62a6fb9294fd5'),
(36, 21, 'button_text', 'Kontaktieren Sie mich'),
(37, 21, '_button_text', 'field_62a6fbc294fd6'),
(38, 21, 'button_link', 'javascript:void(0)'),
(39, 21, '_button_link', 'field_62a6fbd494fd7'),
(40, 22, '_edit_last', '1'),
(41, 22, '_edit_lock', '1655110641:1'),
(42, 23, '_wp_attached_file', '2022/06/s2.jpg'),
(43, 23, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:14:\"2022/06/s2.jpg\";s:8:\"filesize\";i:436502;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"s2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17842;}s:5:\"large\";a:5:{s:4:\"file\";s:15:\"s2-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:165949;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"s2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7584;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:14:\"s2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:98252;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:16:\"s2-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:339434;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:16:\"s2-1568x1045.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1045;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:352009;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(44, 22, '_thumbnail_id', '23'),
(45, 22, 'main_heading', 'Architektur<br />Marianne Sponner'),
(46, 22, '_main_heading', 'field_62a6fb7c94fd4'),
(47, 22, 'sub_heading', 'Architektur und Energieberatung'),
(48, 22, '_sub_heading', 'field_62a6fb9294fd5'),
(49, 22, 'button_text', 'Kontaktieren Sie mich'),
(50, 22, '_button_text', 'field_62a6fbc294fd6'),
(51, 22, 'button_link', 'javascript:void(0)'),
(52, 22, '_button_link', 'field_62a6fbd494fd7'),
(53, 24, 'main_heading', 'Architektur<br />Marianne Sponner'),
(54, 24, '_main_heading', 'field_62a6fb7c94fd4'),
(55, 24, 'sub_heading', 'Architektur und Energieberatung'),
(56, 24, '_sub_heading', 'field_62a6fb9294fd5'),
(57, 24, 'button_text', 'Kontaktieren Sie mich'),
(58, 24, '_button_text', 'field_62a6fbc294fd6'),
(59, 24, 'button_link', 'javascript:void(0)'),
(60, 24, '_button_link', 'field_62a6fbd494fd7'),
(61, 25, '_edit_last', '1'),
(62, 25, '_edit_lock', '1655110666:1'),
(63, 25, '_thumbnail_id', '20'),
(64, 25, 'main_heading', 'Architektur<br />Marianne Sponner'),
(65, 25, '_main_heading', 'field_62a6fb7c94fd4'),
(66, 25, 'sub_heading', 'Architektur und Energieberatung'),
(67, 25, '_sub_heading', 'field_62a6fb9294fd5'),
(68, 25, 'button_text', 'Kontaktieren Sie mich'),
(69, 25, '_button_text', 'field_62a6fbc294fd6'),
(70, 25, 'button_link', 'javascript:void(0)'),
(71, 25, '_button_link', 'field_62a6fbd494fd7'),
(72, 26, 'main_heading', 'Architektur<br />Marianne Sponner'),
(73, 26, '_main_heading', 'field_62a6fb7c94fd4'),
(74, 26, 'sub_heading', 'Architektur und Energieberatung'),
(75, 26, '_sub_heading', 'field_62a6fb9294fd5'),
(76, 26, 'button_text', 'Kontaktieren Sie mich'),
(77, 26, '_button_text', 'field_62a6fbc294fd6'),
(78, 26, 'button_link', 'javascript:void(0)'),
(79, 26, '_button_link', 'field_62a6fbd494fd7'),
(80, 27, '_edit_last', '1'),
(81, 27, '_edit_lock', '1655185808:1'),
(82, 27, '_thumbnail_id', '23'),
(83, 27, 'main_heading', 'Architektur<br />Marianne Sponner'),
(84, 27, '_main_heading', 'field_62a6fb7c94fd4'),
(85, 27, 'sub_heading', 'Architektur und Energieberatung'),
(86, 27, '_sub_heading', 'field_62a6fb9294fd5'),
(87, 27, 'button_text', 'Kontaktieren Sie mich'),
(88, 27, '_button_text', 'field_62a6fbc294fd6'),
(89, 27, 'button_link', 'javascript:void(0)'),
(90, 27, '_button_link', 'field_62a6fbd494fd7'),
(91, 28, 'main_heading', 'Architektur<br />Marianne Sponner'),
(92, 28, '_main_heading', 'field_62a6fb7c94fd4'),
(93, 28, 'sub_heading', 'Architektur und Energieberatung'),
(94, 28, '_sub_heading', 'field_62a6fb9294fd5'),
(95, 28, 'button_text', 'Kontaktieren Sie mich'),
(96, 28, '_button_text', 'field_62a6fbc294fd6'),
(97, 28, 'button_link', 'javascript:void(0)'),
(98, 28, '_button_link', 'field_62a6fbd494fd7'),
(99, 29, '_edit_last', '1'),
(100, 29, '_edit_lock', '1655125729:1'),
(101, 6, 'banner_sections_section_enabled', '1'),
(102, 6, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(103, 6, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(104, 6, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(105, 6, 'banner_sections', ''),
(106, 6, '_banner_sections', 'field_62a6fdf032a35'),
(107, 34, 'banner_sections_section_enabled', '1'),
(108, 34, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(109, 34, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(110, 34, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(111, 34, 'banner_sections', ''),
(112, 34, '_banner_sections', 'field_62a6fdf032a35'),
(113, 35, 'banner_sections_section_enabled', '1'),
(114, 35, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(115, 35, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(116, 35, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(117, 35, 'banner_sections', ''),
(118, 35, '_banner_sections', 'field_62a6fdf032a35'),
(119, 36, 'banner_sections_section_enabled', '0'),
(120, 36, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(121, 36, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(122, 36, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(123, 36, 'banner_sections', ''),
(124, 36, '_banner_sections', 'field_62a6fdf032a35'),
(125, 37, 'banner_sections_section_enabled', '1'),
(126, 37, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(127, 37, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(128, 37, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(129, 37, 'banner_sections', ''),
(130, 37, '_banner_sections', 'field_62a6fdf032a35'),
(131, 38, '_menu_item_type', 'post_type'),
(132, 38, '_menu_item_menu_item_parent', '0'),
(133, 38, '_menu_item_object_id', '12'),
(134, 38, '_menu_item_object', 'page'),
(135, 38, '_menu_item_target', ''),
(136, 38, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(137, 38, '_menu_item_xfn', ''),
(138, 38, '_menu_item_url', ''),
(139, 38, '_menu_item_orphaned', '1655112738'),
(140, 39, '_menu_item_type', 'post_type'),
(141, 39, '_menu_item_menu_item_parent', '0'),
(142, 39, '_menu_item_object_id', '10'),
(143, 39, '_menu_item_object', 'page'),
(144, 39, '_menu_item_target', ''),
(145, 39, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(146, 39, '_menu_item_xfn', ''),
(147, 39, '_menu_item_url', ''),
(149, 40, '_menu_item_type', 'post_type'),
(150, 40, '_menu_item_menu_item_parent', '0'),
(151, 40, '_menu_item_object_id', '8'),
(152, 40, '_menu_item_object', 'page'),
(153, 40, '_menu_item_target', ''),
(154, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(155, 40, '_menu_item_xfn', ''),
(156, 40, '_menu_item_url', ''),
(158, 41, '_menu_item_type', 'post_type'),
(159, 41, '_menu_item_menu_item_parent', '0'),
(160, 41, '_menu_item_object_id', '6'),
(161, 41, '_menu_item_object', 'page'),
(162, 41, '_menu_item_target', ''),
(163, 41, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(164, 41, '_menu_item_xfn', ''),
(165, 41, '_menu_item_url', ''),
(167, 2, '_wp_trash_meta_status', 'publish'),
(168, 2, '_wp_trash_meta_time', '1655113223'),
(169, 2, '_wp_desired_post_slug', 'sample-page'),
(170, 3, '_wp_trash_meta_status', 'draft'),
(171, 3, '_wp_trash_meta_time', '1655113228'),
(172, 3, '_wp_desired_post_slug', 'privacy-policy'),
(173, 44, '_edit_last', '1'),
(174, 44, '_edit_lock', '1655117627:1'),
(175, 46, '_menu_item_type', 'post_type'),
(176, 46, '_menu_item_menu_item_parent', '0'),
(177, 46, '_menu_item_object_id', '44'),
(178, 46, '_menu_item_object', 'page'),
(179, 46, '_menu_item_target', ''),
(180, 46, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(181, 46, '_menu_item_xfn', ''),
(182, 46, '_menu_item_url', ''),
(184, 47, 'banner_sections_section_enabled', '1'),
(185, 47, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(186, 47, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(187, 47, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(188, 47, 'banner_sections', ''),
(189, 47, '_banner_sections', 'field_62a6fdf032a35'),
(190, 48, '_edit_last', '1'),
(191, 48, '_edit_lock', '1655191164:1'),
(192, 49, '_wp_attached_file', '2022/06/p1.jpg'),
(193, 49, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:828;s:6:\"height\";i:798;s:4:\"file\";s:14:\"2022/06/p1.jpg\";s:8:\"filesize\";i:103126;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"p1-300x289.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23982;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"p1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7319;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:14:\"p1-768x740.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:740;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:120440;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(194, 48, '_thumbnail_id', '49'),
(195, 51, '_edit_last', '1'),
(196, 51, '_edit_lock', '1655191243:1'),
(197, 52, '_wp_attached_file', '2022/06/p2.jpg'),
(198, 52, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:828;s:6:\"height\";i:359;s:4:\"file\";s:14:\"2022/06/p2.jpg\";s:8:\"filesize\";i:48971;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"p2-300x130.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12444;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"p2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7365;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:14:\"p2-768x333.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:333;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:57856;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(199, 51, '_thumbnail_id', '52'),
(200, 54, '_edit_last', '1'),
(201, 54, '_edit_lock', '1655191314:1'),
(202, 56, '_wp_attached_file', '2022/06/p3.jpg'),
(203, 56, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:828;s:6:\"height\";i:359;s:4:\"file\";s:14:\"2022/06/p3.jpg\";s:8:\"filesize\";i:47329;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"p3-300x130.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12678;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"p3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7349;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:14:\"p3-768x333.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:333;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:56772;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(204, 6, 'section_enabled', '1'),
(205, 6, '_section_enabled', 'field_62a6fe0532a36'),
(206, 6, 'all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(207, 6, '_all_banners', 'field_62a6fe7932a37'),
(208, 6, 'portfolio_title', 'Portfolio'),
(209, 6, '_portfolio_title', 'field_62a70a3f357b5'),
(210, 6, 'all_portfolios', 'a:3:{i:0;s:2:\"48\";i:1;s:2:\"51\";i:2;s:2:\"54\";}'),
(211, 6, '_all_portfolios', 'field_62a70a49357b6'),
(212, 60, 'banner_sections_section_enabled', '1'),
(213, 60, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(214, 60, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(215, 60, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(216, 60, 'banner_sections', ''),
(217, 60, '_banner_sections', 'field_62a6fdf032a35'),
(218, 60, 'section_enabled', '1'),
(219, 60, '_section_enabled', 'field_62a6fe0532a36'),
(220, 60, 'all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(221, 60, '_all_banners', 'field_62a6fe7932a37'),
(222, 60, 'portfolio_title', 'Portfolio'),
(223, 60, '_portfolio_title', 'field_62a70a3f357b5'),
(224, 60, 'all_portfolios', 'a:3:{i:0;s:2:\"48\";i:1;s:2:\"51\";i:2;s:2:\"54\";}'),
(225, 60, '_all_portfolios', 'field_62a70a49357b6'),
(226, 54, '_thumbnail_id', '56'),
(227, 61, '_edit_last', '1'),
(228, 61, '_edit_lock', '1655114736:1'),
(229, 61, '_wp_trash_meta_status', 'publish'),
(230, 61, '_wp_trash_meta_time', '1655114883'),
(231, 61, '_wp_desired_post_slug', 'asfaf'),
(232, 6, 'portfolios_button_link', 'javascript:void(0)'),
(233, 6, '_portfolios_button_link', 'field_62a70cb7afa1f'),
(234, 64, 'banner_sections_section_enabled', '1'),
(235, 64, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(236, 64, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(237, 64, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(238, 64, 'banner_sections', ''),
(239, 64, '_banner_sections', 'field_62a6fdf032a35'),
(240, 64, 'section_enabled', '1'),
(241, 64, '_section_enabled', 'field_62a6fe0532a36'),
(242, 64, 'all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(243, 64, '_all_banners', 'field_62a6fe7932a37'),
(244, 64, 'portfolio_title', 'Portfolio'),
(245, 64, '_portfolio_title', 'field_62a70a3f357b5'),
(246, 64, 'all_portfolios', 'a:3:{i:0;s:2:\"48\";i:1;s:2:\"51\";i:2;s:2:\"54\";}'),
(247, 64, '_all_portfolios', 'field_62a70a49357b6'),
(248, 64, 'portfolios_button_link', 'javascript:void(0)'),
(249, 64, '_portfolios_button_link', 'field_62a70cb7afa1f'),
(250, 88, '_wp_attached_file', '2022/06/a1.png'),
(251, 88, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:96;s:6:\"height\";i:87;s:4:\"file\";s:14:\"2022/06/a1.png\";s:8:\"filesize\";i:4448;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(252, 89, '_wp_attached_file', '2022/06/a2.png'),
(253, 89, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:75;s:6:\"height\";i:75;s:4:\"file\";s:14:\"2022/06/a2.png\";s:8:\"filesize\";i:4591;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(254, 90, '_wp_attached_file', '2022/06/a3.png'),
(255, 90, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:66;s:6:\"height\";i:62;s:4:\"file\";s:14:\"2022/06/a3.png\";s:8:\"filesize\";i:2438;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(256, 6, 'achivemnets_section_achivemnets_title', 'meine leistungen'),
(257, 6, '_achivemnets_section_achivemnets_title', 'field_62a70dc04c990'),
(258, 6, 'achivemnets_section_a_image_1', '88'),
(259, 6, '_achivemnets_section_a_image_1', 'field_62a70dec4c992'),
(260, 6, 'achivemnets_section_a_title_1', 'Architektenleistungen der<br />Leistungsphasen 1-5 der HOAI'),
(261, 6, '_achivemnets_section_a_title_1', 'field_62a70e4a4c993'),
(262, 6, 'achivemnets_section_a_detail_1', '... meine Betreuung und die Bearbeitung der Vorhaben umfasst die Grundlagenermittlung, Vorentwürfe und den Entwurf, die Erstellung sämtlicher Unterlagen für den Bauantrag und nach Wunsch auch die Erstellung der Ausführungspläne ...'),
(263, 6, '_achivemnets_section_a_detail_1', 'field_62a70e5c4c994'),
(264, 6, 'achivemnets_section_a_image_2', '89'),
(265, 6, '_achivemnets_section_a_image_2', 'field_62a70eecf8f41'),
(266, 6, 'achivemnets_section_a_title_2', 'Verbindung mit der<br />Innenarchitektur'),
(267, 6, '_achivemnets_section_a_title_2', 'field_62a70efff8f42'),
(268, 6, 'achivemnets_section_a_detail_2', '... die Verwirklichung ganz persönlicher Vorstellungen von Lebensräumen ist immer ein Zusammenspiel von „außen“ und „innen“...'),
(269, 6, '_achivemnets_section_a_detail_2', 'field_62a70f11f8f43'),
(270, 6, 'achivemnets_section_a_image_3', '90'),
(271, 6, '_achivemnets_section_a_image_3', 'field_62a70f53f8f45'),
(272, 6, 'achivemnets_section_a_title_3', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(273, 6, '_achivemnets_section_a_title_3', 'field_62a70f69f8f46'),
(274, 6, 'achivemnets_section_a_detail_3', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(275, 6, '_achivemnets_section_a_detail_3', 'field_62a70f7ff8f47'),
(276, 6, 'achivemnets_section_a_image_4', '92'),
(277, 6, '_achivemnets_section_a_image_4', 'field_62a70fcff8f49'),
(278, 6, 'achivemnets_section_a_title_4', 'Beratung und Überprüfung zur Machbarkeit<br />von Bauvorhaben'),
(279, 6, '_achivemnets_section_a_title_4', 'field_62a70fe0f8f4a'),
(280, 6, 'achivemnets_section_a_detail_4', '... erste Untersuchungen zur Zulässigkeit von Bauvorhaben, Größe, Gestaltung etc...'),
(281, 6, '_achivemnets_section_a_detail_4', 'field_62a70ff2f8f4b'),
(282, 6, 'achivemnets_section_a_image_5', '93'),
(283, 6, '_achivemnets_section_a_image_5', 'field_62a710232301f'),
(284, 6, 'achivemnets_section_a_title_5', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(285, 6, '_achivemnets_section_a_title_5', 'field_62a7103423020'),
(286, 6, 'achivemnets_section_a_detail_5', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(287, 6, '_achivemnets_section_a_detail_5', 'field_62a7104023021'),
(288, 6, 'achivemnets_section', ''),
(289, 6, '_achivemnets_section', 'field_62a70e9dbd56d'),
(290, 91, 'banner_sections_section_enabled', '1'),
(291, 91, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(292, 91, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(293, 91, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(294, 91, 'banner_sections', ''),
(295, 91, '_banner_sections', 'field_62a6fdf032a35'),
(296, 91, 'section_enabled', '1'),
(297, 91, '_section_enabled', 'field_62a6fe0532a36'),
(298, 91, 'all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(299, 91, '_all_banners', 'field_62a6fe7932a37'),
(300, 91, 'portfolio_title', 'Portfolio'),
(301, 91, '_portfolio_title', 'field_62a70a3f357b5'),
(302, 91, 'all_portfolios', 'a:3:{i:0;s:2:\"48\";i:1;s:2:\"51\";i:2;s:2:\"54\";}'),
(303, 91, '_all_portfolios', 'field_62a70a49357b6'),
(304, 91, 'portfolios_button_link', 'javascript:void(0)'),
(305, 91, '_portfolios_button_link', 'field_62a70cb7afa1f'),
(306, 91, 'achivemnets_section_achivemnets_title', 'meine leistungen'),
(307, 91, '_achivemnets_section_achivemnets_title', 'field_62a70dc04c990'),
(308, 91, 'achivemnets_section_a_image_1', '88'),
(309, 91, '_achivemnets_section_a_image_1', 'field_62a70dec4c992'),
(310, 91, 'achivemnets_section_a_title_1', 'Architektenleistungen der<br />Leistungsphasen 1-5 der HOAI'),
(311, 91, '_achivemnets_section_a_title_1', 'field_62a70e4a4c993'),
(312, 91, 'achivemnets_section_a_detail_1', '... meine Betreuung und die Bearbeitung der Vorhaben umfasst die Grundlagenermittlung, Vorentwürfe und den Entwurf, die Erstellung sämtlicher Unterlagen für den Bauantrag und nach Wunsch auch die Erstellung der Ausführungspläne ...'),
(313, 91, '_achivemnets_section_a_detail_1', 'field_62a70e5c4c994'),
(314, 91, 'achivemnets_section_a_image_2', '89'),
(315, 91, '_achivemnets_section_a_image_2', 'field_62a70eecf8f41'),
(316, 91, 'achivemnets_section_a_title_2', 'Verbindung mit der<br />Innenarchitektur'),
(317, 91, '_achivemnets_section_a_title_2', 'field_62a70efff8f42'),
(318, 91, 'achivemnets_section_a_detail_2', '... die Verwirklichung ganz persönlicher Vorstellungen von Lebensräumen ist immer ein Zusammenspiel von „außen“ und „innen“...'),
(319, 91, '_achivemnets_section_a_detail_2', 'field_62a70f11f8f43'),
(320, 91, 'achivemnets_section_a_image_3', '90'),
(321, 91, '_achivemnets_section_a_image_3', 'field_62a70f53f8f45'),
(322, 91, 'achivemnets_section_a_title_3', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(323, 91, '_achivemnets_section_a_title_3', 'field_62a70f69f8f46'),
(324, 91, 'achivemnets_section_a_detail_3', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(325, 91, '_achivemnets_section_a_detail_3', 'field_62a70f7ff8f47'),
(326, 91, 'achivemnets_section_a_image_4', ''),
(327, 91, '_achivemnets_section_a_image_4', 'field_62a70fcff8f49'),
(328, 91, 'achivemnets_section_a_title_4', ''),
(329, 91, '_achivemnets_section_a_title_4', 'field_62a70fe0f8f4a'),
(330, 91, 'achivemnets_section_a_detail_4', ''),
(331, 91, '_achivemnets_section_a_detail_4', 'field_62a70ff2f8f4b'),
(332, 91, 'achivemnets_section_a_image_5', ''),
(333, 91, '_achivemnets_section_a_image_5', 'field_62a710232301f'),
(334, 91, 'achivemnets_section_a_title_5', ''),
(335, 91, '_achivemnets_section_a_title_5', 'field_62a7103423020'),
(336, 91, 'achivemnets_section_a_detail_5', ''),
(337, 91, '_achivemnets_section_a_detail_5', 'field_62a7104023021'),
(338, 91, 'achivemnets_section', ''),
(339, 91, '_achivemnets_section', 'field_62a70e9dbd56d'),
(340, 92, '_wp_attached_file', '2022/06/a4.png'),
(341, 92, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:85;s:6:\"height\";i:78;s:4:\"file\";s:14:\"2022/06/a4.png\";s:8:\"filesize\";i:4768;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(342, 93, '_wp_attached_file', '2022/06/a5.png'),
(343, 93, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:87;s:6:\"height\";i:87;s:4:\"file\";s:14:\"2022/06/a5.png\";s:8:\"filesize\";i:4916;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(344, 94, 'banner_sections_section_enabled', '1'),
(345, 94, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(346, 94, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(347, 94, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(348, 94, 'banner_sections', ''),
(349, 94, '_banner_sections', 'field_62a6fdf032a35'),
(350, 94, 'section_enabled', '1'),
(351, 94, '_section_enabled', 'field_62a6fe0532a36'),
(352, 94, 'all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(353, 94, '_all_banners', 'field_62a6fe7932a37'),
(354, 94, 'portfolio_title', 'Portfolio'),
(355, 94, '_portfolio_title', 'field_62a70a3f357b5'),
(356, 94, 'all_portfolios', 'a:3:{i:0;s:2:\"48\";i:1;s:2:\"51\";i:2;s:2:\"54\";}'),
(357, 94, '_all_portfolios', 'field_62a70a49357b6'),
(358, 94, 'portfolios_button_link', 'javascript:void(0)'),
(359, 94, '_portfolios_button_link', 'field_62a70cb7afa1f'),
(360, 94, 'achivemnets_section_achivemnets_title', 'meine leistungen'),
(361, 94, '_achivemnets_section_achivemnets_title', 'field_62a70dc04c990'),
(362, 94, 'achivemnets_section_a_image_1', '88'),
(363, 94, '_achivemnets_section_a_image_1', 'field_62a70dec4c992'),
(364, 94, 'achivemnets_section_a_title_1', 'Architektenleistungen der<br />Leistungsphasen 1-5 der HOAI'),
(365, 94, '_achivemnets_section_a_title_1', 'field_62a70e4a4c993'),
(366, 94, 'achivemnets_section_a_detail_1', '... meine Betreuung und die Bearbeitung der Vorhaben umfasst die Grundlagenermittlung, Vorentwürfe und den Entwurf, die Erstellung sämtlicher Unterlagen für den Bauantrag und nach Wunsch auch die Erstellung der Ausführungspläne ...'),
(367, 94, '_achivemnets_section_a_detail_1', 'field_62a70e5c4c994'),
(368, 94, 'achivemnets_section_a_image_2', '89'),
(369, 94, '_achivemnets_section_a_image_2', 'field_62a70eecf8f41'),
(370, 94, 'achivemnets_section_a_title_2', 'Verbindung mit der<br />Innenarchitektur'),
(371, 94, '_achivemnets_section_a_title_2', 'field_62a70efff8f42'),
(372, 94, 'achivemnets_section_a_detail_2', '... die Verwirklichung ganz persönlicher Vorstellungen von Lebensräumen ist immer ein Zusammenspiel von „außen“ und „innen“...'),
(373, 94, '_achivemnets_section_a_detail_2', 'field_62a70f11f8f43'),
(374, 94, 'achivemnets_section_a_image_3', '90'),
(375, 94, '_achivemnets_section_a_image_3', 'field_62a70f53f8f45'),
(376, 94, 'achivemnets_section_a_title_3', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(377, 94, '_achivemnets_section_a_title_3', 'field_62a70f69f8f46'),
(378, 94, 'achivemnets_section_a_detail_3', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(379, 94, '_achivemnets_section_a_detail_3', 'field_62a70f7ff8f47'),
(380, 94, 'achivemnets_section_a_image_4', '92'),
(381, 94, '_achivemnets_section_a_image_4', 'field_62a70fcff8f49'),
(382, 94, 'achivemnets_section_a_title_4', 'Beratung und Überprüfung zur Machbarkeit<br />von Bauvorhaben'),
(383, 94, '_achivemnets_section_a_title_4', 'field_62a70fe0f8f4a'),
(384, 94, 'achivemnets_section_a_detail_4', '... erste Untersuchungen zur Zulässigkeit von Bauvorhaben, Größe, Gestaltung etc...'),
(385, 94, '_achivemnets_section_a_detail_4', 'field_62a70ff2f8f4b'),
(386, 94, 'achivemnets_section_a_image_5', '93'),
(387, 94, '_achivemnets_section_a_image_5', 'field_62a710232301f'),
(388, 94, 'achivemnets_section_a_title_5', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(389, 94, '_achivemnets_section_a_title_5', 'field_62a7103423020'),
(390, 94, 'achivemnets_section_a_detail_5', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(391, 94, '_achivemnets_section_a_detail_5', 'field_62a7104023021'),
(392, 94, 'achivemnets_section', ''),
(393, 94, '_achivemnets_section', 'field_62a70e9dbd56d'),
(394, 6, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(395, 6, '_action_heading', 'field_62a71405782f4'),
(396, 6, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(397, 6, '_action_sub_heading', 'field_62a7141a782f5'),
(398, 6, 'action_button_link', 'javascript:void(0)'),
(399, 6, '_action_button_link', 'field_62a71424782f6'),
(400, 99, 'banner_sections_section_enabled', '1'),
(401, 99, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(402, 99, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(403, 99, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(404, 99, 'banner_sections', ''),
(405, 99, '_banner_sections', 'field_62a6fdf032a35'),
(406, 99, 'section_enabled', '1'),
(407, 99, '_section_enabled', 'field_62a6fe0532a36'),
(408, 99, 'all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(409, 99, '_all_banners', 'field_62a6fe7932a37'),
(410, 99, 'portfolio_title', 'Portfolio'),
(411, 99, '_portfolio_title', 'field_62a70a3f357b5'),
(412, 99, 'all_portfolios', 'a:3:{i:0;s:2:\"48\";i:1;s:2:\"51\";i:2;s:2:\"54\";}'),
(413, 99, '_all_portfolios', 'field_62a70a49357b6'),
(414, 99, 'portfolios_button_link', 'javascript:void(0)'),
(415, 99, '_portfolios_button_link', 'field_62a70cb7afa1f'),
(416, 99, 'achivemnets_section_achivemnets_title', 'meine leistungen'),
(417, 99, '_achivemnets_section_achivemnets_title', 'field_62a70dc04c990'),
(418, 99, 'achivemnets_section_a_image_1', '88'),
(419, 99, '_achivemnets_section_a_image_1', 'field_62a70dec4c992'),
(420, 99, 'achivemnets_section_a_title_1', 'Architektenleistungen der<br />Leistungsphasen 1-5 der HOAI'),
(421, 99, '_achivemnets_section_a_title_1', 'field_62a70e4a4c993'),
(422, 99, 'achivemnets_section_a_detail_1', '... meine Betreuung und die Bearbeitung der Vorhaben umfasst die Grundlagenermittlung, Vorentwürfe und den Entwurf, die Erstellung sämtlicher Unterlagen für den Bauantrag und nach Wunsch auch die Erstellung der Ausführungspläne ...'),
(423, 99, '_achivemnets_section_a_detail_1', 'field_62a70e5c4c994'),
(424, 99, 'achivemnets_section_a_image_2', '89'),
(425, 99, '_achivemnets_section_a_image_2', 'field_62a70eecf8f41'),
(426, 99, 'achivemnets_section_a_title_2', 'Verbindung mit der<br />Innenarchitektur'),
(427, 99, '_achivemnets_section_a_title_2', 'field_62a70efff8f42'),
(428, 99, 'achivemnets_section_a_detail_2', '... die Verwirklichung ganz persönlicher Vorstellungen von Lebensräumen ist immer ein Zusammenspiel von „außen“ und „innen“...'),
(429, 99, '_achivemnets_section_a_detail_2', 'field_62a70f11f8f43'),
(430, 99, 'achivemnets_section_a_image_3', '90'),
(431, 99, '_achivemnets_section_a_image_3', 'field_62a70f53f8f45'),
(432, 99, 'achivemnets_section_a_title_3', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(433, 99, '_achivemnets_section_a_title_3', 'field_62a70f69f8f46'),
(434, 99, 'achivemnets_section_a_detail_3', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(435, 99, '_achivemnets_section_a_detail_3', 'field_62a70f7ff8f47'),
(436, 99, 'achivemnets_section_a_image_4', '92'),
(437, 99, '_achivemnets_section_a_image_4', 'field_62a70fcff8f49'),
(438, 99, 'achivemnets_section_a_title_4', 'Beratung und Überprüfung zur Machbarkeit<br />von Bauvorhaben'),
(439, 99, '_achivemnets_section_a_title_4', 'field_62a70fe0f8f4a'),
(440, 99, 'achivemnets_section_a_detail_4', '... erste Untersuchungen zur Zulässigkeit von Bauvorhaben, Größe, Gestaltung etc...'),
(441, 99, '_achivemnets_section_a_detail_4', 'field_62a70ff2f8f4b'),
(442, 99, 'achivemnets_section_a_image_5', '93'),
(443, 99, '_achivemnets_section_a_image_5', 'field_62a710232301f'),
(444, 99, 'achivemnets_section_a_title_5', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(445, 99, '_achivemnets_section_a_title_5', 'field_62a7103423020'),
(446, 99, 'achivemnets_section_a_detail_5', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(447, 99, '_achivemnets_section_a_detail_5', 'field_62a7104023021'),
(448, 99, 'achivemnets_section', ''),
(449, 99, '_achivemnets_section', 'field_62a70e9dbd56d'),
(450, 99, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(451, 99, '_action_heading', 'field_62a71405782f4'),
(452, 99, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(453, 99, '_action_sub_heading', 'field_62a7141a782f5'),
(454, 99, 'action_button_link', 'javascript:void(0)'),
(455, 99, '_action_button_link', 'field_62a71424782f6'),
(456, 100, '_edit_last', '1'),
(457, 100, '_edit_lock', '1655116871:1'),
(458, 102, '_edit_last', '1'),
(459, 102, '_edit_lock', '1655117594:1'),
(460, 105, '_edit_last', '1'),
(461, 105, '_edit_lock', '1655116884:1'),
(462, 107, '_menu_item_type', 'post_type'),
(463, 107, '_menu_item_menu_item_parent', '0'),
(464, 107, '_menu_item_object_id', '6'),
(465, 107, '_menu_item_object', 'page'),
(466, 107, '_menu_item_target', ''),
(467, 107, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(468, 107, '_menu_item_xfn', ''),
(469, 107, '_menu_item_url', ''),
(471, 108, '_menu_item_type', 'post_type'),
(472, 108, '_menu_item_menu_item_parent', '0'),
(473, 108, '_menu_item_object_id', '105'),
(474, 108, '_menu_item_object', 'page'),
(475, 108, '_menu_item_target', ''),
(476, 108, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(477, 108, '_menu_item_xfn', ''),
(478, 108, '_menu_item_url', ''),
(480, 109, '_menu_item_type', 'post_type'),
(481, 109, '_menu_item_menu_item_parent', '0'),
(482, 109, '_menu_item_object_id', '102'),
(483, 109, '_menu_item_object', 'page'),
(484, 109, '_menu_item_target', ''),
(485, 109, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(486, 109, '_menu_item_xfn', ''),
(487, 109, '_menu_item_url', ''),
(489, 110, '_menu_item_type', 'post_type'),
(490, 110, '_menu_item_menu_item_parent', '0'),
(491, 110, '_menu_item_object_id', '8'),
(492, 110, '_menu_item_object', 'page'),
(493, 110, '_menu_item_target', ''),
(494, 110, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(495, 110, '_menu_item_xfn', ''),
(496, 110, '_menu_item_url', ''),
(498, 111, '_menu_item_type', 'post_type'),
(499, 111, '_menu_item_menu_item_parent', '0'),
(500, 111, '_menu_item_object_id', '100'),
(501, 111, '_menu_item_object', 'page'),
(502, 111, '_menu_item_target', ''),
(503, 111, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(504, 111, '_menu_item_xfn', ''),
(505, 111, '_menu_item_url', ''),
(507, 112, '_menu_item_type', 'post_type'),
(508, 112, '_menu_item_menu_item_parent', '0'),
(509, 112, '_menu_item_object_id', '44'),
(510, 112, '_menu_item_object', 'page'),
(511, 112, '_menu_item_target', ''),
(512, 112, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(513, 112, '_menu_item_xfn', ''),
(514, 112, '_menu_item_url', ''),
(516, 113, '_menu_item_type', 'post_type'),
(517, 113, '_menu_item_menu_item_parent', '0'),
(518, 113, '_menu_item_object_id', '10'),
(519, 113, '_menu_item_object', 'page'),
(520, 113, '_menu_item_target', ''),
(521, 113, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(522, 113, '_menu_item_xfn', ''),
(523, 113, '_menu_item_url', ''),
(525, 117, 'banner_sections_section_enabled', '1'),
(526, 117, '_banner_sections_section_enabled', 'field_62a6fe0532a36'),
(527, 117, 'banner_sections_all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(528, 117, '_banner_sections_all_banners', 'field_62a6fe7932a37'),
(529, 117, 'banner_sections', ''),
(530, 117, '_banner_sections', 'field_62a6fdf032a35'),
(531, 117, 'section_enabled', '1'),
(532, 117, '_section_enabled', 'field_62a6fe0532a36'),
(533, 117, 'all_banners', 'a:4:{i:0;s:2:\"19\";i:1;s:2:\"22\";i:2;s:2:\"25\";i:3;s:2:\"27\";}'),
(534, 117, '_all_banners', 'field_62a6fe7932a37'),
(535, 117, 'portfolio_title', 'Portfolio'),
(536, 117, '_portfolio_title', 'field_62a70a3f357b5'),
(537, 117, 'all_portfolios', 'a:3:{i:0;s:2:\"48\";i:1;s:2:\"51\";i:2;s:2:\"54\";}'),
(538, 117, '_all_portfolios', 'field_62a70a49357b6'),
(539, 117, 'portfolios_button_link', 'javascript:void(0)'),
(540, 117, '_portfolios_button_link', 'field_62a70cb7afa1f'),
(541, 117, 'achivemnets_section_achivemnets_title', 'meine leistungen'),
(542, 117, '_achivemnets_section_achivemnets_title', 'field_62a70dc04c990'),
(543, 117, 'achivemnets_section_a_image_1', '88'),
(544, 117, '_achivemnets_section_a_image_1', 'field_62a70dec4c992'),
(545, 117, 'achivemnets_section_a_title_1', 'Architektenleistungen der<br />Leistungsphasen 1-5 der HOAI'),
(546, 117, '_achivemnets_section_a_title_1', 'field_62a70e4a4c993'),
(547, 117, 'achivemnets_section_a_detail_1', '... meine Betreuung und die Bearbeitung der Vorhaben umfasst die Grundlagenermittlung, Vorentwürfe und den Entwurf, die Erstellung sämtlicher Unterlagen für den Bauantrag und nach Wunsch auch die Erstellung der Ausführungspläne ...'),
(548, 117, '_achivemnets_section_a_detail_1', 'field_62a70e5c4c994'),
(549, 117, 'achivemnets_section_a_image_2', '89'),
(550, 117, '_achivemnets_section_a_image_2', 'field_62a70eecf8f41'),
(551, 117, 'achivemnets_section_a_title_2', 'Verbindung mit der<br />Innenarchitektur'),
(552, 117, '_achivemnets_section_a_title_2', 'field_62a70efff8f42'),
(553, 117, 'achivemnets_section_a_detail_2', '... die Verwirklichung ganz persönlicher Vorstellungen von Lebensräumen ist immer ein Zusammenspiel von „außen“ und „innen“...'),
(554, 117, '_achivemnets_section_a_detail_2', 'field_62a70f11f8f43'),
(555, 117, 'achivemnets_section_a_image_3', '90'),
(556, 117, '_achivemnets_section_a_image_3', 'field_62a70f53f8f45'),
(557, 117, 'achivemnets_section_a_title_3', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(558, 117, '_achivemnets_section_a_title_3', 'field_62a70f69f8f46'),
(559, 117, 'achivemnets_section_a_detail_3', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(560, 117, '_achivemnets_section_a_detail_3', 'field_62a70f7ff8f47'),
(561, 117, 'achivemnets_section_a_image_4', '92'),
(562, 117, '_achivemnets_section_a_image_4', 'field_62a70fcff8f49'),
(563, 117, 'achivemnets_section_a_title_4', 'Beratung und Überprüfung zur Machbarkeit<br />von Bauvorhaben'),
(564, 117, '_achivemnets_section_a_title_4', 'field_62a70fe0f8f4a'),
(565, 117, 'achivemnets_section_a_detail_4', '... erste Untersuchungen zur Zulässigkeit von Bauvorhaben, Größe, Gestaltung etc...'),
(566, 117, '_achivemnets_section_a_detail_4', 'field_62a70ff2f8f4b'),
(567, 117, 'achivemnets_section_a_image_5', '93'),
(568, 117, '_achivemnets_section_a_image_5', 'field_62a710232301f'),
(569, 117, 'achivemnets_section_a_title_5', 'Beratungsleistungen bei Sanierungs- und<br />Umbaumaßnahmen'),
(570, 117, '_achivemnets_section_a_title_5', 'field_62a7103423020'),
(571, 117, 'achivemnets_section_a_detail_5', '... mit der Erfahrung von zahlreichen, ausgeführten Projekten in diesem Bereich kann ich eine Beratung im Vorfeld und im weiteren Verlauf der Maßnahmen anbieten ...'),
(572, 117, '_achivemnets_section_a_detail_5', 'field_62a7104023021'),
(573, 117, 'achivemnets_section', ''),
(574, 117, '_achivemnets_section', 'field_62a70e9dbd56d'),
(575, 117, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(576, 117, '_action_heading', 'field_62a71405782f4'),
(577, 117, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(578, 117, '_action_sub_heading', 'field_62a7141a782f5'),
(579, 117, 'action_button_link', 'javascript:void(0)'),
(580, 117, '_action_button_link', 'field_62a71424782f6'),
(581, 8, '_wp_page_template', 'templates/tmp-Kontakt.php'),
(582, 10, '_wp_page_template', 'templates/tmp-projekte.php'),
(583, 118, '_edit_last', '1'),
(584, 118, '_edit_lock', '1655189300:1'),
(585, 8, 'contact_details', 'Gerne können Sie mich kontaktieren und wir sprechen <br> gemeinsam über Ihr neues Bauvorhaben!'),
(586, 8, '_contact_details', 'field_62a72a0003a6f'),
(587, 8, 'contact_map', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2666.0305323607276!2d11.18449121517085!3d48.071053563771656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x479c2cc0d05aea75%3A0x56a9c593c22efe55!2sSponner%20Marianne%20Dipl.-Ing.%20Architekt!5e0!3m2!1sen!2sin!4v1654766248029!5m2!1sen!2sin\" width=\"100%\" height=\"100%\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),
(588, 8, '_contact_map', 'field_62a72a3b03a71'),
(589, 121, 'contact_details', 'Gerne können Sie mich kontaktieren und wir sprechen <br> gemeinsam über Ihr neues Bauvorhaben!'),
(590, 121, '_contact_details', 'field_62a72a0003a6f'),
(591, 121, 'contact_map', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2666.0305323607276!2d11.18449121517085!3d48.071053563771656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x479c2cc0d05aea75%3A0x56a9c593c22efe55!2sSponner%20Marianne%20Dipl.-Ing.%20Architekt!5e0!3m2!1sen!2sin!4v1654766248029!5m2!1sen!2sin\" width=\"100%\" height=\"100%\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),
(592, 121, '_contact_map', 'field_62a72a3b03a71'),
(593, 123, '_edit_last', '1'),
(594, 123, '_wp_page_template', 'templates/tmp-uber_mich.php'),
(595, 123, '_edit_lock', '1655200663:1'),
(596, 125, '_edit_last', '1'),
(597, 125, '_edit_lock', '1655198813:1'),
(598, 123, 'meine_philosophie_title', 'Meine Philosophie'),
(599, 123, '_meine_philosophie_title', 'field_62a72e5c42eb9'),
(600, 123, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.<br><br>\r\n\r\nIndividuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der Umnutzungen, Erweiterungen und Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br>\r\n\r\nDie jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen, Gegebenheiten und Möglichkeiten wird\r\njedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den individuellen Bauaufgaben ist das Ziel.<br><br>\r\n\r\nDie Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der\r\nArbeiten fließt in die einzelnen Schritte mit ein.<br><br>\r\n\r\nDas Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten Lösungen für die Konstruktionen und eine zeitgemäße Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer\r\ngewähren.<br><br>\r\n\r\nAlles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(601, 123, '_meine_philosophie_details', 'field_62a72e7142eba'),
(602, 129, 'meine_philosophie_title', ''),
(603, 129, '_meine_philosophie_title', 'field_62a72e5c42eb9'),
(604, 129, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.<br><br> Individuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der Umnutzungen, Erweiterungen und Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br> Die jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen, Gegebenheiten und Möglichkeiten wirdjedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den individuellen Bauaufgaben ist das Ziel.<br><br> Die Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der\r\nArbeiten fließt in die einzelnen Schritte mit ein.<br><br>\r\nDas Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten Lösungen für die Konstruktionen und eine zeitgemäße Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer gewähren.<br><br> Alles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(605, 129, '_meine_philosophie_details', 'field_62a72e7142eba'),
(606, 130, 'meine_philosophie_title', 'Meine Philosophie'),
(607, 130, '_meine_philosophie_title', 'field_62a72e5c42eb9');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(608, 130, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.<br><br> Individuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der Umnutzungen, Erweiterungen und Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br> Die jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen, Gegebenheiten und Möglichkeiten wirdjedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den individuellen Bauaufgaben ist das Ziel.<br><br> Die Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der\r\nArbeiten fließt in die einzelnen Schritte mit ein.<br><br>\r\nDas Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten Lösungen für die Konstruktionen und eine zeitgemäße Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer gewähren.<br><br> Alles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(609, 130, '_meine_philosophie_details', 'field_62a72e7142eba'),
(610, 131, 'meine_philosophie_title', 'Meine Philosophie'),
(611, 131, '_meine_philosophie_title', 'field_62a72e5c42eb9'),
(612, 131, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.<br><br> Individuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der Umnutzungen, Erweiterungen und Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br> Die jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen, Gegebenheiten und Möglichkeiten wirdjedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den individuellen Bauaufgaben ist das Ziel.<br><br> Die Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der Arbeiten fließt in die einzelnen Schritte mit ein.<br><br> Das Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten Lösungen für die Konstruktionen und eine zeitgemäße Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer gewähren.<br><br> Alles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(613, 131, '_meine_philosophie_details', 'field_62a72e7142eba'),
(614, 123, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(615, 123, '_action_heading', 'field_62a732bacc3f5'),
(616, 123, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(617, 123, '_action_sub_heading', 'field_62a732c6cc3f6'),
(618, 123, 'action_button_link', 'javascript:void(0)'),
(619, 123, '_action_button_link', 'field_62a732cecc3f7'),
(620, 136, 'meine_philosophie_title', 'Meine Philosophie'),
(621, 136, '_meine_philosophie_title', 'field_62a72e5c42eb9'),
(622, 136, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.<br><br> Individuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der Umnutzungen, Erweiterungen und Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br> Die jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen, Gegebenheiten und Möglichkeiten wirdjedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den individuellen Bauaufgaben ist das Ziel.<br><br> Die Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der Arbeiten fließt in die einzelnen Schritte mit ein.<br><br> Das Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten Lösungen für die Konstruktionen und eine zeitgemäße Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer gewähren.<br><br> Alles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(623, 136, '_meine_philosophie_details', 'field_62a72e7142eba'),
(624, 136, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(625, 136, '_action_heading', 'field_62a732bacc3f5'),
(626, 136, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(627, 136, '_action_sub_heading', 'field_62a732c6cc3f6'),
(628, 136, 'action_button_link', 'javascript:void(0)'),
(629, 136, '_action_button_link', 'field_62a732cecc3f7'),
(630, 12, '_wp_trash_meta_status', 'publish'),
(631, 12, '_wp_trash_meta_time', '1655182463'),
(632, 12, '_wp_desired_post_slug', 'uber-mich'),
(633, 150, '_wp_attached_file', '2022/06/about_me.jpg'),
(634, 150, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:615;s:6:\"height\";i:582;s:4:\"file\";s:20:\"2022/06/about_me.jpg\";s:8:\"filesize\";i:224403;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:20:\"about_me-300x284.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14211;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"about_me-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5236;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(635, 123, 'name', 'Mein Lebenslauf'),
(636, 123, '_name', 'field_62a734add4d3d'),
(637, 123, 'my_image', '150'),
(638, 123, '_my_image', 'field_62a814b957086'),
(639, 123, 'from_to_1', '1978-82'),
(640, 123, '_from_to_1', 'field_62a734b7d4d3e'),
(641, 123, 'detail_1', 'Studium Innenarchitektur FH Rosenheim'),
(642, 123, '_detail_1', 'field_62a734d6d4d3f'),
(643, 123, 'from_to_2', '1983-85'),
(644, 123, '_from_to_2', 'field_62a73500d4d40'),
(645, 123, 'detail_2', 'Aufbaustudium Architektur FH München<br><br>Gastsemester bei Frei Otto am Institur für leichte Flächentragwerke in Stuttgart<br><br>Mitarbeit im Büro Prof. W. Betsch, München'),
(646, 123, '_detail_2', 'field_62a7350dd4d41'),
(647, 123, 'from_to_3', '1985-88'),
(648, 123, '_from_to_3', 'field_62a7351ad4d42'),
(649, 123, 'detail_3', 'angestellt im Büro R. Lagally, München'),
(650, 123, '_detail_3', 'field_62a73525d4d43'),
(651, 123, 'from_to_4', '1989'),
(652, 123, '_from_to_4', 'field_62a7354bd4d44'),
(653, 123, 'detail_4', 'Selbstständig'),
(654, 123, '_detail_4', 'field_62a7355dd4d45'),
(655, 123, 'from_to_5', '1992'),
(656, 123, '_from_to_5', 'field_62a735711379d'),
(657, 123, 'detail_5', 'Mitgliedschaft Bayr. Architektenkammer'),
(658, 123, '_detail_5', 'field_62a7357c1379e'),
(659, 151, 'meine_philosophie_title', 'Meine Philosophie'),
(660, 151, '_meine_philosophie_title', 'field_62a72e5c42eb9'),
(661, 151, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.<br><br> Individuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der Umnutzungen, Erweiterungen und Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br> Die jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen, Gegebenheiten und Möglichkeiten wirdjedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den individuellen Bauaufgaben ist das Ziel.<br><br> Die Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der Arbeiten fließt in die einzelnen Schritte mit ein.<br><br> Das Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten Lösungen für die Konstruktionen und eine zeitgemäße Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer gewähren.<br><br> Alles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(662, 151, '_meine_philosophie_details', 'field_62a72e7142eba'),
(663, 151, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(664, 151, '_action_heading', 'field_62a732bacc3f5'),
(665, 151, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(666, 151, '_action_sub_heading', 'field_62a732c6cc3f6'),
(667, 151, 'action_button_link', 'javascript:void(0)'),
(668, 151, '_action_button_link', 'field_62a732cecc3f7'),
(669, 151, 'name', 'Mein Lebenslauf'),
(670, 151, '_name', 'field_62a734add4d3d'),
(671, 151, 'my_image', '150'),
(672, 151, '_my_image', 'field_62a814b957086'),
(673, 151, 'from_to_1', '1978-82'),
(674, 151, '_from_to_1', 'field_62a734b7d4d3e'),
(675, 151, 'detail_1', 'Studium Innenarchitektur FH Rosenheim'),
(676, 151, '_detail_1', 'field_62a734d6d4d3f'),
(677, 151, 'from_to_2', '1983-85'),
(678, 151, '_from_to_2', 'field_62a73500d4d40'),
(679, 151, 'detail_2', 'Aufbaustudium Architektur FH München<br><br>Gastsemester bei Frei Otto am Institur für leichte Flächentragwerke in Stuttgart<br><br>Mitarbeit im Büro Prof. W. Betsch, München'),
(680, 151, '_detail_2', 'field_62a7350dd4d41'),
(681, 151, 'from_to_3', '1985-88'),
(682, 151, '_from_to_3', 'field_62a7351ad4d42'),
(683, 151, 'detail_3', 'angestellt im Büro R. Lagally, München'),
(684, 151, '_detail_3', 'field_62a73525d4d43'),
(685, 151, 'from_to_4', '1989'),
(686, 151, '_from_to_4', 'field_62a7354bd4d44'),
(687, 151, 'detail_4', 'Selbstständig'),
(688, 151, '_detail_4', 'field_62a7355dd4d45'),
(689, 151, 'from_to_5', '1992'),
(690, 151, '_from_to_5', 'field_62a735711379d'),
(691, 151, 'detail_5', 'Mitgliedschaft Bayr. Architektenkammer'),
(692, 151, '_detail_5', 'field_62a7357c1379e'),
(693, 153, 'meine_philosophie_title', 'Meine Philosophie'),
(694, 153, '_meine_philosophie_title', 'field_62a72e5c42eb9'),
(695, 153, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem\r\n                        Bauen im Bestand und mit denkmalgeschützten\r\n                        Gebäuden befasst und zahlreiche Projekte realisiert.<br><br>\r\n\r\n                        Individuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der\r\n                        Umnutzungen, Erweiterungen und\r\n                        Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br>\r\n\r\n                        Die jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen,\r\n                        Gegebenheiten und Möglichkeiten wird\r\n                        jedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den\r\n                        individuellen Bauaufgaben ist das Ziel.<br><br>\r\n\r\n                        Die Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit\r\n                        den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der\r\n                        Arbeiten fließt in die einzelnen Schritte mit ein.<br><br>\r\n\r\n                        Das Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten\r\n                        Lösungen für die Konstruktionen und eine zeitgemäße\r\n                        Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer\r\n                        gewähren.<br><br>\r\n\r\n                        Alles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(696, 153, '_meine_philosophie_details', 'field_62a72e7142eba'),
(697, 153, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(698, 153, '_action_heading', 'field_62a732bacc3f5'),
(699, 153, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(700, 153, '_action_sub_heading', 'field_62a732c6cc3f6'),
(701, 153, 'action_button_link', 'javascript:void(0)'),
(702, 153, '_action_button_link', 'field_62a732cecc3f7'),
(703, 153, 'name', 'Mein Lebenslauf'),
(704, 153, '_name', 'field_62a734add4d3d'),
(705, 153, 'my_image', '150'),
(706, 153, '_my_image', 'field_62a814b957086'),
(707, 153, 'from_to_1', '1978-82'),
(708, 153, '_from_to_1', 'field_62a734b7d4d3e'),
(709, 153, 'detail_1', 'Studium Innenarchitektur FH Rosenheim'),
(710, 153, '_detail_1', 'field_62a734d6d4d3f'),
(711, 153, 'from_to_2', '1983-85'),
(712, 153, '_from_to_2', 'field_62a73500d4d40'),
(713, 153, 'detail_2', 'Aufbaustudium Architektur FH München<br><br>Gastsemester bei Frei Otto am Institur für leichte Flächentragwerke in Stuttgart<br><br>Mitarbeit im Büro Prof. W. Betsch, München'),
(714, 153, '_detail_2', 'field_62a7350dd4d41'),
(715, 153, 'from_to_3', '1985-88'),
(716, 153, '_from_to_3', 'field_62a7351ad4d42'),
(717, 153, 'detail_3', 'angestellt im Büro R. Lagally, München'),
(718, 153, '_detail_3', 'field_62a73525d4d43'),
(719, 153, 'from_to_4', '1989'),
(720, 153, '_from_to_4', 'field_62a7354bd4d44'),
(721, 153, 'detail_4', 'Selbstständig'),
(722, 153, '_detail_4', 'field_62a7355dd4d45'),
(723, 153, 'from_to_5', '1992'),
(724, 153, '_from_to_5', 'field_62a735711379d'),
(725, 153, 'detail_5', 'Mitgliedschaft Bayr. Architektenkammer'),
(726, 153, '_detail_5', 'field_62a7357c1379e'),
(727, 154, 'meine_philosophie_title', 'Meine Philosophie'),
(728, 154, '_meine_philosophie_title', 'field_62a72e5c42eb9'),
(729, 154, 'meine_philosophie_details', '<p>Seit Beginn meiner selbständigen Tätigkeit als Architektin habe ich mich mit Neubauten, dem Bauen im Bestand und mit denkmalgeschützten Gebäuden befasst und zahlreiche Projekte realisiert.<br><br>\r\n\r\nIndividuelle Lösungen im Einfamilienhaus- und Mehrfamilienhausbereich und im Bereich der Umnutzungen, Erweiterungen und Sanierungen von bestehenden Gebäude sind dabei entstanden.<br><br>\r\n\r\nDie jeweilige Bausituation wird erfasst und in Abstimmung mit den Anforderungen, Gegebenheiten und Möglichkeiten wird\r\njedes Projekt bearbeitet. Der Zusammenklang von Architektur, der Umgebung und den individuellen Bauaufgaben ist das Ziel.<br><br>\r\n\r\nDie Aufgabe führt durch den kreativen Entwurfsprozess zur konkreten Ausführungs-planung mit den individuellen Details. Meine langjährige Erfahrung bei der Begleitung der Ausführung der\r\nArbeiten fließt in die einzelnen Schritte mit ein.<br><br>\r\n\r\nDas Bauen ist für alle Beteiligten eine vielseitige Herausforderung. Die eingesetzten Lösungen für die Konstruktionen und eine zeitgemäße Technologie sollen den Nutzen und den Erhalt der Gebäude über eine lange Lebensdauer\r\ngewähren.<br><br>\r\n\r\nAlles zusammen eine Aufgabe, die immer wieder begeistert!</p>'),
(730, 154, '_meine_philosophie_details', 'field_62a72e7142eba'),
(731, 154, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(732, 154, '_action_heading', 'field_62a732bacc3f5'),
(733, 154, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(734, 154, '_action_sub_heading', 'field_62a732c6cc3f6'),
(735, 154, 'action_button_link', 'javascript:void(0)'),
(736, 154, '_action_button_link', 'field_62a732cecc3f7'),
(737, 154, 'name', 'Mein Lebenslauf'),
(738, 154, '_name', 'field_62a734add4d3d'),
(739, 154, 'my_image', '150'),
(740, 154, '_my_image', 'field_62a814b957086'),
(741, 154, 'from_to_1', '1978-82'),
(742, 154, '_from_to_1', 'field_62a734b7d4d3e'),
(743, 154, 'detail_1', 'Studium Innenarchitektur FH Rosenheim'),
(744, 154, '_detail_1', 'field_62a734d6d4d3f'),
(745, 154, 'from_to_2', '1983-85'),
(746, 154, '_from_to_2', 'field_62a73500d4d40'),
(747, 154, 'detail_2', 'Aufbaustudium Architektur FH München<br><br>Gastsemester bei Frei Otto am Institur für leichte Flächentragwerke in Stuttgart<br><br>Mitarbeit im Büro Prof. W. Betsch, München'),
(748, 154, '_detail_2', 'field_62a7350dd4d41'),
(749, 154, 'from_to_3', '1985-88'),
(750, 154, '_from_to_3', 'field_62a7351ad4d42'),
(751, 154, 'detail_3', 'angestellt im Büro R. Lagally, München'),
(752, 154, '_detail_3', 'field_62a73525d4d43'),
(753, 154, 'from_to_4', '1989'),
(754, 154, '_from_to_4', 'field_62a7354bd4d44'),
(755, 154, 'detail_4', 'Selbstständig'),
(756, 154, '_detail_4', 'field_62a7355dd4d45'),
(757, 154, 'from_to_5', '1992'),
(758, 154, '_from_to_5', 'field_62a735711379d'),
(759, 154, 'detail_5', 'Mitgliedschaft Bayr. Architektenkammer'),
(760, 154, '_detail_5', 'field_62a7357c1379e'),
(761, 156, '_edit_last', '1'),
(762, 156, '_edit_lock', '1655186254:1'),
(763, 158, '_edit_last', '1'),
(764, 158, '_edit_lock', '1655186277:1'),
(765, 160, '_edit_last', '1'),
(766, 160, '_edit_lock', '1655186302:1'),
(767, 162, '_edit_last', '1'),
(768, 162, '_edit_lock', '1655186328:1'),
(769, 165, '_edit_last', '1'),
(770, 165, '_edit_lock', '1655186346:1'),
(771, 167, '_edit_last', '1'),
(772, 167, '_edit_lock', '1655186368:1'),
(773, 169, '_edit_last', '1'),
(774, 169, '_edit_lock', '1655186385:1'),
(775, 171, '_edit_last', '1'),
(776, 171, '_edit_lock', '1655186409:1'),
(777, 173, '_edit_last', '1'),
(778, 173, '_edit_lock', '1655186467:1'),
(779, 176, '_edit_last', '1'),
(780, 176, '_edit_lock', '1655186490:1'),
(781, 178, '_edit_last', '1'),
(782, 178, '_edit_lock', '1655186509:1'),
(783, 180, '_edit_last', '1'),
(784, 180, '_edit_lock', '1655186531:1'),
(785, 182, '_edit_last', '1'),
(786, 182, '_edit_lock', '1655186567:1'),
(787, 184, '_edit_last', '1'),
(788, 184, '_edit_lock', '1655186590:1'),
(789, 186, '_edit_last', '1'),
(790, 186, '_edit_lock', '1655186633:1'),
(791, 188, '_edit_last', '1'),
(792, 188, '_edit_lock', '1655186677:1'),
(793, 191, '_edit_last', '1'),
(794, 191, '_edit_lock', '1655186700:1'),
(795, 193, '_edit_last', '1'),
(796, 193, '_edit_lock', '1655186761:1'),
(797, 195, '_edit_last', '1'),
(798, 195, '_edit_lock', '1655186786:1'),
(799, 197, '_edit_last', '1'),
(800, 197, '_edit_lock', '1655186810:1'),
(801, 199, '_edit_last', '1'),
(802, 199, '_edit_lock', '1655186843:1'),
(803, 201, '_edit_last', '1'),
(804, 201, '_edit_lock', '1655186862:1'),
(805, 203, '_edit_last', '1'),
(806, 203, '_edit_lock', '1655186884:1'),
(807, 205, '_edit_last', '1'),
(808, 205, '_edit_lock', '1655197050:1'),
(809, 205, 'cfs_fields', 'a:4:{i:0;a:8:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:16:\"project_timeline\";s:5:\"label\";s:16:\"Project Timeline\";s:4:\"type\";s:4:\"loop\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:0;s:6:\"weight\";i:0;s:7:\"options\";a:5:{s:11:\"row_display\";s:1:\"0\";s:9:\"row_label\";s:9:\"Timelines\";s:12:\"button_label\";s:16:\"Add New Timeline\";s:9:\"limit_min\";s:0:\"\";s:9:\"limit_max\";s:0:\"\";}}i:1;a:8:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:12:\"project_year\";s:5:\"label\";s:12:\"Project Year\";s:4:\"type\";s:4:\"text\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:1;s:6:\"weight\";i:1;s:7:\"options\";a:2:{s:13:\"default_value\";s:0:\"\";s:8:\"required\";s:1:\"0\";}}i:2;a:8:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:8:\"projects\";s:5:\"label\";s:8:\"Projects\";s:4:\"type\";s:4:\"loop\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:1;s:6:\"weight\";i:2;s:7:\"options\";a:5:{s:11:\"row_display\";s:1:\"0\";s:9:\"row_label\";s:14:\"Project Labels\";s:12:\"button_label\";s:15:\"Add New Project\";s:9:\"limit_min\";s:0:\"\";s:9:\"limit_max\";s:0:\"\";}}i:3;a:8:{s:2:\"id\";s:1:\"4\";s:4:\"name\";s:13:\"project_label\";s:5:\"label\";s:13:\"Project Label\";s:4:\"type\";s:4:\"text\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:3;s:6:\"weight\";i:3;s:7:\"options\";a:2:{s:13:\"default_value\";s:0:\"\";s:8:\"required\";s:1:\"0\";}}}'),
(810, 205, 'cfs_rules', 'a:2:{s:10:\"post_types\";a:2:{s:8:\"operator\";s:2:\"==\";s:6:\"values\";a:1:{i:0;s:4:\"page\";}}s:8:\"post_ids\";a:2:{s:8:\"operator\";s:2:\"==\";s:6:\"values\";a:1:{i:0;s:2:\"10\";}}}'),
(811, 205, 'cfs_extras', 'a:3:{s:5:\"order\";s:1:\"0\";s:7:\"context\";s:6:\"normal\";s:11:\"hide_editor\";s:1:\"0\";}'),
(821, 206, '_edit_last', '1'),
(822, 206, '_edit_lock', '1655191085:1'),
(823, 207, '_wp_attached_file', '2022/06/IMG_20220318_122011-a-a2-scaled.jpg'),
(824, 207, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:43:\"2022/06/IMG_20220318_122011-a-a2-scaled.jpg\";s:8:\"filesize\";i:883692;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122011-a-a2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15674;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"IMG_20220318_122011-a-a2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:157956;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122011-a-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6419;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122011-a-a2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:89423;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122011-a-a2-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:346663;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122011-a-a2-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:593462;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122011-a-a2-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:361024;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647606012\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.001441\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:28:\"IMG_20220318_122011-a-a2.jpg\";}'),
(825, 206, '_thumbnail_id', '207'),
(826, 209, '_edit_last', '1'),
(827, 209, '_edit_lock', '1655191485:1'),
(838, 10, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(839, 10, '_action_heading', 'field_62a831b98e1be'),
(840, 10, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(841, 10, '_action_sub_heading', 'field_62a831c08e1bf'),
(842, 10, 'action_button_link', 'javascript:void(0)'),
(843, 10, '_action_button_link', 'field_62a831c38e1c0'),
(844, 215, 'action_heading', 'Ich kümmer mich um Ihr individuelles Anliegen!'),
(845, 215, '_action_heading', 'field_62a831b98e1be'),
(846, 215, 'action_sub_heading', 'Gerne können Sie mich kontaktieren und wir sprechen gemeinsam über Ihr neues Bauvorhaben!'),
(847, 215, '_action_sub_heading', 'field_62a831c08e1bf'),
(848, 215, 'action_button_link', 'javascript:void(0)'),
(849, 215, '_action_button_link', 'field_62a831c38e1c0'),
(850, 221, '_edit_last', '1'),
(851, 221, '_edit_lock', '1655196774:1'),
(852, 221, 'cfs_fields', 'a:2:{i:0;a:8:{s:2:\"id\";s:1:\"5\";s:4:\"name\";s:11:\"add_gallery\";s:5:\"label\";s:11:\"Add Gallery\";s:4:\"type\";s:4:\"loop\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:0;s:6:\"weight\";i:0;s:7:\"options\";a:5:{s:11:\"row_display\";s:1:\"0\";s:9:\"row_label\";s:9:\"Galleries\";s:12:\"button_label\";s:15:\"Add New Gallery\";s:9:\"limit_min\";s:0:\"\";s:9:\"limit_max\";s:0:\"\";}}i:1;a:8:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:9:\"add_image\";s:5:\"label\";s:9:\"Add Image\";s:4:\"type\";s:4:\"file\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:5;s:6:\"weight\";i:1;s:7:\"options\";a:3:{s:9:\"file_type\";s:5:\"image\";s:12:\"return_value\";s:3:\"url\";s:8:\"required\";s:1:\"0\";}}}'),
(853, 221, 'cfs_rules', 'a:1:{s:10:\"post_types\";a:2:{s:8:\"operator\";s:2:\"==\";s:6:\"values\";a:1:{i:0;s:13:\"cpt_portfolio\";}}}'),
(854, 221, 'cfs_extras', 'a:3:{s:5:\"order\";s:1:\"0\";s:7:\"context\";s:6:\"normal\";s:11:\"hide_editor\";s:1:\"0\";}'),
(855, 223, '_wp_attached_file', '2022/06/IMG_20220318_122037-a2-scaled.jpg'),
(856, 223, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:4:\"file\";s:41:\"2022/06/IMG_20220318_122037-a2-scaled.jpg\";s:8:\"filesize\";i:681249;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_122037-a2-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15018;}s:5:\"large\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_122037-a2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:134495;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_122037-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6273;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_122037-a2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:134495;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122037-a2-1152x1536.jpg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:277784;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122037-a2-1536x2048.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:461342;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122037-a2-1568x2091.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:2091;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:479028;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647606038\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.001645\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:26:\"IMG_20220318_122037-a2.jpg\";}'),
(857, 224, '_wp_attached_file', '2022/06/IMG_20220318_122359-a-a2-scaled.jpg'),
(858, 224, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1698;s:4:\"file\";s:43:\"2022/06/IMG_20220318_122359-a-a2-scaled.jpg\";s:8:\"filesize\";i:414942;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122359-a-a2-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13387;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"IMG_20220318_122359-a-a2-1024x679.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:679;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:103057;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122359-a-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5967;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122359-a-a2-768x510.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:66257;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122359-a-a2-1536x1019.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1019;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:190369;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122359-a-a2-2048x1359.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1359;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:293728;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122359-a-a2-1568x1040.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1040;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:195773;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"dig\";s:17:\"created_timestamp\";s:10:\"1647606240\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.001179\";s:5:\"title\";s:3:\"dig\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:28:\"IMG_20220318_122359-a-a2.jpg\";}'),
(859, 225, '_wp_attached_file', '2022/06/IMG_20220318_122507-a-a2-scaled.jpg'),
(860, 225, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1765;s:4:\"file\";s:43:\"2022/06/IMG_20220318_122507-a-a2-scaled.jpg\";s:8:\"filesize\";i:607390;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122507-a-a2-300x207.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:207;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17395;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"IMG_20220318_122507-a-a2-1024x706.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:706;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:155635;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122507-a-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6756;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_122507-a-a2-768x529.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:529;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:97760;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122507-a-a2-1536x1059.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1059;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:285495;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122507-a-a2-2048x1412.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1412;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:437540;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122507-a-a2-1568x1081.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1081;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:293616;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"dig\";s:17:\"created_timestamp\";s:10:\"1647606308\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.002433\";s:5:\"title\";s:3:\"dig\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:28:\"IMG_20220318_122507-a-a2.jpg\";}'),
(861, 226, '_wp_attached_file', '2022/06/IMG_20220318_122011-a-a2-1-scaled.jpg'),
(862, 226, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:45:\"2022/06/IMG_20220318_122011-a-a2-1-scaled.jpg\";s:8:\"filesize\";i:883692;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122011-a-a2-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15674;}s:5:\"large\";a:5:{s:4:\"file\";s:39:\"IMG_20220318_122011-a-a2-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:157956;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122011-a-a2-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6419;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_122011-a-a2-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:89423;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:40:\"IMG_20220318_122011-a-a2-1-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:346663;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:40:\"IMG_20220318_122011-a-a2-1-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:593462;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:40:\"IMG_20220318_122011-a-a2-1-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:361024;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647606012\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.001441\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:30:\"IMG_20220318_122011-a-a2-1.jpg\";}'),
(863, 206, 'add_image', '223'),
(864, 206, 'add_image', '224'),
(865, 206, 'add_image', '225'),
(866, 206, 'add_image', ''),
(867, 227, '_wp_attached_file', '2022/06/IMG_20220318_113354-a2-scaled.jpg'),
(868, 227, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:2305;s:4:\"file\";s:41:\"2022/06/IMG_20220318_113354-a2-scaled.jpg\";s:8:\"filesize\";i:1044672;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_113354-a2-300x270.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:21712;}s:5:\"large\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_113354-a2-1024x922.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:221398;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_113354-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7172;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_113354-a2-768x691.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:691;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:129155;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_113354-a2-1536x1383.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:454214;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_113354-a2-2048x1844.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1844;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:731842;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_113354-a2-1568x1412.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1412;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:471415;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647603235\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000852\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:26:\"IMG_20220318_113354-a2.jpg\";}'),
(869, 228, '_wp_attached_file', '2022/06/IMG_20220318_113429-a2-scaled.jpg'),
(870, 228, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:41:\"2022/06/IMG_20220318_113429-a2-scaled.jpg\";s:8:\"filesize\";i:800243;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_113429-a2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16315;}s:5:\"large\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_113429-a2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:151240;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_113429-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6500;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_113429-a2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:88252;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_113429-a2-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:322451;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_113429-a2-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:541159;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_113429-a2-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:334788;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647603269\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000822\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:26:\"IMG_20220318_113429-a2.jpg\";}'),
(871, 229, '_wp_attached_file', '2022/06/main-IMG_20220318_115746-a2-scaled.jpg'),
(872, 229, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:46:\"2022/06/main-IMG_20220318_115746-a2-scaled.jpg\";s:8:\"filesize\";i:1350418;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:39:\"main-IMG_20220318_115746-a2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27875;}s:5:\"large\";a:5:{s:4:\"file\";s:40:\"main-IMG_20220318_115746-a2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:282933;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:39:\"main-IMG_20220318_115746-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9941;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:39:\"main-IMG_20220318_115746-a2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:164848;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:41:\"main-IMG_20220318_115746-a2-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:586258;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:41:\"main-IMG_20220318_115746-a2-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:948003;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:41:\"main-IMG_20220318_115746-a2-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:607411;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"sdr\";s:17:\"created_timestamp\";s:10:\"1647604668\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000941\";s:5:\"title\";s:3:\"sdr\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:31:\"main-IMG_20220318_115746-a2.jpg\";}'),
(873, 48, 'add_image', '227'),
(874, 48, 'add_image', '228'),
(875, 48, 'add_image', '229'),
(876, 230, '_wp_attached_file', '2022/06/IMG_20220124_120235-scaled.jpg'),
(877, 230, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:4:\"file\";s:38:\"2022/06/IMG_20220124_120235-scaled.jpg\";s:8:\"filesize\";i:851297;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:31:\"IMG_20220124_120235-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19218;}s:5:\"large\";a:5:{s:4:\"file\";s:32:\"IMG_20220124_120235-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:177528;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:31:\"IMG_20220124_120235-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7633;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:32:\"IMG_20220124_120235-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:177528;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_120235-1152x1536.jpg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:364980;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_120235-1536x2048.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:593353;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_120235-1568x2091.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:2091;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:615936;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"sdr\";s:17:\"created_timestamp\";s:10:\"1643025756\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000892\";s:5:\"title\";s:3:\"sdr\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:23:\"IMG_20220124_120235.jpg\";}'),
(878, 231, '_wp_attached_file', '2022/06/IMG_20220124_115548-scaled.jpg'),
(879, 231, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:4:\"file\";s:38:\"2022/06/IMG_20220124_115548-scaled.jpg\";s:8:\"filesize\";i:840235;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:31:\"IMG_20220124_115548-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24283;}s:5:\"large\";a:5:{s:4:\"file\";s:32:\"IMG_20220124_115548-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:220833;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:31:\"IMG_20220124_115548-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9220;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:32:\"IMG_20220124_115548-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:220833;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_115548-1152x1536.jpg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:406486;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_115548-1536x2048.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:613333;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_115548-1568x2091.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:2091;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:632700;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"dig\";s:17:\"created_timestamp\";s:10:\"1643025349\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000633\";s:5:\"title\";s:3:\"dig\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:23:\"IMG_20220124_115548.jpg\";}'),
(880, 232, '_wp_attached_file', '2022/06/IMG_20220124_115426-2-scaled.jpg'),
(881, 232, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:40:\"2022/06/IMG_20220124_115426-2-scaled.jpg\";s:8:\"filesize\";i:833429;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_115426-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:22619;}s:5:\"large\";a:5:{s:4:\"file\";s:34:\"IMG_20220124_115426-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:214408;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_115426-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8145;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:33:\"IMG_20220124_115426-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:132121;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:35:\"IMG_20220124_115426-2-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:399949;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:35:\"IMG_20220124_115426-2-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:605919;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:35:\"IMG_20220124_115426-2-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:412243;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"dig\";s:17:\"created_timestamp\";s:10:\"1643025267\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000829\";s:5:\"title\";s:3:\"dig\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:25:\"IMG_20220124_115426-2.jpg\";}'),
(882, 233, '_wp_attached_file', '2022/06/main-IMG_20220124_120056-scaled.jpg'),
(883, 233, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:43:\"2022/06/main-IMG_20220124_120056-scaled.jpg\";s:8:\"filesize\";i:850012;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:36:\"main-IMG_20220124_120056-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18436;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"main-IMG_20220124_120056-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:171689;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:36:\"main-IMG_20220124_120056-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7089;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:36:\"main-IMG_20220124_120056-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:100478;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:38:\"main-IMG_20220124_120056-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:358026;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:38:\"main-IMG_20220124_120056-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:587158;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:38:\"main-IMG_20220124_120056-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:371590;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1643025656\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000761\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:28:\"main-IMG_20220124_120056.jpg\";}'),
(884, 51, 'add_image', '230'),
(885, 51, 'add_image', '231'),
(886, 51, 'add_image', '232'),
(887, 51, 'add_image', '233'),
(888, 234, '_wp_attached_file', '2022/06/IMG_20220318_111749-a2.jpg'),
(889, 234, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2462;s:6:\"height\";i:2024;s:4:\"file\";s:34:\"2022/06/IMG_20220318_111749-a2.jpg\";s:8:\"filesize\";i:1381034;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_111749-a2-300x247.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:247;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20531;}s:5:\"large\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_111749-a2-1024x842.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:842;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:188473;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_111749-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7445;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_111749-a2-768x631.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:631;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:111225;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_111749-a2-1536x1263.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1263;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:383583;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_111749-a2-2048x1684.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1684;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:625374;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_111749-a2-1568x1289.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1289;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:397430;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647602270\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000593\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(890, 235, '_wp_attached_file', '2022/06/IMG_20220318_111626_12-a2-scaled.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(891, 235, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:4:\"file\";s:44:\"2022/06/IMG_20220318_111626_12-a2-scaled.jpg\";s:8:\"filesize\";i:822993;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:37:\"IMG_20220318_111626_12-a2-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17087;}s:5:\"large\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_111626_12-a2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:159053;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:37:\"IMG_20220318_111626_12-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6734;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:38:\"IMG_20220318_111626_12-a2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:159053;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:39:\"IMG_20220318_111626_12-a2-1152x1536.jpg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:336749;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:39:\"IMG_20220318_111626_12-a2-1536x2048.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:561702;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:39:\"IMG_20220318_111626_12-a2-1568x2091.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:2091;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:582459;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"sdr\";s:17:\"created_timestamp\";s:10:\"1647602187\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.001348\";s:5:\"title\";s:3:\"sdr\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:29:\"IMG_20220318_111626_12-a2.jpg\";}'),
(892, 236, '_wp_attached_file', '2022/06/IMG_20220318_111749-ba2.jpg'),
(893, 236, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2037;s:6:\"height\";i:1454;s:4:\"file\";s:35:\"2022/06/IMG_20220318_111749-ba2.jpg\";s:8:\"filesize\";i:915309;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_111749-ba2-300x214.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20281;}s:5:\"large\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_111749-ba2-1024x731.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:731;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:180532;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_111749-ba2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8246;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_111749-ba2-768x548.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:548;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:108459;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:37:\"IMG_20220318_111749-ba2-1536x1096.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1096;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:356251;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:37:\"IMG_20220318_111749-ba2-1568x1119.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1119;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:368579;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647602270\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000593\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(894, 237, '_wp_attached_file', '2022/06/IMG_20220318_111946-a2-scaled.jpg'),
(895, 237, '_wp_attachment_metadata', 'a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:41:\"2022/06/IMG_20220318_111946-a2-scaled.jpg\";s:8:\"filesize\";i:883340;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_111946-a2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19184;}s:5:\"large\";a:5:{s:4:\"file\";s:35:\"IMG_20220318_111946-a2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:172838;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_111946-a2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7399;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:34:\"IMG_20220318_111946-a2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:101757;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_111946-a2-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:360825;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_111946-a2-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:599240;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:36:\"IMG_20220318_111946-a2-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:374460;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"EVA-L09\";s:7:\"caption\";s:3:\"cof\";s:17:\"created_timestamp\";s:10:\"1647602386\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"4.5\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:8:\"0.000946\";s:5:\"title\";s:3:\"cof\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:26:\"IMG_20220318_111946-a2.jpg\";}'),
(896, 54, 'add_image', '234'),
(897, 54, 'add_image', '235'),
(898, 54, 'add_image', '236'),
(899, 54, 'add_image', '237'),
(900, 238, '_edit_last', '1'),
(901, 238, '_edit_lock', '1655197187:1'),
(902, 238, 'cfs_fields', 'a:3:{i:0;a:8:{s:2:\"id\";s:1:\"7\";s:4:\"name\";s:16:\"timeline_summary\";s:5:\"label\";s:16:\"Timeline Summary\";s:4:\"type\";s:4:\"loop\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:0;s:6:\"weight\";i:0;s:7:\"options\";a:5:{s:11:\"row_display\";s:1:\"0\";s:9:\"row_label\";s:7:\"Summary\";s:12:\"button_label\";s:15:\"Add New Summary\";s:9:\"limit_min\";s:0:\"\";s:9:\"limit_max\";s:0:\"\";}}i:1;a:8:{s:2:\"id\";s:1:\"8\";s:4:\"name\";s:4:\"year\";s:5:\"label\";s:4:\"Year\";s:4:\"type\";s:4:\"text\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:7;s:6:\"weight\";i:1;s:7:\"options\";a:2:{s:13:\"default_value\";s:0:\"\";s:8:\"required\";s:1:\"0\";}}i:2;a:8:{s:2:\"id\";s:1:\"9\";s:4:\"name\";s:7:\"details\";s:5:\"label\";s:7:\"Details\";s:4:\"type\";s:8:\"textarea\";s:5:\"notes\";s:0:\"\";s:9:\"parent_id\";i:7;s:6:\"weight\";i:2;s:7:\"options\";a:3:{s:13:\"default_value\";s:0:\"\";s:10:\"formatting\";s:7:\"auto_br\";s:8:\"required\";s:1:\"0\";}}}'),
(903, 238, 'cfs_rules', 'a:2:{s:10:\"post_types\";a:2:{s:8:\"operator\";s:2:\"==\";s:6:\"values\";a:1:{i:0;s:4:\"page\";}}s:8:\"post_ids\";a:2:{s:8:\"operator\";s:2:\"==\";s:6:\"values\";a:1:{i:0;s:3:\"123\";}}}'),
(904, 238, 'cfs_extras', 'a:3:{s:5:\"order\";s:1:\"0\";s:7:\"context\";s:6:\"normal\";s:11:\"hide_editor\";s:1:\"0\";}'),
(905, 123, 'year', '1978-82'),
(906, 123, 'details', 'Studium Innenarchitektur FH Rosenheim'),
(907, 123, 'year', '1983-85'),
(908, 123, 'details', 'Aufbaustudium Architektur FH München<br><br>Gastsemester bei Frei Otto am Institur für leichte Flächentragwerke in Stuttgart<br><br>Mitarbeit im Büro Prof. W. Betsch, München'),
(909, 123, 'year', '1985-88'),
(910, 123, 'details', 'angestellt im Büro R. Lagally, München'),
(911, 123, 'year', '1989'),
(912, 123, 'details', 'Selbstständig'),
(913, 123, 'year', '1992'),
(914, 123, 'details', 'Mitgliedschaft Bayr. Architektenkammer'),
(953, 10, 'project_year', '2000'),
(954, 10, 'project_label', ' EFH Wörthsee'),
(955, 10, 'project_year', '2001'),
(956, 10, 'project_label', 'Sanierung/Umbau denkmalgeschütztes Haus Inning a. A.'),
(957, 10, 'project_label', 'Umbau Wirtschaftsgebäude in Wohnhaus Zankenhausen'),
(958, 10, 'project_year', '2002'),
(959, 10, 'project_label', 'Umbau EFH in 2-Familienhaus Herrsching'),
(960, 10, 'project_year', '2003'),
(961, 10, 'project_label', 'Umbau EFH Wörthsee'),
(962, 10, 'project_year', '2004'),
(963, 10, 'project_label', 'Umbau u. Sanierung EFH Bachern'),
(964, 10, 'project_year', '2005'),
(965, 10, 'project_label', 'EFH Markt Wald'),
(966, 10, 'project_year', '2006'),
(967, 10, 'project_label', 'Anbau a. DHH Weßling'),
(968, 10, 'project_year', '2007'),
(969, 10, 'project_label', 'EFH Wörthsee'),
(970, 10, 'project_year', '2008'),
(971, 10, 'project_label', 'Umbau/Anbau 2-Familienhaus Weßling'),
(972, 10, 'project_label', 'EFH Breitbrunn'),
(973, 10, 'project_label', 'EFH m. Einliegerwohnung Allach'),
(974, 10, 'project_year', '2009'),
(975, 10, 'project_label', 'Umbau/Anbau u. Sanierung EFH Wörthsee'),
(976, 10, 'project_year', '2010'),
(977, 10, 'project_label', 'MFH u. Anbau an 2-Familienhaus Grafrath'),
(978, 10, 'project_label', 'EFH Hechendorf'),
(979, 10, 'project_year', '2011'),
(980, 10, 'project_label', 'Neubau DG u. Sanierung EFH Puchheim'),
(981, 10, 'project_year', '2012'),
(982, 10, 'project_label', 'Entwurf Ausbau Tenne'),
(983, 10, 'project_label', 'Anbau EFH Breitbrunn'),
(984, 10, 'project_year', '2013'),
(985, 10, 'project_label', 'MFH Wörthsee'),
(986, 10, 'project_label', 'EFH Gräfelfing'),
(987, 10, 'project_year', '2014'),
(988, 10, 'project_label', 'Neugestaltung Praxisräume Gilching'),
(989, 10, 'project_label', 'Anbau/Umbau/Sanierung EFH Lochhausen'),
(990, 10, 'project_label', 'Energetische Sanierung EFH Steinbach'),
(991, 10, 'project_year', '2015'),
(992, 10, 'project_label', 'Zweifamilienhaus Geisenbrunn'),
(993, 10, 'project_label', 'Ausbau DG Herrsching'),
(994, 10, 'project_label', 'Ausbau DG u. Sanierung EFH Unterpfaffenhofen'),
(995, 10, 'project_year', '2016'),
(996, 10, 'project_label', 'Umbau u. Sanierung EFH Weßling'),
(997, 10, 'project_year', '2017'),
(998, 10, 'project_label', 'Energetische Sanierung EFH Steinebach'),
(999, 10, 'project_label', 'Anbau/Umbau e. EFH zum Zweifamilienhaus Oberpfaffenhofen'),
(1000, 10, 'project_label', 'Anbau an MFH Steinebach'),
(1001, 10, 'project_year', '2018'),
(1002, 10, 'project_label', 'Anbau a. EFH zum Doppelhaus Wörthsee'),
(1003, 10, 'project_label', 'Außenanlagen EFH Breitbrunn'),
(1004, 10, 'project_year', '2019'),
(1005, 10, 'project_label', 'Anbau an DHH Weßling'),
(1006, 10, 'project_label', 'Ausbau Dachgeschoss Hanfeld'),
(1007, 10, 'project_year', '2020'),
(1008, 10, 'project_label', 'Anbau an EFH Wörthsee'),
(1009, 10, 'project_label', 'Sanierung EFH Wörthsee'),
(1010, 10, 'project_label', 'Umbau Wohn- und Wirtschaftsgebäude München/Aubing zu MFH'),
(1011, 10, 'project_year', '2021'),
(1012, 10, 'project_label', 'Umbau Wohn- und Wirtschaftsgebäude München/Aubing zu MFH'),
(1013, 10, 'project_year', '2022'),
(1014, 10, 'project_label', 'EFH Wörthsee'),
(1015, 10, 'project_label', 'Anbau/Umbau DHH Unterpfaffenhofen'),
(1018, 246, '_wp_attached_file', '2022/06/call_to_action.jpg'),
(1019, 246, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:440;s:4:\"file\";s:26:\"2022/06/call_to_action.jpg\";s:8:\"filesize\";i:35718;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:25:\"call_to_action-300x69.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:69;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4513;}s:5:\"large\";a:5:{s:4:\"file\";s:27:\"call_to_action-1024x235.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:235;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25577;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"call_to_action-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2704;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:26:\"call_to_action-768x176.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:176;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16163;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:27:\"call_to_action-1536x352.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:352;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:45241;}s:14:\"post-thumbnail\";a:5:{s:4:\"file\";s:27:\"call_to_action-1568x359.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:359;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:46757;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-06-10 12:06:56', '2022-06-10 12:06:56', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2022-06-10 12:06:56', '2022-06-10 12:06:56', '', 0, 'http://localhost/sponner/?p=1', 0, 'post', '', 1),
(2, 1, '2022-06-10 12:06:56', '2022-06-10 12:06:56', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/sponner/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2022-06-13 09:40:23', '2022-06-13 09:40:23', '', 0, 'http://localhost/sponner/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-06-10 12:06:56', '2022-06-10 12:06:56', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/sponner.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2022-06-13 09:40:28', '2022-06-13 09:40:28', '', 0, 'http://localhost/sponner/?page_id=3', 0, 'page', '', 0),
(5, 1, '2022-06-10 12:49:45', '2022-06-10 12:49:45', '<label> Your name\n    [text* your-name] </label>\n\n<label> Your email\n    [email* your-email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit \"Submit\"]\n[_site_title] \"[your-subject]\"\n[_site_title] <Animesh.codearts@gmail.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\n[_site_admin_email]\nReply-To: [your-email]\n\n0\n0\n\n[_site_title] \"[your-subject]\"\n[_site_title] <Animesh.codearts@gmail.com>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\n[your-email]\nReply-To: [_site_admin_email]\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2022-06-10 12:49:45', '2022-06-10 12:49:45', '', 0, 'http://localhost/sponner/?post_type=wpcf7_contact_form&p=5', 0, 'wpcf7_contact_form', '', 0),
(6, 1, '2022-06-13 04:53:03', '2022-06-13 04:53:03', '', 'Startseite', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-06-13 10:56:47', '2022-06-13 10:56:47', '', 0, 'https://localhost/sponner/?page_id=6', 0, 'page', '', 0),
(7, 1, '2022-06-13 04:53:03', '2022-06-13 04:53:03', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 04:53:03', '2022-06-13 04:53:03', '', 6, 'https://localhost/sponner/?p=7', 0, 'revision', '', 0),
(8, 1, '2022-06-13 04:53:36', '2022-06-13 04:53:36', '', 'Kontakt', '', 'publish', 'closed', 'closed', '', 'kontakt', '', '', '2022-06-14 04:59:32', '2022-06-14 04:59:32', '', 0, 'https://localhost/sponner/?page_id=8', 0, 'page', '', 0),
(9, 1, '2022-06-13 04:53:36', '2022-06-13 04:53:36', '', 'kontakt', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2022-06-13 04:53:36', '2022-06-13 04:53:36', '', 8, 'https://localhost/sponner/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-06-13 04:54:58', '2022-06-13 04:54:58', '', 'Projekte', '', 'publish', 'closed', 'closed', '', 'projekte', '', '', '2022-06-14 10:14:31', '2022-06-14 10:14:31', '', 0, 'https://localhost/sponner/?page_id=10', 0, 'page', '', 0),
(11, 1, '2022-06-13 04:54:58', '2022-06-13 04:54:58', '', 'projekte', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-06-13 04:54:58', '2022-06-13 04:54:58', '', 10, 'https://localhost/sponner/?p=11', 0, 'revision', '', 0),
(12, 1, '2022-06-13 04:55:11', '2022-06-13 04:55:11', '', 'uber-mich', '', 'trash', 'closed', 'closed', '', 'uber-mich__trashed', '', '', '2022-06-14 04:54:23', '2022-06-14 04:54:23', '', 0, 'https://localhost/sponner/?page_id=12', 0, 'page', '', 0),
(13, 1, '2022-06-13 04:55:11', '2022-06-13 04:55:11', '', 'uber-mich', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2022-06-13 04:55:11', '2022-06-13 04:55:11', '', 12, 'https://localhost/sponner/?p=13', 0, 'revision', '', 0),
(14, 1, '2022-06-13 08:53:48', '2022-06-13 08:53:48', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:10:\"cpt_banner\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Banner', 'banner', 'publish', 'closed', 'closed', '', 'group_62a6fb12ea45c', '', '', '2022-06-13 08:57:23', '2022-06-13 08:57:23', '', 0, 'https://localhost/sponner/?post_type=acf-field-group&#038;p=14', 0, 'acf-field-group', '', 0),
(15, 1, '2022-06-13 08:57:23', '2022-06-13 08:57:23', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Main Heading', 'main_heading', 'publish', 'closed', 'closed', '', 'field_62a6fb7c94fd4', '', '', '2022-06-13 08:57:23', '2022-06-13 08:57:23', '', 14, 'https://localhost/sponner/?post_type=acf-field&p=15', 0, 'acf-field', '', 0),
(16, 1, '2022-06-13 08:57:23', '2022-06-13 08:57:23', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Sub Heading', 'sub_heading', 'publish', 'closed', 'closed', '', 'field_62a6fb9294fd5', '', '', '2022-06-13 08:57:23', '2022-06-13 08:57:23', '', 14, 'https://localhost/sponner/?post_type=acf-field&p=16', 1, 'acf-field', '', 0),
(17, 1, '2022-06-13 08:57:23', '2022-06-13 08:57:23', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Button Text', 'button_text', 'publish', 'closed', 'closed', '', 'field_62a6fbc294fd6', '', '', '2022-06-13 08:57:23', '2022-06-13 08:57:23', '', 14, 'https://localhost/sponner/?post_type=acf-field&p=17', 2, 'acf-field', '', 0),
(18, 1, '2022-06-13 08:57:23', '2022-06-13 08:57:23', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Button Link', 'button_link', 'publish', 'closed', 'closed', '', 'field_62a6fbd494fd7', '', '', '2022-06-13 08:57:23', '2022-06-13 08:57:23', '', 14, 'https://localhost/sponner/?post_type=acf-field&p=18', 3, 'acf-field', '', 0),
(19, 1, '2022-06-13 08:58:47', '2022-06-13 08:58:47', '', 'Slide One', '', 'publish', 'open', 'closed', '', 'slide-one', '', '', '2022-06-13 08:58:47', '2022-06-13 08:58:47', '', 0, 'https://localhost/sponner/?post_type=cpt_banner&#038;p=19', 0, 'cpt_banner', '', 0),
(20, 1, '2022-06-13 08:58:42', '2022-06-13 08:58:42', '', 's1', '', 'inherit', 'open', 'closed', '', 's1', '', '', '2022-06-13 08:58:42', '2022-06-13 08:58:42', '', 19, 'http://localhost/sponner/wp-content/uploads/2022/06/s1.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 1, '2022-06-13 08:58:47', '2022-06-13 08:58:47', '', 'Slide One', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2022-06-13 08:58:47', '2022-06-13 08:58:47', '', 19, 'https://localhost/sponner/?p=21', 0, 'revision', '', 0),
(22, 1, '2022-06-13 08:59:41', '2022-06-13 08:59:41', '', 'Slide Two', '', 'publish', 'open', 'closed', '', 'slide-two', '', '', '2022-06-13 08:59:41', '2022-06-13 08:59:41', '', 0, 'https://localhost/sponner/?post_type=cpt_banner&#038;p=22', 0, 'cpt_banner', '', 0),
(23, 1, '2022-06-13 08:59:35', '2022-06-13 08:59:35', '', 's2', '', 'inherit', 'open', 'closed', '', 's2', '', '', '2022-06-13 08:59:35', '2022-06-13 08:59:35', '', 22, 'http://localhost/sponner/wp-content/uploads/2022/06/s2.jpg', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2022-06-13 08:59:41', '2022-06-13 08:59:41', '', 'Slide Two', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2022-06-13 08:59:41', '2022-06-13 08:59:41', '', 22, 'https://localhost/sponner/?p=24', 0, 'revision', '', 0),
(25, 1, '2022-06-13 09:00:05', '2022-06-13 09:00:05', '', 'Slide Three', '', 'publish', 'open', 'closed', '', 'slide-three', '', '', '2022-06-13 09:00:05', '2022-06-13 09:00:05', '', 0, 'https://localhost/sponner/?post_type=cpt_banner&#038;p=25', 0, 'cpt_banner', '', 0),
(26, 1, '2022-06-13 09:00:05', '2022-06-13 09:00:05', '', 'Slide Three', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-06-13 09:00:05', '2022-06-13 09:00:05', '', 25, 'https://localhost/sponner/?p=26', 0, 'revision', '', 0),
(27, 1, '2022-06-13 09:00:31', '2022-06-13 09:00:31', '', 'Slide Four', '', 'publish', 'open', 'closed', '', 'slide-four', '', '', '2022-06-13 09:00:31', '2022-06-13 09:00:31', '', 0, 'https://localhost/sponner/?post_type=cpt_banner&#038;p=27', 0, 'cpt_banner', '', 0),
(28, 1, '2022-06-13 09:00:31', '2022-06-13 09:00:31', '', 'Slide Four', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2022-06-13 09:00:31', '2022-06-13 09:00:31', '', 27, 'https://localhost/sponner/?p=28', 0, 'revision', '', 0),
(29, 1, '2022-06-13 09:02:08', '2022-06-13 09:02:08', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"6\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Home', 'home', 'publish', 'closed', 'closed', '', 'group_62a6fcfe847f2', '', '', '2022-06-13 10:40:54', '2022-06-13 10:40:54', '', 0, 'https://localhost/sponner/?post_type=acf-field-group&#038;p=29', 0, 'acf-field-group', '', 0),
(30, 1, '2022-06-13 09:11:13', '2022-06-13 09:11:13', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Banner Sections', 'banner_sections', 'publish', 'closed', 'closed', '', 'field_62a6fd8032a34', '', '', '2022-06-13 09:11:13', '2022-06-13 09:11:13', '', 29, 'https://localhost/sponner/?post_type=acf-field&p=30', 0, 'acf-field', '', 0),
(33, 1, '2022-06-13 09:11:13', '2022-06-13 09:11:13', 'a:12:{s:4:\"type\";s:12:\"relationship\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:10:\"cpt_banner\";}s:8:\"taxonomy\";s:0:\"\";s:7:\"filters\";a:3:{i:0;s:6:\"search\";i:1;s:9:\"post_type\";i:2;s:8:\"taxonomy\";}s:8:\"elements\";a:1:{i:0;s:14:\"featured_image\";}s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:13:\"return_format\";s:2:\"id\";}', 'All Banners', 'all_banners', 'publish', 'closed', 'closed', '', 'field_62a6fe7932a37', '', '', '2022-06-13 10:01:14', '2022-06-13 10:01:14', '', 29, 'https://localhost/sponner/?post_type=acf-field&#038;p=33', 1, 'acf-field', '', 0),
(34, 1, '2022-06-13 09:11:43', '2022-06-13 09:11:43', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 09:11:43', '2022-06-13 09:11:43', '', 6, 'https://localhost/sponner/?p=34', 0, 'revision', '', 0),
(35, 1, '2022-06-13 09:19:42', '2022-06-13 09:19:42', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 09:19:42', '2022-06-13 09:19:42', '', 6, 'https://localhost/sponner/?p=35', 0, 'revision', '', 0),
(36, 1, '2022-06-13 09:19:53', '2022-06-13 09:19:53', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 09:19:53', '2022-06-13 09:19:53', '', 6, 'https://localhost/sponner/?p=36', 0, 'revision', '', 0),
(37, 1, '2022-06-13 09:20:05', '2022-06-13 09:20:05', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 09:20:05', '2022-06-13 09:20:05', '', 6, 'https://localhost/sponner/?p=37', 0, 'revision', '', 0),
(38, 1, '2022-06-13 09:32:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-06-13 09:32:18', '0000-00-00 00:00:00', '', 0, 'https://localhost/sponner/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2022-06-13 09:41:15', '2022-06-13 09:32:41', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2022-06-13 09:41:15', '2022-06-13 09:41:15', '', 0, 'https://localhost/sponner/?p=39', 2, 'nav_menu_item', '', 0),
(40, 1, '2022-06-13 09:41:15', '2022-06-13 09:32:41', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2022-06-13 09:41:15', '2022-06-13 09:41:15', '', 0, 'https://localhost/sponner/?p=40', 3, 'nav_menu_item', '', 0),
(41, 1, '2022-06-13 09:41:15', '2022-06-13 09:32:41', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2022-06-13 09:41:15', '2022-06-13 09:41:15', '', 0, 'https://localhost/sponner/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2022-06-13 09:40:23', '2022-06-13 09:40:23', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/sponner/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-06-13 09:40:23', '2022-06-13 09:40:23', '', 2, 'https://localhost/sponner/?p=42', 0, 'revision', '', 0),
(43, 1, '2022-06-13 09:40:28', '2022-06-13 09:40:28', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/sponner.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2022-06-13 09:40:28', '2022-06-13 09:40:28', '', 3, 'https://localhost/sponner/?p=43', 0, 'revision', '', 0),
(44, 1, '2022-06-13 09:40:42', '2022-06-13 09:40:42', '', 'Profil', '', 'publish', 'closed', 'closed', '', 'profil', '', '', '2022-06-13 10:56:10', '2022-06-13 10:56:10', '', 0, 'https://localhost/sponner/?page_id=44', 0, 'page', '', 0),
(45, 1, '2022-06-13 09:40:42', '2022-06-13 09:40:42', '', 'PROFIL', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2022-06-13 09:40:42', '2022-06-13 09:40:42', '', 44, 'https://localhost/sponner/?p=45', 0, 'revision', '', 0),
(46, 1, '2022-06-13 09:41:15', '2022-06-13 09:41:15', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2022-06-13 09:41:15', '2022-06-13 09:41:15', '', 0, 'https://localhost/sponner/?p=46', 4, 'nav_menu_item', '', 0),
(47, 1, '2022-06-13 09:43:15', '2022-06-13 09:43:15', '', 'STARTSEITE', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 09:43:15', '2022-06-13 09:43:15', '', 6, 'https://localhost/sponner/?p=47', 0, 'revision', '', 0),
(48, 1, '2022-06-13 09:55:33', '2022-06-13 09:55:33', '', 'Neubau EFH', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'publish', 'open', 'closed', '', 'neubau-efh', '', '', '2022-06-14 07:21:40', '2022-06-14 07:21:40', '', 0, 'https://localhost/sponner/?post_type=cpt_portfolio&#038;p=48', 0, 'cpt_portfolio', '', 0),
(49, 1, '2022-06-13 09:55:29', '2022-06-13 09:55:29', '', 'p1', '', 'inherit', 'open', 'closed', '', 'p1', '', '', '2022-06-13 09:55:29', '2022-06-13 09:55:29', '', 48, 'http://localhost/sponner/wp-content/uploads/2022/06/p1.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2022-06-13 09:55:33', '2022-06-13 09:55:33', '', 'Neubau EFH', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2022-06-13 09:55:33', '2022-06-13 09:55:33', '', 48, 'https://localhost/sponner/?p=50', 0, 'revision', '', 0),
(51, 1, '2022-06-13 09:56:05', '2022-06-13 09:56:05', '', 'Neubau FHE', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'publish', 'open', 'closed', '', 'neubau-fhe', '', '', '2022-06-14 07:23:03', '2022-06-14 07:23:03', '', 0, 'https://localhost/sponner/?post_type=cpt_portfolio&#038;p=51', 0, 'cpt_portfolio', '', 0),
(52, 1, '2022-06-13 09:56:00', '2022-06-13 09:56:00', '', 'p2', '', 'inherit', 'open', 'closed', '', 'p2', '', '', '2022-06-13 09:56:00', '2022-06-13 09:56:00', '', 51, 'http://localhost/sponner/wp-content/uploads/2022/06/p2.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2022-06-13 09:56:05', '2022-06-13 09:56:05', '', 'Neubau FHE', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2022-06-13 09:56:05', '2022-06-13 09:56:05', '', 51, 'https://localhost/sponner/?p=53', 0, 'revision', '', 0),
(54, 1, '2022-06-13 09:56:18', '2022-06-13 09:56:18', '', 'Neubau HEF', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'publish', 'open', 'closed', '', 'neubau-hef', '', '', '2022-06-14 07:24:13', '2022-06-14 07:24:13', '', 0, 'https://localhost/sponner/?post_type=cpt_portfolio&#038;p=54', 0, 'cpt_portfolio', '', 0),
(55, 1, '2022-06-13 09:56:18', '2022-06-13 09:56:18', '', 'Neubau HEF', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2022-06-13 09:56:18', '2022-06-13 09:56:18', '', 54, 'https://localhost/sponner/?p=55', 0, 'revision', '', 0),
(56, 1, '2022-06-13 09:56:27', '2022-06-13 09:56:27', '', 'p3', '', 'inherit', 'open', 'closed', '', 'p3', '', '', '2022-06-13 09:56:27', '2022-06-13 09:56:27', '', 54, 'http://localhost/sponner/wp-content/uploads/2022/06/p3.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2022-06-13 09:59:23', '2022-06-13 09:59:23', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Portfolio Section', 'portfolio_section', 'publish', 'closed', 'closed', '', 'field_62a70a01357b3', '', '', '2022-06-13 10:01:14', '2022-06-13 10:01:14', '', 29, 'https://localhost/sponner/?post_type=acf-field&#038;p=57', 2, 'acf-field', '', 0),
(58, 1, '2022-06-13 09:59:23', '2022-06-13 09:59:23', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Portfolio Title', 'portfolio_title', 'publish', 'closed', 'closed', '', 'field_62a70a3f357b5', '', '', '2022-06-13 10:01:14', '2022-06-13 10:01:14', '', 29, 'https://localhost/sponner/?post_type=acf-field&#038;p=58', 3, 'acf-field', '', 0),
(59, 1, '2022-06-13 09:59:23', '2022-06-13 09:59:23', 'a:12:{s:4:\"type\";s:12:\"relationship\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:13:\"cpt_portfolio\";}s:8:\"taxonomy\";s:0:\"\";s:7:\"filters\";a:3:{i:0;s:6:\"search\";i:1;s:9:\"post_type\";i:2;s:8:\"taxonomy\";}s:8:\"elements\";a:1:{i:0;s:14:\"featured_image\";}s:3:\"min\";i:3;s:3:\"max\";i:3;s:13:\"return_format\";s:2:\"id\";}', 'All Portfolios', 'all_portfolios', 'publish', 'closed', 'closed', '', 'field_62a70a49357b6', '', '', '2022-06-13 10:01:14', '2022-06-13 10:01:14', '', 29, 'https://localhost/sponner/?post_type=acf-field&#038;p=59', 4, 'acf-field', '', 0),
(60, 1, '2022-06-13 10:00:32', '2022-06-13 10:00:32', '', 'STARTSEITE', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 10:00:32', '2022-06-13 10:00:32', '', 6, 'https://localhost/sponner/?p=60', 0, 'revision', '', 0),
(61, 1, '2022-06-13 10:07:43', '2022-06-13 10:07:43', '', 'asfaf', '', 'trash', 'open', 'closed', '', 'asfaf__trashed', '', '', '2022-06-13 10:08:03', '2022-06-13 10:08:03', '', 0, 'https://localhost/sponner/?post_type=cpt_portfolio&#038;p=61', 0, 'cpt_portfolio', '', 0),
(62, 1, '2022-06-13 10:07:43', '2022-06-13 10:07:43', '', 'asfaf', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2022-06-13 10:07:43', '2022-06-13 10:07:43', '', 61, 'https://localhost/sponner/?p=62', 0, 'revision', '', 0),
(63, 1, '2022-06-13 10:09:11', '2022-06-13 10:09:11', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Portfolios Button Link', 'portfolios_button_link', 'publish', 'closed', 'closed', '', 'field_62a70cb7afa1f', '', '', '2022-06-13 10:09:11', '2022-06-13 10:09:11', '', 29, 'https://localhost/sponner/?post_type=acf-field&p=63', 5, 'acf-field', '', 0),
(64, 1, '2022-06-13 10:10:05', '2022-06-13 10:10:05', '', 'STARTSEITE', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 10:10:05', '2022-06-13 10:10:05', '', 6, 'https://localhost/sponner/?p=64', 0, 'revision', '', 0),
(65, 1, '2022-06-13 10:16:21', '2022-06-13 10:16:21', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Achivemnets Section', 'achivemnets_section', 'publish', 'closed', 'closed', '', 'field_62a70da54c98f', '', '', '2022-06-13 10:16:21', '2022-06-13 10:16:21', '', 29, 'https://localhost/sponner/?post_type=acf-field&p=65', 6, 'acf-field', '', 0),
(66, 1, '2022-06-13 10:16:21', '2022-06-13 10:16:21', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Achivemnets Title', 'achivemnets_title', 'publish', 'closed', 'closed', '', 'field_62a70dc04c990', '', '', '2022-06-13 10:17:56', '2022-06-13 10:17:56', '', 71, 'https://localhost/sponner/?post_type=acf-field&#038;p=66', 0, 'acf-field', '', 0),
(67, 1, '2022-06-13 10:16:21', '2022-06-13 10:16:21', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Achivemnets Box 1', 'achivemnets_box_1', 'publish', 'closed', 'closed', '', 'field_62a70ddc4c991', '', '', '2022-06-13 10:17:56', '2022-06-13 10:17:56', '', 71, 'https://localhost/sponner/?post_type=acf-field&#038;p=67', 1, 'acf-field', '', 0),
(68, 1, '2022-06-13 10:16:21', '2022-06-13 10:16:21', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'a_image_1', 'publish', 'closed', 'closed', '', 'field_62a70dec4c992', '', '', '2022-06-13 10:17:56', '2022-06-13 10:17:56', '', 71, 'https://localhost/sponner/?post_type=acf-field&#038;p=68', 2, 'acf-field', '', 0),
(69, 1, '2022-06-13 10:16:21', '2022-06-13 10:16:21', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'a_title_1', 'publish', 'closed', 'closed', '', 'field_62a70e4a4c993', '', '', '2022-06-13 10:17:56', '2022-06-13 10:17:56', '', 71, 'https://localhost/sponner/?post_type=acf-field&#038;p=69', 3, 'acf-field', '', 0),
(70, 1, '2022-06-13 10:16:21', '2022-06-13 10:16:21', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:4;s:9:\"new_lines\";s:0:\"\";}', 'Detail', 'a_detail_1', 'publish', 'closed', 'closed', '', 'field_62a70e5c4c994', '', '', '2022-06-13 10:17:56', '2022-06-13 10:17:56', '', 71, 'https://localhost/sponner/?post_type=acf-field&#038;p=70', 4, 'acf-field', '', 0),
(71, 1, '2022-06-13 10:17:55', '2022-06-13 10:17:55', 'a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}', 'Achivemnets Section', 'achivemnets_section', 'publish', 'closed', 'closed', '', 'field_62a70e9dbd56d', '', '', '2022-06-13 10:40:54', '2022-06-13 10:40:54', '', 29, 'https://localhost/sponner/?post_type=acf-field&#038;p=71', 7, 'acf-field', '', 0),
(72, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Achivemnets Box 2', 'achivemnets_box_2', 'publish', 'closed', 'closed', '', 'field_62a70ee1f8f40', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=72', 5, 'acf-field', '', 0),
(73, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'a_image_2', 'publish', 'closed', 'closed', '', 'field_62a70eecf8f41', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=73', 6, 'acf-field', '', 0),
(74, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'a_title_2', 'publish', 'closed', 'closed', '', 'field_62a70efff8f42', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=74', 7, 'acf-field', '', 0),
(75, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:4;s:9:\"new_lines\";s:0:\"\";}', 'Detail', 'a_detail_2', 'publish', 'closed', 'closed', '', 'field_62a70f11f8f43', '', '', '2022-06-13 10:24:52', '2022-06-13 10:24:52', '', 71, 'https://localhost/sponner/?post_type=acf-field&#038;p=75', 8, 'acf-field', '', 0),
(76, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Achivemnets Box 3', 'achivemnets_box_3', 'publish', 'closed', 'closed', '', 'field_62a70f23f8f44', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=76', 9, 'acf-field', '', 0),
(77, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'a_image_3', 'publish', 'closed', 'closed', '', 'field_62a70f53f8f45', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=77', 10, 'acf-field', '', 0),
(78, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'a_title_3', 'publish', 'closed', 'closed', '', 'field_62a70f69f8f46', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=78', 11, 'acf-field', '', 0),
(79, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:4;s:9:\"new_lines\";s:0:\"\";}', 'Detail', 'a_detail_3', 'publish', 'closed', 'closed', '', 'field_62a70f7ff8f47', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=79', 12, 'acf-field', '', 0),
(80, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Achivemnets Box 4', 'achivemnets_box_4', 'publish', 'closed', 'closed', '', 'field_62a70f9af8f48', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=80', 13, 'acf-field', '', 0),
(81, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'a_image_4', 'publish', 'closed', 'closed', '', 'field_62a70fcff8f49', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=81', 14, 'acf-field', '', 0),
(82, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'a_title_4', 'publish', 'closed', 'closed', '', 'field_62a70fe0f8f4a', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=82', 15, 'acf-field', '', 0),
(83, 1, '2022-06-13 10:23:00', '2022-06-13 10:23:00', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:4;s:9:\"new_lines\";s:0:\"\";}', 'Detail', 'a_detail_4', 'publish', 'closed', 'closed', '', 'field_62a70ff2f8f4b', '', '', '2022-06-13 10:23:00', '2022-06-13 10:23:00', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=83', 16, 'acf-field', '', 0),
(84, 1, '2022-06-13 10:24:20', '2022-06-13 10:24:20', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Achivemnets Box 5', 'achivemnets_box_5', 'publish', 'closed', 'closed', '', 'field_62a710152301e', '', '', '2022-06-13 10:24:20', '2022-06-13 10:24:20', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=84', 17, 'acf-field', '', 0),
(85, 1, '2022-06-13 10:24:20', '2022-06-13 10:24:20', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'a_image_5', 'publish', 'closed', 'closed', '', 'field_62a710232301f', '', '', '2022-06-13 10:24:20', '2022-06-13 10:24:20', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=85', 18, 'acf-field', '', 0),
(86, 1, '2022-06-13 10:24:20', '2022-06-13 10:24:20', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'a_title_5', 'publish', 'closed', 'closed', '', 'field_62a7103423020', '', '', '2022-06-13 10:24:34', '2022-06-13 10:24:34', '', 71, 'https://localhost/sponner/?post_type=acf-field&#038;p=86', 19, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(87, 1, '2022-06-13 10:24:20', '2022-06-13 10:24:20', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:4;s:9:\"new_lines\";s:0:\"\";}', 'Detail', 'a_detail_5', 'publish', 'closed', 'closed', '', 'field_62a7104023021', '', '', '2022-06-13 10:24:20', '2022-06-13 10:24:20', '', 71, 'https://localhost/sponner/?post_type=acf-field&p=87', 20, 'acf-field', '', 0),
(88, 1, '2022-06-13 10:25:54', '2022-06-13 10:25:54', '', 'a1', '', 'inherit', 'open', 'closed', '', 'a1', '', '', '2022-06-13 10:25:54', '2022-06-13 10:25:54', '', 6, 'http://localhost/sponner/wp-content/uploads/2022/06/a1.png', 0, 'attachment', 'image/png', 0),
(89, 1, '2022-06-13 10:26:47', '2022-06-13 10:26:47', '', 'a2', '', 'inherit', 'open', 'closed', '', 'a2', '', '', '2022-06-13 10:26:47', '2022-06-13 10:26:47', '', 6, 'http://localhost/sponner/wp-content/uploads/2022/06/a2.png', 0, 'attachment', 'image/png', 0),
(90, 1, '2022-06-13 10:27:30', '2022-06-13 10:27:30', '', 'a3', '', 'inherit', 'open', 'closed', '', 'a3', '', '', '2022-06-13 10:27:30', '2022-06-13 10:27:30', '', 6, 'http://localhost/sponner/wp-content/uploads/2022/06/a3.png', 0, 'attachment', 'image/png', 0),
(91, 1, '2022-06-13 10:28:18', '2022-06-13 10:28:18', '', 'STARTSEITE', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 10:28:18', '2022-06-13 10:28:18', '', 6, 'https://localhost/sponner/?p=91', 0, 'revision', '', 0),
(92, 1, '2022-06-13 10:29:48', '2022-06-13 10:29:48', '', 'a4', '', 'inherit', 'open', 'closed', '', 'a4', '', '', '2022-06-13 10:29:48', '2022-06-13 10:29:48', '', 6, 'http://localhost/sponner/wp-content/uploads/2022/06/a4.png', 0, 'attachment', 'image/png', 0),
(93, 1, '2022-06-13 10:29:59', '2022-06-13 10:29:59', '', 'a5', '', 'inherit', 'open', 'closed', '', 'a5', '', '', '2022-06-13 10:29:59', '2022-06-13 10:29:59', '', 6, 'http://localhost/sponner/wp-content/uploads/2022/06/a5.png', 0, 'attachment', 'image/png', 0),
(94, 1, '2022-06-13 10:30:32', '2022-06-13 10:30:32', '', 'STARTSEITE', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 10:30:32', '2022-06-13 10:30:32', '', 6, 'https://localhost/sponner/?p=94', 0, 'revision', '', 0),
(95, 1, '2022-06-13 10:40:54', '2022-06-13 10:40:54', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Call to Action Section', 'call_to_action_section', 'publish', 'closed', 'closed', '', 'field_62a713c8782f3', '', '', '2022-06-13 10:40:54', '2022-06-13 10:40:54', '', 29, 'https://localhost/sponner/?post_type=acf-field&p=95', 8, 'acf-field', '', 0),
(96, 1, '2022-06-13 10:40:54', '2022-06-13 10:40:54', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Heading', 'action_heading', 'publish', 'closed', 'closed', '', 'field_62a71405782f4', '', '', '2022-06-13 10:40:54', '2022-06-13 10:40:54', '', 29, 'https://localhost/sponner/?post_type=acf-field&p=96', 9, 'acf-field', '', 0),
(97, 1, '2022-06-13 10:40:54', '2022-06-13 10:40:54', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Sub Heading', 'action_sub_heading', 'publish', 'closed', 'closed', '', 'field_62a7141a782f5', '', '', '2022-06-13 10:40:54', '2022-06-13 10:40:54', '', 29, 'https://localhost/sponner/?post_type=acf-field&p=97', 10, 'acf-field', '', 0),
(98, 1, '2022-06-13 10:40:54', '2022-06-13 10:40:54', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Button Link', 'action_button_link', 'publish', 'closed', 'closed', '', 'field_62a71424782f6', '', '', '2022-06-13 10:40:54', '2022-06-13 10:40:54', '', 29, 'https://localhost/sponner/?post_type=acf-field&p=98', 11, 'acf-field', '', 0),
(99, 1, '2022-06-13 10:41:44', '2022-06-13 10:41:44', '', 'STARTSEITE', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 10:41:44', '2022-06-13 10:41:44', '', 6, 'https://localhost/sponner/?p=99', 0, 'revision', '', 0),
(100, 1, '2022-06-13 10:43:21', '2022-06-13 10:43:21', '', 'Leistungen', '', 'publish', 'closed', 'closed', '', 'leistungen', '', '', '2022-06-13 10:43:21', '2022-06-13 10:43:21', '', 0, 'https://localhost/sponner/?page_id=100', 0, 'page', '', 0),
(101, 1, '2022-06-13 10:43:21', '2022-06-13 10:43:21', '', 'Leistungen', '', 'inherit', 'closed', 'closed', '', '100-revision-v1', '', '', '2022-06-13 10:43:21', '2022-06-13 10:43:21', '', 100, 'https://localhost/sponner/?p=101', 0, 'revision', '', 0),
(102, 1, '2022-06-13 10:43:38', '2022-06-13 10:43:38', '', 'Impressum', '', 'publish', 'closed', 'closed', '', 'impressum', '', '', '2022-06-13 10:55:37', '2022-06-13 10:55:37', '', 0, 'https://localhost/sponner/?page_id=102', 0, 'page', '', 0),
(103, 1, '2022-06-13 10:43:38', '2022-06-13 10:43:38', '', 'Impressum', '', 'inherit', 'closed', 'closed', '', '102-revision-v1', '', '', '2022-06-13 10:43:38', '2022-06-13 10:43:38', '', 102, 'https://localhost/sponner/?p=103', 0, 'revision', '', 0),
(105, 1, '2022-06-13 10:43:45', '2022-06-13 10:43:45', '', 'Datenschutz', '', 'publish', 'closed', 'closed', '', 'datenschutz', '', '', '2022-06-13 10:43:45', '2022-06-13 10:43:45', '', 0, 'https://localhost/sponner/?page_id=105', 0, 'page', '', 0),
(106, 1, '2022-06-13 10:43:45', '2022-06-13 10:43:45', '', 'Datenschutz', '', 'inherit', 'closed', 'closed', '', '105-revision-v1', '', '', '2022-06-13 10:43:45', '2022-06-13 10:43:45', '', 105, 'https://localhost/sponner/?p=106', 0, 'revision', '', 0),
(107, 1, '2022-06-13 10:48:11', '2022-06-13 10:48:11', ' ', '', '', 'publish', 'closed', 'closed', '', '107', '', '', '2022-06-13 10:48:11', '2022-06-13 10:48:11', '', 0, 'https://localhost/sponner/?p=107', 1, 'nav_menu_item', '', 0),
(108, 1, '2022-06-13 10:48:11', '2022-06-13 10:48:11', ' ', '', '', 'publish', 'closed', 'closed', '', '108', '', '', '2022-06-13 10:48:11', '2022-06-13 10:48:11', '', 0, 'https://localhost/sponner/?p=108', 7, 'nav_menu_item', '', 0),
(109, 1, '2022-06-13 10:48:11', '2022-06-13 10:48:11', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2022-06-13 10:48:11', '2022-06-13 10:48:11', '', 0, 'https://localhost/sponner/?p=109', 6, 'nav_menu_item', '', 0),
(110, 1, '2022-06-13 10:48:11', '2022-06-13 10:48:11', ' ', '', '', 'publish', 'closed', 'closed', '', '110', '', '', '2022-06-13 10:48:11', '2022-06-13 10:48:11', '', 0, 'https://localhost/sponner/?p=110', 5, 'nav_menu_item', '', 0),
(111, 1, '2022-06-13 10:48:11', '2022-06-13 10:48:11', ' ', '', '', 'publish', 'closed', 'closed', '', '111', '', '', '2022-06-13 10:48:11', '2022-06-13 10:48:11', '', 0, 'https://localhost/sponner/?p=111', 3, 'nav_menu_item', '', 0),
(112, 1, '2022-06-13 10:48:11', '2022-06-13 10:48:11', ' ', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2022-06-13 10:48:11', '2022-06-13 10:48:11', '', 0, 'https://localhost/sponner/?p=112', 4, 'nav_menu_item', '', 0),
(113, 1, '2022-06-13 10:48:11', '2022-06-13 10:48:11', ' ', '', '', 'publish', 'closed', 'closed', '', '113', '', '', '2022-06-13 10:48:11', '2022-06-13 10:48:11', '', 0, 'https://localhost/sponner/?p=113', 2, 'nav_menu_item', '', 0),
(114, 1, '2022-06-13 10:55:52', '2022-06-13 10:55:52', '', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2022-06-13 10:55:52', '2022-06-13 10:55:52', '', 8, 'https://localhost/sponner/?p=114', 0, 'revision', '', 0),
(115, 1, '2022-06-13 10:56:10', '2022-06-13 10:56:10', '', 'Profil', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2022-06-13 10:56:10', '2022-06-13 10:56:10', '', 44, 'https://localhost/sponner/?p=115', 0, 'revision', '', 0),
(116, 1, '2022-06-13 10:56:22', '2022-06-13 10:56:22', '', 'Projekte', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-06-13 10:56:22', '2022-06-13 10:56:22', '', 10, 'https://localhost/sponner/?p=116', 0, 'revision', '', 0),
(117, 1, '2022-06-13 10:56:47', '2022-06-13 10:56:47', '', 'Startseite', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-06-13 10:56:47', '2022-06-13 10:56:47', '', 6, 'https://localhost/sponner/?p=117', 0, 'revision', '', 0),
(118, 1, '2022-06-13 12:13:48', '2022-06-13 12:13:48', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:25:\"templates/tmp-Kontakt.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Kontakt', 'kontakt', 'publish', 'closed', 'closed', '', 'group_62a729dd487ca', '', '', '2022-06-13 12:15:25', '2022-06-13 12:15:25', '', 0, 'https://localhost/sponner/?post_type=acf-field-group&#038;p=118', 0, 'acf-field-group', '', 0),
(119, 1, '2022-06-13 12:15:25', '2022-06-13 12:15:25', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:2;s:9:\"new_lines\";s:0:\"\";}', 'Contact Details', 'contact_details', 'publish', 'closed', 'closed', '', 'field_62a72a0003a6f', '', '', '2022-06-13 12:15:25', '2022-06-13 12:15:25', '', 118, 'https://localhost/sponner/?post_type=acf-field&p=119', 0, 'acf-field', '', 0),
(120, 1, '2022-06-13 12:15:25', '2022-06-13 12:15:25', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:4;s:9:\"new_lines\";s:0:\"\";}', 'Contact Map', 'contact_map', 'publish', 'closed', 'closed', '', 'field_62a72a3b03a71', '', '', '2022-06-13 12:15:25', '2022-06-13 12:15:25', '', 118, 'https://localhost/sponner/?post_type=acf-field&p=120', 1, 'acf-field', '', 0),
(121, 1, '2022-06-13 12:16:11', '2022-06-13 12:16:11', '', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2022-06-13 12:16:11', '2022-06-13 12:16:11', '', 8, 'https://localhost/sponner/?p=121', 0, 'revision', '', 0),
(123, 1, '2022-06-13 12:29:31', '2022-06-13 12:29:31', '', 'Über mich', '', 'publish', 'closed', 'closed', '', 'uber-mich', '', '', '2022-06-14 09:03:57', '2022-06-14 09:03:57', '', 0, 'https://localhost/sponner/?page_id=123', 0, 'page', '', 0),
(124, 1, '2022-06-13 12:29:31', '2022-06-13 12:29:31', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-13 12:29:31', '2022-06-13 12:29:31', '', 123, 'https://localhost/sponner/?p=124', 0, 'revision', '', 0),
(125, 1, '2022-06-13 12:33:13', '2022-06-13 12:33:13', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:27:\"templates/tmp-uber_mich.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Über mich', 'uber-mich', 'publish', 'closed', 'closed', '', 'group_62a72db713311', '', '', '2022-06-14 09:07:05', '2022-06-14 09:07:05', '', 0, 'https://localhost/sponner/?post_type=acf-field-group&#038;p=125', 0, 'acf-field-group', '', 0),
(126, 1, '2022-06-13 12:33:13', '2022-06-13 12:33:13', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Philosophie Section', 'philosophie_section', 'publish', 'closed', 'closed', '', 'field_62a72db942eb8', '', '', '2022-06-13 12:33:13', '2022-06-13 12:33:13', '', 125, 'https://localhost/sponner/?post_type=acf-field&p=126', 0, 'acf-field', '', 0),
(127, 1, '2022-06-13 12:33:13', '2022-06-13 12:33:13', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Meine Philosophie Title', 'meine_philosophie_title', 'publish', 'closed', 'closed', '', 'field_62a72e5c42eb9', '', '', '2022-06-13 12:33:13', '2022-06-13 12:33:13', '', 125, 'https://localhost/sponner/?post_type=acf-field&p=127', 1, 'acf-field', '', 0),
(128, 1, '2022-06-13 12:33:13', '2022-06-13 12:33:13', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Meine Philosophie Details', 'meine_philosophie_details', 'publish', 'closed', 'closed', '', 'field_62a72e7142eba', '', '', '2022-06-14 05:28:04', '2022-06-14 05:28:04', '', 125, 'https://localhost/sponner/?post_type=acf-field&#038;p=128', 2, 'acf-field', '', 0),
(129, 1, '2022-06-13 12:40:11', '2022-06-13 12:40:11', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-13 12:40:11', '2022-06-13 12:40:11', '', 123, 'https://localhost/sponner/?p=129', 0, 'revision', '', 0),
(130, 1, '2022-06-13 12:40:23', '2022-06-13 12:40:23', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-13 12:40:23', '2022-06-13 12:40:23', '', 123, 'https://localhost/sponner/?p=130', 0, 'revision', '', 0),
(131, 1, '2022-06-13 12:40:48', '2022-06-13 12:40:48', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-13 12:40:48', '2022-06-13 12:40:48', '', 123, 'https://localhost/sponner/?p=131', 0, 'revision', '', 0),
(132, 1, '2022-06-13 12:51:29', '2022-06-13 12:51:29', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Call to Action Section', 'call_to_action_section', 'publish', 'closed', 'closed', '', 'field_62a73283cc3f4', '', '', '2022-06-14 09:07:05', '2022-06-14 09:07:05', '', 125, 'https://localhost/sponner/?post_type=acf-field&#038;p=132', 5, 'acf-field', '', 0),
(133, 1, '2022-06-13 12:51:30', '2022-06-13 12:51:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Heading', 'action_heading', 'publish', 'closed', 'closed', '', 'field_62a732bacc3f5', '', '', '2022-06-14 09:07:05', '2022-06-14 09:07:05', '', 125, 'https://localhost/sponner/?post_type=acf-field&#038;p=133', 6, 'acf-field', '', 0),
(134, 1, '2022-06-13 12:51:30', '2022-06-13 12:51:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Sub Heading', 'action_sub_heading', 'publish', 'closed', 'closed', '', 'field_62a732c6cc3f6', '', '', '2022-06-14 09:07:05', '2022-06-14 09:07:05', '', 125, 'https://localhost/sponner/?post_type=acf-field&#038;p=134', 7, 'acf-field', '', 0),
(135, 1, '2022-06-13 12:51:30', '2022-06-13 12:51:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Button Link', 'action_button_link', 'publish', 'closed', 'closed', '', 'field_62a732cecc3f7', '', '', '2022-06-14 09:07:05', '2022-06-14 09:07:05', '', 125, 'https://localhost/sponner/?post_type=acf-field&#038;p=135', 8, 'acf-field', '', 0),
(136, 1, '2022-06-13 12:52:34', '2022-06-13 12:52:34', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-13 12:52:34', '2022-06-13 12:52:34', '', 123, 'https://localhost/sponner/?p=136', 0, 'revision', '', 0),
(138, 1, '2022-06-13 13:02:34', '2022-06-13 13:02:34', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Name', 'name', 'publish', 'closed', 'closed', '', 'field_62a734add4d3d', '', '', '2022-06-14 09:07:05', '2022-06-14 09:07:05', '', 125, 'https://localhost/sponner/?post_type=acf-field&#038;p=138', 3, 'acf-field', '', 0),
(149, 1, '2022-06-14 04:55:55', '2022-06-14 04:55:55', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'My Image', 'my_image', 'publish', 'closed', 'closed', '', 'field_62a814b957086', '', '', '2022-06-14 09:07:05', '2022-06-14 09:07:05', '', 125, 'http://localhost/sponner/?post_type=acf-field&#038;p=149', 4, 'acf-field', '', 0),
(150, 1, '2022-06-14 04:56:42', '2022-06-14 04:56:42', '', 'about_me', '', 'inherit', 'open', 'closed', '', 'about_me', '', '', '2022-06-14 04:56:42', '2022-06-14 04:56:42', '', 123, 'http://localhost/sponner/wp-content/uploads/2022/06/about_me.jpg', 0, 'attachment', 'image/jpeg', 0),
(151, 1, '2022-06-14 05:00:46', '2022-06-14 05:00:46', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-14 05:00:46', '2022-06-14 05:00:46', '', 123, 'http://localhost/sponner/?p=151', 0, 'revision', '', 0),
(153, 1, '2022-06-14 05:24:09', '2022-06-14 05:24:09', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-14 05:24:09', '2022-06-14 05:24:09', '', 123, 'http://localhost/sponner/?p=153', 0, 'revision', '', 0),
(154, 1, '2022-06-14 05:26:02', '2022-06-14 05:26:02', '', 'Über mich', '', 'inherit', 'closed', 'closed', '', '123-revision-v1', '', '', '2022-06-14 05:26:02', '2022-06-14 05:26:02', '', 123, 'http://localhost/sponner/?p=154', 0, 'revision', '', 0),
(156, 1, '2022-06-14 05:59:56', '2022-06-14 05:59:56', 'EFH Wörthsee', '2000', '', 'publish', 'open', 'closed', '', '2000', '', '', '2022-06-14 05:59:56', '2022-06-14 05:59:56', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=156', 0, 'cpt_timeline', '', 0),
(157, 1, '2022-06-14 05:59:56', '2022-06-14 05:59:56', 'EFH Wörthsee', '2000', '', 'inherit', 'closed', 'closed', '', '156-revision-v1', '', '', '2022-06-14 05:59:56', '2022-06-14 05:59:56', '', 156, 'http://localhost/sponner/?p=157', 0, 'revision', '', 0),
(158, 1, '2022-06-14 06:00:16', '2022-06-14 06:00:16', 'Sanierung/Umbau denkmalgeschütztes Haus Inning a. A.\r\nUmbau Wirtschaftsgebäude in Wohnhaus Zankenhausen', '2001', '', 'publish', 'open', 'closed', '', '2001', '', '', '2022-06-14 06:00:16', '2022-06-14 06:00:16', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=158', 0, 'cpt_timeline', '', 0),
(159, 1, '2022-06-14 06:00:16', '2022-06-14 06:00:16', 'Sanierung/Umbau denkmalgeschütztes Haus Inning a. A.\r\nUmbau Wirtschaftsgebäude in Wohnhaus Zankenhausen', '2001', '', 'inherit', 'closed', 'closed', '', '158-revision-v1', '', '', '2022-06-14 06:00:16', '2022-06-14 06:00:16', '', 158, 'http://localhost/sponner/?p=159', 0, 'revision', '', 0),
(160, 1, '2022-06-14 06:00:43', '2022-06-14 06:00:43', 'Umbau EFH in 2-Familienhaus Herrsching', '2002', '', 'publish', 'open', 'closed', '', '2002', '', '', '2022-06-14 06:00:43', '2022-06-14 06:00:43', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=160', 0, 'cpt_timeline', '', 0),
(161, 1, '2022-06-14 06:00:43', '2022-06-14 06:00:43', 'Umbau EFH in 2-Familienhaus Herrsching', '2002', '', 'inherit', 'closed', 'closed', '', '160-revision-v1', '', '', '2022-06-14 06:00:43', '2022-06-14 06:00:43', '', 160, 'http://localhost/sponner/?p=161', 0, 'revision', '', 0),
(162, 1, '2022-06-14 06:01:01', '2022-06-14 06:01:01', 'Umbau EFH Wörthsee', '2003', '', 'publish', 'open', 'closed', '', '2003', '', '', '2022-06-14 06:01:01', '2022-06-14 06:01:01', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=162', 0, 'cpt_timeline', '', 0),
(163, 1, '2022-06-14 06:01:01', '2022-06-14 06:01:01', 'Umbau EFH Wörthsee', '2003', '', 'inherit', 'closed', 'closed', '', '162-revision-v1', '', '', '2022-06-14 06:01:01', '2022-06-14 06:01:01', '', 162, 'http://localhost/sponner/?p=163', 0, 'revision', '', 0),
(164, 1, '2022-06-14 06:01:03', '2022-06-14 06:01:03', 'Umbau EFH Wörthsee', '2003', '', 'inherit', 'closed', 'closed', '', '162-autosave-v1', '', '', '2022-06-14 06:01:03', '2022-06-14 06:01:03', '', 162, 'http://localhost/sponner/?p=164', 0, 'revision', '', 0),
(165, 1, '2022-06-14 06:01:26', '2022-06-14 06:01:26', 'Umbau u. Sanierung EFH Bachern', '2004', '', 'publish', 'open', 'closed', '', '2004', '', '', '2022-06-14 06:01:26', '2022-06-14 06:01:26', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=165', 0, 'cpt_timeline', '', 0),
(166, 1, '2022-06-14 06:01:26', '2022-06-14 06:01:26', 'Umbau u. Sanierung EFH Bachern', '2004', '', 'inherit', 'closed', 'closed', '', '165-revision-v1', '', '', '2022-06-14 06:01:26', '2022-06-14 06:01:26', '', 165, 'http://localhost/sponner/?p=166', 0, 'revision', '', 0),
(167, 1, '2022-06-14 06:01:43', '2022-06-14 06:01:43', 'EFH Markt Wald', '2005', '', 'publish', 'open', 'closed', '', '2005', '', '', '2022-06-14 06:01:43', '2022-06-14 06:01:43', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=167', 0, 'cpt_timeline', '', 0),
(168, 1, '2022-06-14 06:01:43', '2022-06-14 06:01:43', 'EFH Markt Wald', '2005', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2022-06-14 06:01:43', '2022-06-14 06:01:43', '', 167, 'http://localhost/sponner/?p=168', 0, 'revision', '', 0),
(169, 1, '2022-06-14 06:02:03', '2022-06-14 06:02:03', 'Anbau a. DHH Weßling', '2006', '', 'publish', 'open', 'closed', '', '2006', '', '', '2022-06-14 06:02:03', '2022-06-14 06:02:03', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=169', 0, 'cpt_timeline', '', 0),
(170, 1, '2022-06-14 06:02:03', '2022-06-14 06:02:03', 'Anbau a. DHH Weßling', '2006', '', 'inherit', 'closed', 'closed', '', '169-revision-v1', '', '', '2022-06-14 06:02:03', '2022-06-14 06:02:03', '', 169, 'http://localhost/sponner/?p=170', 0, 'revision', '', 0),
(171, 1, '2022-06-14 06:02:25', '2022-06-14 06:02:25', 'EFH Wörthsee', '2007', '', 'publish', 'open', 'closed', '', '2007', '', '', '2022-06-14 06:02:25', '2022-06-14 06:02:25', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=171', 0, 'cpt_timeline', '', 0),
(172, 1, '2022-06-14 06:02:25', '2022-06-14 06:02:25', 'EFH Wörthsee', '2007', '', 'inherit', 'closed', 'closed', '', '171-revision-v1', '', '', '2022-06-14 06:02:25', '2022-06-14 06:02:25', '', 171, 'http://localhost/sponner/?p=172', 0, 'revision', '', 0),
(173, 1, '2022-06-14 06:02:54', '2022-06-14 06:02:54', 'Umbau/Anbau 2-Familienhaus Weßling<br /> EFH Breitbrunn<br />EFH m. Einliegerwohnung Allach', '2008', '', 'publish', 'open', 'closed', '', '2008', '', '', '2022-06-14 06:03:14', '2022-06-14 06:03:14', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=173', 0, 'cpt_timeline', '', 0),
(174, 1, '2022-06-14 06:02:54', '2022-06-14 06:02:54', 'Umbau/Anbau 2-Familienhaus Weßling<br /> EFH Breitbrunn<br />?EFH m. Einliegerwohnung Allach', '2008', '', 'inherit', 'closed', 'closed', '', '173-revision-v1', '', '', '2022-06-14 06:02:54', '2022-06-14 06:02:54', '', 173, 'http://localhost/sponner/?p=174', 0, 'revision', '', 0),
(175, 1, '2022-06-14 06:03:14', '2022-06-14 06:03:14', 'Umbau/Anbau 2-Familienhaus Weßling<br /> EFH Breitbrunn<br />EFH m. Einliegerwohnung Allach', '2008', '', 'inherit', 'closed', 'closed', '', '173-revision-v1', '', '', '2022-06-14 06:03:14', '2022-06-14 06:03:14', '', 173, 'http://localhost/sponner/?p=175', 0, 'revision', '', 0),
(176, 1, '2022-06-14 06:03:46', '2022-06-14 06:03:46', 'Umbau/Anbau u. Sanierung EFH Wörthsee', '2009', '', 'publish', 'open', 'closed', '', '2009', '', '', '2022-06-14 06:03:46', '2022-06-14 06:03:46', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=176', 0, 'cpt_timeline', '', 0),
(177, 1, '2022-06-14 06:03:46', '2022-06-14 06:03:46', 'Umbau/Anbau u. Sanierung EFH Wörthsee', '2009', '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', '2022-06-14 06:03:46', '2022-06-14 06:03:46', '', 176, 'http://localhost/sponner/?p=177', 0, 'revision', '', 0),
(178, 1, '2022-06-14 06:04:10', '2022-06-14 06:04:10', 'MFH u. Anbau an 2-Familienhaus Grafrath\r\nEFH Hechendorf', '2010', '', 'publish', 'open', 'closed', '', '2010', '', '', '2022-06-14 06:04:10', '2022-06-14 06:04:10', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=178', 0, 'cpt_timeline', '', 0),
(179, 1, '2022-06-14 06:04:10', '2022-06-14 06:04:10', 'MFH u. Anbau an 2-Familienhaus Grafrath\r\nEFH Hechendorf', '2010', '', 'inherit', 'closed', 'closed', '', '178-revision-v1', '', '', '2022-06-14 06:04:10', '2022-06-14 06:04:10', '', 178, 'http://localhost/sponner/?p=179', 0, 'revision', '', 0),
(180, 1, '2022-06-14 06:04:28', '2022-06-14 06:04:28', 'Neubau DG u. Sanierung EFH Puchheim', '2011', '', 'publish', 'open', 'closed', '', '2011', '', '', '2022-06-14 06:04:28', '2022-06-14 06:04:28', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=180', 0, 'cpt_timeline', '', 0),
(181, 1, '2022-06-14 06:04:28', '2022-06-14 06:04:28', 'Neubau DG u. Sanierung EFH Puchheim', '2011', '', 'inherit', 'closed', 'closed', '', '180-revision-v1', '', '', '2022-06-14 06:04:28', '2022-06-14 06:04:28', '', 180, 'http://localhost/sponner/?p=181', 0, 'revision', '', 0),
(182, 1, '2022-06-14 06:05:01', '2022-06-14 06:05:01', 'Entwurf Ausbau Tenne\r\nAnbau EFH Breitbrunn', '2012', '', 'publish', 'open', 'closed', '', '2012', '', '', '2022-06-14 06:05:01', '2022-06-14 06:05:01', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=182', 0, 'cpt_timeline', '', 0),
(183, 1, '2022-06-14 06:05:01', '2022-06-14 06:05:01', 'Entwurf Ausbau Tenne\r\nAnbau EFH Breitbrunn', '2012', '', 'inherit', 'closed', 'closed', '', '182-revision-v1', '', '', '2022-06-14 06:05:01', '2022-06-14 06:05:01', '', 182, 'http://localhost/sponner/?p=183', 0, 'revision', '', 0),
(184, 1, '2022-06-14 06:05:32', '2022-06-14 06:05:32', 'MFH Wörthsee\r\nEFH Gräfelfing', '2013', '', 'publish', 'open', 'closed', '', '2013', '', '', '2022-06-14 06:05:32', '2022-06-14 06:05:32', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=184', 0, 'cpt_timeline', '', 0),
(185, 1, '2022-06-14 06:05:32', '2022-06-14 06:05:32', 'MFH Wörthsee\r\nEFH Gräfelfing', '2013', '', 'inherit', 'closed', 'closed', '', '184-revision-v1', '', '', '2022-06-14 06:05:32', '2022-06-14 06:05:32', '', 184, 'http://localhost/sponner/?p=185', 0, 'revision', '', 0),
(186, 1, '2022-06-14 06:06:14', '2022-06-14 06:06:14', 'Neugestaltung Praxisräume Gilching\r\nAnbau/Umbau/Sanierung EFH Lochhausen\r\nEnergetische Sanierung EFH Steinbach', '2014', '', 'publish', 'open', 'closed', '', '2014', '', '', '2022-06-14 06:06:14', '2022-06-14 06:06:14', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=186', 0, 'cpt_timeline', '', 0),
(187, 1, '2022-06-14 06:06:14', '2022-06-14 06:06:14', 'Neugestaltung Praxisräume Gilching\r\nAnbau/Umbau/Sanierung EFH Lochhausen\r\nEnergetische Sanierung EFH Steinbach', '2014', '', 'inherit', 'closed', 'closed', '', '186-revision-v1', '', '', '2022-06-14 06:06:14', '2022-06-14 06:06:14', '', 186, 'http://localhost/sponner/?p=187', 0, 'revision', '', 0),
(188, 1, '2022-06-14 06:06:33', '2022-06-14 06:06:33', 'Zweifamilienhaus Geisenbrunn\r\nAusbau DG Herrsching\r\nAusbau DG u. Sanierung EFH Unterpfaffenhofen', '2015', '', 'publish', 'open', 'closed', '', '2015', '', '', '2022-06-14 06:06:53', '2022-06-14 06:06:53', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=188', 0, 'cpt_timeline', '', 0),
(189, 1, '2022-06-14 06:06:33', '2022-06-14 06:06:33', 'Zweifamilienhaus Geisenbrunn', '2015', '', 'inherit', 'closed', 'closed', '', '188-revision-v1', '', '', '2022-06-14 06:06:33', '2022-06-14 06:06:33', '', 188, 'http://localhost/sponner/?p=189', 0, 'revision', '', 0),
(190, 1, '2022-06-14 06:06:53', '2022-06-14 06:06:53', 'Zweifamilienhaus Geisenbrunn\r\nAusbau DG Herrsching\r\nAusbau DG u. Sanierung EFH Unterpfaffenhofen', '2015', '', 'inherit', 'closed', 'closed', '', '188-revision-v1', '', '', '2022-06-14 06:06:53', '2022-06-14 06:06:53', '', 188, 'http://localhost/sponner/?p=190', 0, 'revision', '', 0),
(191, 1, '2022-06-14 06:07:17', '2022-06-14 06:07:17', 'Umbau u. Sanierung EFH Weßling', '2016', '', 'publish', 'open', 'closed', '', '2016', '', '', '2022-06-14 06:07:17', '2022-06-14 06:07:17', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=191', 0, 'cpt_timeline', '', 0),
(192, 1, '2022-06-14 06:07:17', '2022-06-14 06:07:17', 'Umbau u. Sanierung EFH Weßling', '2016', '', 'inherit', 'closed', 'closed', '', '191-revision-v1', '', '', '2022-06-14 06:07:17', '2022-06-14 06:07:17', '', 191, 'http://localhost/sponner/?p=192', 0, 'revision', '', 0),
(193, 1, '2022-06-14 06:07:44', '2022-06-14 06:07:44', 'Energetische Sanierung EFH Steinebach<br />\r\nAnbau/Umbau e. EFH zum Zweifamilienhaus Oberpfaffenhofen<br />\r\nAnbau an MFH Steinebach', '2017', '', 'publish', 'open', 'closed', '', '2017', '', '', '2022-06-14 06:07:44', '2022-06-14 06:07:44', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=193', 0, 'cpt_timeline', '', 0),
(194, 1, '2022-06-14 06:07:44', '2022-06-14 06:07:44', 'Energetische Sanierung EFH Steinebach<br />\r\nAnbau/Umbau e. EFH zum Zweifamilienhaus Oberpfaffenhofen<br />\r\nAnbau an MFH Steinebach', '2017', '', 'inherit', 'closed', 'closed', '', '193-revision-v1', '', '', '2022-06-14 06:07:44', '2022-06-14 06:07:44', '', 193, 'http://localhost/sponner/?p=194', 0, 'revision', '', 0),
(195, 1, '2022-06-14 06:08:41', '2022-06-14 06:08:41', 'Anbau a. EFH zum Doppelhaus Wörthsee<br />\r\nAußenanlagen EFH Breitbrunn', '2018', '', 'publish', 'open', 'closed', '', '2018', '', '', '2022-06-14 06:08:41', '2022-06-14 06:08:41', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=195', 0, 'cpt_timeline', '', 0),
(196, 1, '2022-06-14 06:08:41', '2022-06-14 06:08:41', 'Anbau a. EFH zum Doppelhaus Wörthsee<br />\r\nAußenanlagen EFH Breitbrunn', '2018', '', 'inherit', 'closed', 'closed', '', '195-revision-v1', '', '', '2022-06-14 06:08:41', '2022-06-14 06:08:41', '', 195, 'http://localhost/sponner/?p=196', 0, 'revision', '', 0),
(197, 1, '2022-06-14 06:09:09', '2022-06-14 06:09:09', 'Anbau an DHH Weßling<br />\r\nAusbau Dachgeschoss Hanfeld', '2019', '', 'publish', 'open', 'closed', '', '2019', '', '', '2022-06-14 06:09:09', '2022-06-14 06:09:09', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=197', 0, 'cpt_timeline', '', 0),
(198, 1, '2022-06-14 06:09:09', '2022-06-14 06:09:09', 'Anbau an DHH Weßling<br />\r\nAusbau Dachgeschoss Hanfeld', '2019', '', 'inherit', 'closed', 'closed', '', '197-revision-v1', '', '', '2022-06-14 06:09:09', '2022-06-14 06:09:09', '', 197, 'http://localhost/sponner/?p=198', 0, 'revision', '', 0),
(199, 1, '2022-06-14 06:09:36', '2022-06-14 06:09:36', 'Anbau an EFH Wörthsee<br />\r\nSanierung EFH Wörthsee<br />\r\nUmbau Wohn- und Wirtschaftsgebäude München/Aubing zu MFH', '2020', '', 'publish', 'open', 'closed', '', '2020', '', '', '2022-06-14 06:09:36', '2022-06-14 06:09:36', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=199', 0, 'cpt_timeline', '', 0),
(200, 1, '2022-06-14 06:09:36', '2022-06-14 06:09:36', 'Anbau an EFH Wörthsee<br />\r\nSanierung EFH Wörthsee<br />\r\nUmbau Wohn- und Wirtschaftsgebäude München/Aubing zu MFH', '2020', '', 'inherit', 'closed', 'closed', '', '199-revision-v1', '', '', '2022-06-14 06:09:36', '2022-06-14 06:09:36', '', 199, 'http://localhost/sponner/?p=200', 0, 'revision', '', 0),
(201, 1, '2022-06-14 06:10:01', '2022-06-14 06:10:01', 'Umbau Wohn- und Wirtschaftsgebäude München/Aubing zu MFH', '2021', '', 'publish', 'open', 'closed', '', '2021', '', '', '2022-06-14 06:10:01', '2022-06-14 06:10:01', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=201', 0, 'cpt_timeline', '', 0),
(202, 1, '2022-06-14 06:10:01', '2022-06-14 06:10:01', 'Umbau Wohn- und Wirtschaftsgebäude München/Aubing zu MFH', '2021', '', 'inherit', 'closed', 'closed', '', '201-revision-v1', '', '', '2022-06-14 06:10:01', '2022-06-14 06:10:01', '', 201, 'http://localhost/sponner/?p=202', 0, 'revision', '', 0),
(203, 1, '2022-06-14 06:10:22', '2022-06-14 06:10:22', 'EFH Wörthsee\r\nAnbau/Umbau DHH Unterpfaffenhofen', '2022', '', 'publish', 'open', 'closed', '', '2022', '', '', '2022-06-14 06:10:22', '2022-06-14 06:10:22', '', 0, 'http://localhost/sponner/?post_type=cpt_timeline&#038;p=203', 0, 'cpt_timeline', '', 0),
(204, 1, '2022-06-14 06:10:22', '2022-06-14 06:10:22', 'EFH Wörthsee\r\nAnbau/Umbau DHH Unterpfaffenhofen', '2022', '', 'inherit', 'closed', 'closed', '', '203-revision-v1', '', '', '2022-06-14 06:10:22', '2022-06-14 06:10:22', '', 203, 'http://localhost/sponner/?p=204', 0, 'revision', '', 0),
(205, 1, '2022-06-14 06:17:18', '2022-06-14 06:17:18', '', 'Timeline', '', 'publish', 'closed', 'closed', '', 'timeline', '', '', '2022-06-14 06:21:41', '2022-06-14 06:21:41', '', 0, 'http://localhost/sponner/?post_type=cfs&#038;p=205', 0, 'cfs', '', 0),
(206, 1, '2022-06-14 06:43:26', '2022-06-14 06:43:26', '', 'Umbau Bearbeitet', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'publish', 'open', 'closed', '', 'umbau-bearbeitet', '', '', '2022-06-14 07:20:19', '2022-06-14 07:20:19', '', 0, 'http://localhost/sponner/?post_type=cpt_portfolio&#038;p=206', 0, 'cpt_portfolio', '', 0),
(207, 1, '2022-06-14 06:43:17', '2022-06-14 06:43:17', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof', '', '', '2022-06-14 06:43:17', '2022-06-14 06:43:17', '', 206, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_122011-a-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(208, 1, '2022-06-14 06:43:26', '2022-06-14 06:43:26', '', 'Umbau Bearbeitet', '', 'inherit', 'closed', 'closed', '', '206-revision-v1', '', '', '2022-06-14 06:43:26', '2022-06-14 06:43:26', '', 206, 'http://localhost/sponner/?p=208', 0, 'revision', '', 0),
(209, 1, '2022-06-14 06:55:17', '2022-06-14 06:55:17', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:26:\"templates/tmp-projekte.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Projekte', 'projekte', 'publish', 'closed', 'closed', '', 'group_62a82fdaa598f', '', '', '2022-06-14 06:59:24', '2022-06-14 06:59:24', '', 0, 'http://localhost/sponner/?post_type=acf-field-group&#038;p=209', 0, 'acf-field-group', '', 0),
(211, 1, '2022-06-14 06:59:24', '2022-06-14 06:59:24', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Call to Action Section', 'call_to_action_section', 'publish', 'closed', 'closed', '', 'field_62a831af8e1bd', '', '', '2022-06-14 06:59:24', '2022-06-14 06:59:24', '', 209, 'http://localhost/sponner/?post_type=acf-field&p=211', 0, 'acf-field', '', 0),
(212, 1, '2022-06-14 06:59:24', '2022-06-14 06:59:24', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Heading', 'action_heading', 'publish', 'closed', 'closed', '', 'field_62a831b98e1be', '', '', '2022-06-14 06:59:24', '2022-06-14 06:59:24', '', 209, 'http://localhost/sponner/?post_type=acf-field&p=212', 1, 'acf-field', '', 0),
(213, 1, '2022-06-14 06:59:24', '2022-06-14 06:59:24', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Sub Heading', 'action_sub_heading', 'publish', 'closed', 'closed', '', 'field_62a831c08e1bf', '', '', '2022-06-14 06:59:24', '2022-06-14 06:59:24', '', 209, 'http://localhost/sponner/?post_type=acf-field&p=213', 2, 'acf-field', '', 0),
(214, 1, '2022-06-14 06:59:24', '2022-06-14 06:59:24', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Action Button Link', 'action_button_link', 'publish', 'closed', 'closed', '', 'field_62a831c38e1c0', '', '', '2022-06-14 06:59:24', '2022-06-14 06:59:24', '', 209, 'http://localhost/sponner/?post_type=acf-field&p=214', 3, 'acf-field', '', 0),
(215, 1, '2022-06-14 07:00:11', '2022-06-14 07:00:11', '', 'Projekte', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-06-14 07:00:11', '2022-06-14 07:00:11', '', 10, 'http://localhost/sponner/?p=215', 0, 'revision', '', 0),
(216, 1, '2022-06-14 07:09:40', '2022-06-14 07:09:40', '', 'Neubau EFH', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2022-06-14 07:09:40', '2022-06-14 07:09:40', '', 48, 'http://localhost/sponner/?p=216', 0, 'revision', '', 0),
(217, 1, '2022-06-14 07:09:45', '2022-06-14 07:09:45', '', 'Neubau FHE', '', 'inherit', 'closed', 'closed', '', '51-autosave-v1', '', '', '2022-06-14 07:09:45', '2022-06-14 07:09:45', '', 51, 'http://localhost/sponner/?p=217', 0, 'revision', '', 0),
(218, 1, '2022-06-14 07:09:52', '2022-06-14 07:09:52', '', 'Umbau Bearbeitet', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'inherit', 'closed', 'closed', '', '206-revision-v1', '', '', '2022-06-14 07:09:52', '2022-06-14 07:09:52', '', 206, 'http://localhost/sponner/?p=218', 0, 'revision', '', 0),
(219, 1, '2022-06-14 07:09:54', '2022-06-14 07:09:54', '', 'Neubau HEF', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2022-06-14 07:09:54', '2022-06-14 07:09:54', '', 54, 'http://localhost/sponner/?p=219', 0, 'revision', '', 0),
(220, 1, '2022-06-14 07:09:56', '2022-06-14 07:09:56', '', 'Neubau FHE', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2022-06-14 07:09:56', '2022-06-14 07:09:56', '', 51, 'http://localhost/sponner/?p=220', 0, 'revision', '', 0),
(221, 1, '2022-06-14 07:18:20', '2022-06-14 07:18:20', '', 'Project Inner', '', 'publish', 'closed', 'closed', '', 'project-inner', '', '', '2022-06-14 07:18:33', '2022-06-14 07:18:33', '', 0, 'http://localhost/sponner/?post_type=cfs&#038;p=221', 0, 'cfs', '', 0),
(222, 1, '2022-06-14 07:18:48', '2022-06-14 07:18:48', '', 'Umbau Bearbeitet', 'In diesem Haus am Hang befinden sich drei Wohnungen. Zwei davon in<br> Maisonette-Ausführung, mit Zugang zum Garten und teils eigenem Eingang und einer Wohnung<br>im OG mit großzügigem Grundriss auf einer Ebene und barrierefreiem Zugang (Aufzug).', 'inherit', 'closed', 'closed', '', '206-autosave-v1', '', '', '2022-06-14 07:18:48', '2022-06-14 07:18:48', '', 206, 'http://localhost/sponner/?p=222', 0, 'revision', '', 0),
(223, 1, '2022-06-14 07:19:20', '2022-06-14 07:19:20', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-2', '', '', '2022-06-14 07:19:20', '2022-06-14 07:19:20', '', 206, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_122037-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(224, 1, '2022-06-14 07:19:32', '2022-06-14 07:19:32', '', 'dig', 'dig', 'inherit', 'open', 'closed', '', 'dig', '', '', '2022-06-14 07:19:32', '2022-06-14 07:19:32', '', 206, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_122359-a-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(225, 1, '2022-06-14 07:19:44', '2022-06-14 07:19:44', '', 'dig', 'dig', 'inherit', 'open', 'closed', '', 'dig-2', '', '', '2022-06-14 07:19:44', '2022-06-14 07:19:44', '', 206, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_122507-a-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(226, 1, '2022-06-14 07:20:05', '2022-06-14 07:20:05', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-3', '', '', '2022-06-14 07:20:05', '2022-06-14 07:20:05', '', 206, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_122011-a-a2-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(227, 1, '2022-06-14 07:21:09', '2022-06-14 07:21:09', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-4', '', '', '2022-06-14 07:21:09', '2022-06-14 07:21:09', '', 48, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_113354-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(228, 1, '2022-06-14 07:21:21', '2022-06-14 07:21:21', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-5', '', '', '2022-06-14 07:21:21', '2022-06-14 07:21:21', '', 48, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_113429-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(229, 1, '2022-06-14 07:21:33', '2022-06-14 07:21:33', '', 'sdr', 'sdr', 'inherit', 'open', 'closed', '', 'sdr', '', '', '2022-06-14 07:21:33', '2022-06-14 07:21:33', '', 48, 'http://localhost/sponner/wp-content/uploads/2022/06/main-IMG_20220318_115746-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(230, 1, '2022-06-14 07:22:16', '2022-06-14 07:22:16', '', 'sdr', 'sdr', 'inherit', 'open', 'closed', '', 'sdr-2', '', '', '2022-06-14 07:22:16', '2022-06-14 07:22:16', '', 51, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220124_120235.jpg', 0, 'attachment', 'image/jpeg', 0),
(231, 1, '2022-06-14 07:22:29', '2022-06-14 07:22:29', '', 'dig', 'dig', 'inherit', 'open', 'closed', '', 'dig-3', '', '', '2022-06-14 07:22:29', '2022-06-14 07:22:29', '', 51, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220124_115548.jpg', 0, 'attachment', 'image/jpeg', 0),
(232, 1, '2022-06-14 07:22:43', '2022-06-14 07:22:43', '', 'dig', 'dig', 'inherit', 'open', 'closed', '', 'dig-4', '', '', '2022-06-14 07:22:43', '2022-06-14 07:22:43', '', 51, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220124_115426-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(233, 1, '2022-06-14 07:22:55', '2022-06-14 07:22:55', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-6', '', '', '2022-06-14 07:22:55', '2022-06-14 07:22:55', '', 51, 'http://localhost/sponner/wp-content/uploads/2022/06/main-IMG_20220124_120056.jpg', 0, 'attachment', 'image/jpeg', 0),
(234, 1, '2022-06-14 07:23:24', '2022-06-14 07:23:24', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-7', '', '', '2022-06-14 07:23:24', '2022-06-14 07:23:24', '', 54, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_111749-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(235, 1, '2022-06-14 07:23:37', '2022-06-14 07:23:37', '', 'sdr', 'sdr', 'inherit', 'open', 'closed', '', 'sdr-3', '', '', '2022-06-14 07:23:37', '2022-06-14 07:23:37', '', 54, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_111626_12-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(236, 1, '2022-06-14 07:23:51', '2022-06-14 07:23:51', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-8', '', '', '2022-06-14 07:23:51', '2022-06-14 07:23:51', '', 54, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_111749-ba2.jpg', 0, 'attachment', 'image/jpeg', 0),
(237, 1, '2022-06-14 07:24:04', '2022-06-14 07:24:04', '', 'cof', 'cof', 'inherit', 'open', 'closed', '', 'cof-9', '', '', '2022-06-14 07:24:04', '2022-06-14 07:24:04', '', 54, 'http://localhost/sponner/wp-content/uploads/2022/06/IMG_20220318_111946-a2.jpg', 0, 'attachment', 'image/jpeg', 0),
(238, 1, '2022-06-14 08:54:16', '2022-06-14 08:54:16', '', 'My Cv', '', 'publish', 'closed', 'closed', '', 'uber-mich', '', '', '2022-06-14 09:01:47', '2022-06-14 09:01:47', '', 0, 'http://localhost/sponner/?post_type=cfs&#038;p=238', 0, 'cfs', '', 0),
(246, 1, '2022-06-14 10:38:06', '2022-06-14 10:38:06', '', 'call_to_action', '', 'inherit', 'open', 'closed', '', 'call_to_action', '', '', '2022-06-14 10:38:06', '2022-06-14 10:38:06', '', 0, 'http://localhost/sponner/wp-content/uploads/2022/06/call_to_action.jpg', 0, 'attachment', 'image/jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'main_menu', 'main_menu', 0),
(3, 'Footer_Menu', 'footer_menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(39, 2, 0),
(40, 2, 0),
(41, 2, 0),
(46, 2, 0),
(107, 3, 0),
(108, 3, 0),
(109, 3, 0),
(110, 3, 0),
(111, 3, 0),
(112, 3, 0),
(113, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 4),
(3, 3, 'nav_menu', '', 0, 7);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:4:{s:64:\"6e93f3c7f04d942acb23ae72f3fe5eafe18e84f3fcbde65de1946fa85dbb233e\";a:4:{s:10:\"expiration\";i:1656072423;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:100.0) Gecko/20100101 Firefox/100.0\";s:5:\"login\";i:1654862823;}s:64:\"e840ff9fe3990908a0f2da31a78beb7d2ef8e1aabebc050eb65d155476a85d9e\";a:4:{s:10:\"expiration\";i:1656305413;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:100.0) Gecko/20100101 Firefox/100.0\";s:5:\"login\";i:1655095813;}s:64:\"d052ac09f74fbaee2f608ffc4c577a6f91720ad60d1b782b896ed0a01f5ee501\";a:4:{s:10:\"expiration\";i:1656392000;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:100.0) Gecko/20100101 Firefox/100.0\";s:5:\"login\";i:1655182400;}s:64:\"aff98a4c8df060762da70e02a223eac9ea4850e4aaf4a1ef70a871239cdf6b72\";a:4:{s:10:\"expiration\";i:1656421254;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:101.0) Gecko/20100101 Firefox/101.0\";s:5:\"login\";i:1655211654;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(20, 1, 'wp_user-settings-time', '1655186996'),
(21, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:24:\"add-post-type-cpt_banner\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";}'),
(23, 1, 'nav_menu_recently_edited', '3');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$Br0Q5Nj8OMcctZ.y2YqoB11j9qlCrZ1', 'admin', 'Animesh.codearts@gmail.com', 'http://localhost/sponner', '2022-06-10 12:06:56', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_cfs_sessions`
--
ALTER TABLE `wp_cfs_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_cfs_values`
--
ALTER TABLE `wp_cfs_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `field_id_idx` (`field_id`),
  ADD KEY `post_id_idx` (`post_id`);

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_cfs_values`
--
ALTER TABLE `wp_cfs_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=681;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1020;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
