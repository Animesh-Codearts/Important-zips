// JavaScript Document

//var swiper = new Swiper(".mySwiper", {
////        cssMode: true,
//        slidesPerView: 3,
//        spaceBetween: 30,
//        pagination: {
//          el: ".swiper-pagination",
//          clickable: true,
//        },
//        navigation: {
//          nextEl: ".swiper-button-next",
//          prevEl: ".swiper-button-prev",
//        },
//			
//	
//	breakpoints: {
//
//            575: {
//
//                slidesPerView: 2,
//
//            },
//
//            768: {
//
//                slidesPerView: 2,
//
//            },
//
//            992: {
//
//                slidesPerView: 3,
//
//            },
//
//            1200: {
//
//                slidesPerView: 4,
//
//            },
//
//        }
//	
//	
//      });


    var swiper = new Swiper(".our-project-slider", {
            //        cssMode: true,
//                    slidesPerView: 3,
                    spaceBetween: 15,
                    loop: true,
                    pagination: {
                      el: ".swiper-pagination",
                      clickable: true,
                    },
                    navigation: {
                      nextEl: ".project-swiper-button-next",
                      prevEl: ".project-swiper-button-prev",
                    },
                        
                
                breakpoints: {
          640: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 15,
          },
          1024: {
            slidesPerView: 4,
            spaceBetween: 15,
          },
        },
                
                
                  });   
    
    var swiper2 = new Swiper(".custom-solar-batteries-swiper", {
                    //        cssMode: true,
                            slidesPerView: 3,
                            spaceBetween: 0,
                            loop:true,
                            pagination: {
                              el: ".swiper-pagination",
                              clickable: true,
                            },
                            navigation: {
                              nextEl: ".swiper-button-next",
                              prevEl: ".swiper-button-prev",
                            },
                                
                        
                        breakpoints: {
							300: {
                    
                                    slidesPerView: 1,
                    
                                },
							400: {
                    
                                    slidesPerView: 2,
                    
                                },
								520: {
                    
                                    slidesPerView: 2,
                    
                                },
                    
                                575: {
                    
                                    slidesPerView: 2,
                    
                                },
                    
                                768: {
                    
                                    slidesPerView: 3,
                    
                                },
                    
                                992: {
                    
                                    slidesPerView: 2,
                    
                                },
                    
                                1200: {
                    
                                    slidesPerView: 3,
                    
                                },
                    
                            }
                        
                        
                          });