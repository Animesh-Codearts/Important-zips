// JavaScript Document
//jQuery('#custom-owl').owlCarousel({
//    loop:true,
//    margin:10,
//    nav:true,
//    responsive:{
//        0:{
//            items:1
//        },
//        600:{
//            items:1
//        },
//        1000:{
//            items:1
//        }
//    }
//});
jQuery('#custom-owl').owlCarousel({
   loop:true,
   margin:30,
   nav:false,
   dots:false,
   responsive:{
       0:{
           items:2
       },
       600:{
           items:3
       },
       1000:{
           items:6
       }
   }
});