<?php
$html='<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
       
            <table style="border-collapse: collapse;width: 100%; margin: 0 auto;" >
                <thead>
                    <tr>
                        <th style="text-align: left;">LPA INSTRUCTION</th>
                        <th style="text-align: right;"><img style="width: 200px;" src="https://upload.wikimedia.org/wikipedia/commons/b/b6/Image_created_with_a_mobile_phone.png" alt=""></th>
                    </tr>
                </thead>
            </table>
            <table style="border-collapse:collapse;border: 1px solid black;width: 100%; margin:20px 0;" >
                <tbody>
                    <tr>
                        <td>Estate Planner Name:</td>
                        <td><input type="text" style="width:100%;border: none;outline:none;"></td>
                        <td>Date of Consultation:</td>
                        <td><input type="text" style="width:100%;border: none;outline:none;background-color: transparent;"></td>
                    </tr>
                </tbody>
            </table>
            <table style="border-collapse: collapse; width: 100%; margin: 0;margin-bottom: 50px;padding: 0;" >
                <tr>
                    <td style="padding:0 10px 10px 0;">1.</td>
                    <td style="padding-bottom: 10px;">This form must be completed in full by the Estate Planner in the presence of the Client(s).</td>
                </tr>
                <tr>
                    <td style="padding:0 10px 10px 0;">2.</td>
                    <td style="padding-bottom: 10px;">The signature(s) of the Client(s) and the Estate Planner are required at the end of this form.</td>
                </tr>
                <tr>
                    <td style="padding:0 10px 10px 0;">3.</td>
                    <td style="padding-bottom: 10px;">All questions must be answered (put N/A where necessary).</td>
                </tr>
                <tr>
                    <td style="padding:0 10px 10px 0;">4.</td>
                    <td style="padding-bottom: 10px;">Include full notes about the issues discussed during the consultation in the further information 
                        section.</td>
                </tr>
                <tr>
                    <td style="padding:0 10px 10px 0;vertical-align: top;">5.</td>
                    <td style="padding-bottom: 10px;">If the Client suffers from an illness or condition which results in diminished capacity or they take 
                        medication which may impact decision making, a note from a medical practitioner may be required to 
                        protect the Client and nay potential beneficiaries – please provide full details on page 8 of this form.</td>
                </tr>
            </table>
            <table style="border-collapse: collapse; width: 100%; margin: 0;margin-bottom: 50px;padding: 0;">
                
                <tbody>
                <tr>
                        <th style="text-align: left;padding-bottom: 25px;">Personal Details </th>
                        <th style="vertical-align: top;">Client 1</th>
                        <th style="vertical-align: top;">Client 2</th>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 30px;">Title: <br>Mr/Mrs/Miss/Ms/Other </td>
                        <td style="vertical-align: top;"><input type="text" style="width:100%;height:40px; outline: none;border:1px solid black;background-color:transparent;margin-right: 10px;"></td>
                        <td style="vertical-align: top;"><input type="text" style="width:100%;height:40px;outline: none;border:1px solid black;background-color:transparent;margin-left: 10px;"></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 66px;">Full Name:</td>
                        <td style="vertical-align: top;"><input type="text" style="width:100%;height:60px;outline:none;border:1px solid black;background-color:transparent;margin-right: 10px;"></td>
                        <td style="vertical-align: top;"><input type="text" style="width:100%;height:60px;outline:none;border:1px solid black;background-color:transparent;margin-left: 10px;"></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 30px;">Address:</td>
                        <td style="vertical-align: top;padding-bottom: 30px;">
                            <table
                                style="width: 100%; margin:0 10px 15px 0; border-collapse:collapse;padding:0;border:1px solid black;">
                                <tr>
                                    <td><textarea style="outline: none;width: 100%; background-color: transparent; height: 80px; border: none;resize:none"></textarea></td>
                                </tr>
                                <tr>
                                    <td style="padding-left: 10px; padding-bottom: 10px;"><input type="text"
                                            style="outline: none;border: none;" placeholder="PostCode:"></td>
                                </tr>
                            </table>
                        </td>
                        <td style="vertical-align: top;padding-bottom: 30px;">
                            <table
                                style="width: 100%; margin:0 0 15px 10px; border-collapse:collapse;padding:0;border:1px solid black;">
                                <tr>
                                    <td><textarea style="outline: none;width: 100%; background-color: transparent; height: 80px; border: none;resize:none"></textarea></td>
                                </tr>
                                <tr>
                                    <td style="padding-left: 10px; padding-bottom: 10px;"><input type="text"
                                            style="outline: none;border: none;" placeholder="PostCode:"></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr style="margin-bottom: 20px;">
                        <td style="padding-bottom: 30px;">Date of Birth:</td>
                        <td style="vertical-align: top;margin-bottom: 20px;"><input type="text" style="width:100%;height:40px; outline: none;border:1px solid black;background-color:transparent;margin-right: 10px;"></td>
                        <td style="vertical-align: top;margin-bottom: 20px;"><input type="text" style="width:100%;height:40px;outline: none;border:1px solid black;background-color:transparent;margin-left: 10px;"></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding: 30px 0;">
                            <table style="border-collapse:collapse;width:100%;margin: 0;padding:0;">
                                <tbody>
                                    <tr>
                                        <td>Which type of LPA is required: </td>
                                        <td> Property and Financial Affairs </td>
                                        <td><input type="checkbox" style="width:18px;height:18px;"></td>
                                        <td>Property and Financial Affairs</td>
                                        <td ><input type="checkbox"style="width:18px;height:18px;"></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td> Health and Welfare </td>
                                        <td><input type="checkbox" style="width:18px;height:18px;"></td>
                                        <td>Health and Welfare</td>
                                        <td ><input type="checkbox"style="width:18px;height:18px;"></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td> Both</td>
                                        <td><input type="checkbox" style="width:18px;height:18px;"></td>
                                        <td>Both</td>
                                        <td ><input type="checkbox"style="width:18px;height:18px;"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <table style="border-collapse:collapse;width:100%;margin:0;margin-bottom:50px;padding:0;">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;padding-bottom: 20px;">Attorneys</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Spouse / Partner to act as Attorney?</td>
                                        <td>Yes </td>
                                        <td><input type="checkbox"style="width:18px;height:18px;"></td>
                                        <td>No</td>
                                        <td><input type="checkbox"style="width:18px;height:18px;"></td>
                                        <td>Yes </td>
                                        <td><input type="checkbox"style="width:18px;height:18px;"></td>
                                        <td>No</td>
                                        <td><input type="checkbox"style="width:18px;height:18px;"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <table style="border-collapse:collapse;width:100%;margin:0;margin-bottom:50px;padding:0;">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;padding-bottom: 30px;"><u>Additional Attorney(s)</u></th>
                                        <th style="padding-bottom: 30px;">Attorney 1 </th>
                                        <th style="padding-bottom: 30px;">Attorney 2</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Title:<br>Mr/Mrs/Miss/Ms/Other </td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;vertical-align: top;">Full Name:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:80px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:80px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Date of Birth:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 25px;vertical-align: top;">Address:</td>
                                        <td style="vertical-align: top;padding-bottom: 25px;">
                                            <table
                                                style="width: 100%; margin:0 10px 15px 0; border-collapse:collapse;padding:0;border:1px solid black;">
                                                <tr>
                                                    <td><textarea style="outline: none;width: 100%; background-color: transparent; height: 80px; border: none;resize:none"></textarea></td>
                                                </tr>
                                                <tr>
                                                    <td style="padding-left: 10px; padding-bottom: 10px;">
                                                    <input type="text"
                                                            style="outline: none;border: none;" placeholder="PostCode:"></td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td style="vertical-align: top;padding-bottom: 30px;">
                                            <table
                                                style="width: 100%; margin:0 0 15px 10px; border-collapse:collapse;padding:0;border:1px solid black;">
                                                <tr>
                                                    <td><input type="text"
                                                            style="outline: none;width: 100%;background-color: transparent; height: 80px; border: none;"></td>
                                                </tr>
                                                <tr>
                                                    <td style="padding-left: 10px; padding-bottom: 10px;"><input type="text"
                                                            style="outline: none;border: none;" placeholder="PostCode:"></td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Home Telephone:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Mobile Number:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Relationship to Donor:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <table  style="border-collapse:collapse;width:100%;margin:0;margin-bottom:50px;padding:0;">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;padding-bottom: 30px;"><u>Additional Attorney(s) </u></th>
                                        <th style="padding-bottom: 30px;">Attorney 3 </th>
                                        <th style="padding-bottom: 30px;">Attorney 4</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Title:<br>Mr/Mrs/Miss/Ms/Other </td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;vertical-align: top;">Full Name:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:80px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:80px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Date of Birth:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 25px;vertical-align: top;">Address:</td>
                                        <td style="vertical-align: top;padding-bottom: 25px;">
                                            <table
                                                style="width: 100%; margin:0 10px 15px 0; border-collapse:collapse;padding:0;border:1px solid black;">
                                                <tr>
                                                    <td><textarea style="outline: none;width: 100%; background-color: transparent; height: 80px; border: none;resize:none"></textarea></td>
                                                </tr>
                                                <tr>
                                                    <td style="padding-left: 10px; padding-bottom: 10px;">
                                                    <input type="text"
                                                            style="outline: none;border: none;" placeholder="PostCode:"></td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td style="vertical-align: top;padding-bottom: 30px;">
                                            <table
                                                style="width: 100%; margin:0 0 15px 10px; border-collapse:collapse;padding:0;border:1px solid black;">
                                                <tr>
                                                    <td><input type="text"
                                                            style="outline: none;width: 100%;background-color: transparent; height: 80px; border: none;"></td>
                                                </tr>
                                                <tr>
                                                    <td style="padding-left: 10px; padding-bottom: 10px;"><input type="text"
                                                            style="outline: none;border: none;" placeholder="PostCode:"></td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Home Telephone:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Mobile Number:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 40px;">Relationship to Donor:</td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-right:10px;height:40px";></td>
                                        <td style="padding-bottom: 25px;"><input type="text"style="width:100%;border: 1px solid black;outline:none;background-color:transparent;margin-left:10px;height:40px;"></td>
                                    </tr>
                                </tbody>

                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 15px;">Category A:</td>
                        <td style="padding-bottom: 15px;" colspan="2">A person that knows the Donor personally and has done so for at least two
                        <br>years and is more than an acquaintance.</td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 35px;">Category B:</td>
                        <td style="padding-bottom: 35px;" colspan="2">Someone with relevant professional skills.</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="padding-bottom: 50px;"><b>Is the Estate Planner to be a Certificate Provider (Category B)?</b></td>
                        <td  style="padding-bottom: 50px;">Yes&nbsp;<input type="checkbox" style="width: 15px;height:15px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                             No&nbsp;<input type="checkbox" style="width: 15px;height:15px;"></td> 
                    </tr>
                    <tr>
                        <td colspan="3">
                            <table style="border-collapse:collapse;width:100%;margin:0;margin-bottom:50px;padding:0;">
                                <thead>
                                    <th colspan="3" style="padding-bottom: 30px;">Alternative Certificate Provider Details</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="padding-bottom: 30px;">Title:</td>
                                        <td style="padding-bottom: 30px;"><input type="text" style="width:100%;height: 40px; outline:none;border:1px solid black;"></td>
                                        <td style="padding:0 0 30px 20px;vertical-align: top;">Mr/Mrs/Miss/Ms/Other </td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 20px;vertical-align: top;">Full Name:</td>
                                        <td style="padding-bottom: 20px;"><input type="text" style="width:100%;height:70px;outline:none;border:1px solid black;background-color:transparent;margin-right: 10px;"></td>
                                        <td style="padding-bottom: 20px;"></td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 30px;vertical-align: top;">Address:</td>
                                        <td style="vertical-align: top;padding-bottom: 30px;">
                                            <table
                                                style="width: 100%; margin:0 10px 15px 0; border-collapse:collapse;padding:0;border:1px solid black;">
                                                <tr>
                                                    <td><input type="text"
                                                            style="outline: none;width: 100%; background-color: transparent; height: 80px; border: none;"></td>
                                                </tr>
                                                <tr>
                                                    <td style="padding-left: 10px; padding-bottom: 10px;"><input type="text"
                                                            style="outline: none;border: none;" placeholder="PostCode:"></td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td style="vertical-align: top;padding:0 0 30px 20px;">
                                            NB – Only complete section<br>
                                            opposite if the Estate Planner<br>
                                            is not to act as a CP</td>
                                    </tr>
                                    <tr>
                                        <td style="padding-bottom: 30px;">Which Category?</td>
                                        <td style="padding-bottom: 30px;"><input type="text" placeholder="Category A / Category B" style="width:100%;height: 40px;text-align: center; outline:none;border:1px solid black;"></td>
                                        <td style="padding:0 0 30px 20px;vertical-align: top;"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding-bottom: 15px;"><b>Notes and Additional Information</b></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding-bottom: 30px;"><textarea style="width: 100%;height: 400px; outline: none;border: 1px solid black;resize: none;"></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding-bottom: 30px;"><b>Registering your LPA</b></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding-bottom: 30px;line-height: 23px;">A Lasting Power of Attorney (LPA) must be registered with the Office of the Public Guardian (OPG)
                        <br>before it can be used. Registration can be undertaken by the Donor or the Attorney(s) either now , 
                        <br>or at any time in the future prior to the Donor’s death A fee of £82 (subject to change) will be 
                        <br>payable by the Donor to the OPG to register the LPA (unless entitled to a fee exemption or 
                        <br>remission). The OPG fee is not included in our fee. </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="padding-bottom: 30px;line-height: 23px;">LPA Registration Service. Do you wish to take advantage
                            <br>of this service?
                        </td>
                        <td style="padding-bottom: 30px;">Yes&nbsp;<input type="checkbox" style="width: 15px;height:15px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                             No&nbsp;<input type="checkbox" style="width: 15px;height:15px;"></td> 
                    </tr>
                    <tr>
                        <td style="padding-bottom: 30px;">If yes, who is to complete the
                        <br>registration paperwork:</td>
                        <td colspan="2" style="padding-bottom: 30px;">Donor / Attorney 1 / Attorney 2 / Attorney 3 / Attorney 4</td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 50px;">After registration of the LPA
                        <br>is complete, what should<br>happen to the document?</td>
                        <td colspan="2" style="padding-bottom: 50px;">Return to Donor / Return to Attorney / Place in Secure Storage</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding-bottom: 15px;"><b>Client Signature(s)</b></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding-bottom: 15px;">Please refer to the full disclaimer on the Fact Find before signing this form.</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding-bottom: 30px;">It has been explained to me that my nominated Attorneys must sign and date my LPA (and have their signature 
                            witnessed) promptly and within a reasonable period of time (currently deemed to be within 12 months of the 
                            Donor’s signature) as failure to do so may prevent the future registration of the document.
                        </td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 20px;"><b>Client 1 Signature:</b></td>
                        <td colspan="2" style="vertical-align: top;padding-bottom: 20px;"><input type="text" style="width:100%;height:50px;outline:none;border:1px solid black;"></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 20px;"><b>Client 2 Signature:</b></td>
                        <td colspan="2" style="vertical-align: top;padding-bottom: 20px;"><input type="text" style="width:100%;height:50px;outline:none;border:1px solid black;"></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 20px;"><b>Date:</b></td>
                        <td colspan="2" style="vertical-align: top;padding-bottom: 20px;"><input type="text" style="width:100%;height:50px;outline:none;border:1px solid black;"></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 20px;"><b>Signature of Estate Planner:</b></td>
                        <td colspan="2" style="vertical-align: top;padding-bottom: 20px;"><input type="text" style="width:100%;height:50px;outline:none;border:1px solid black;"></td>
                    </tr>
                </tbody>
            </table>
        
    </div>
     <!-- <table style="border-collapse:collapse;width:100%;margin:0;margin-bottom:50px;padding:0;">
            </table> -->
</body>
</html>';



?>
