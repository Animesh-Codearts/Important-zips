<?php
/* 

Plugin Name: PDF Data
Description: Plugin for converting HTML To PDF

*/

function me_post_pdf(){
    if (isset($_POST['me_post_pdf'])){
        include 'dompdf/autoload.inc.php';
        global $wp;
        //$current_url = home_url(add_query_arg(array(),$wp->request));

        $html = 'demo';

        $options = new Options();
        $options->set('A4','potrait');
        $options->set('enable_css_float',true);
        $options->set('isHtml5ParserEnabled', true);

        $dompdf = new DOMPDF();
        $pdf->loadHtml($html);

		// (Optional) Setup the paper size and orientation
		$pdf->setPaper('A4', 'landscape');

		// Render the HTML as PDF
		$pdf->render();

		// Output the generated PDF to Browser

		$pdf->stream();
		$pdf->stream('result.pdf', Array('attachment'=> 0));
        // $dompdf->load_html($html);

        // $dompdf->render();

        // $dompdf->stream('title.pdf');
        exit;
    }
}

add_action('init', 'me_post_pdf');

add_shortcode( 'customformfordom', 'customformfordom' ); 
function customformfordom( $atts ) {
   ?> 
   <form>
    <input type="submit" value="click me">
    <input type="hidden" name="me_post_pdf" value="submitted">
</form>
    <?php
}


?>
