<?php

return array(

    'styles' => array(
        'id' => 'styles',
        'nicename' => __( 'Styles', 'ninja-forms-layout-styles' ),
    )

);